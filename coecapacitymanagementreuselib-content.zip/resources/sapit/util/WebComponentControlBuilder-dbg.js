sap.ui.define([
	"sap/ui/base/Object"

], function (Object) {
	"use strict";
	return Object.extend("sapit.util.WebComponentControlBuilder", {
		//one second wait time maximum
		_triesToWaitForMethod: 100,
		_timeToWaitForMethod: 300,
		_events: [],
		_properties: [],
		_methods: [],
		_attachToDom: false,
		_attachAsIntegrationPopup: false,
		_htmlTag: "",

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Lifecycle
		////////////////////////////////////////////////////////////////////////////////////////////////////

		constructor: function (ctx) {
			if (ctx) {
				this._ctx = ctx;
			}
			//reset
			this._events = [];
			this._properties = [];
			this._methods = [];
			this._attachToDom = false;
			this._htmlTag = "";
		},

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// public
		////////////////////////////////////////////////////////////////////////////////////////////////////

		setContext: function (ctx) {
			this._ctx = ctx;
		},
		htmlTag: function (sHTMLTag) {
			this._htmlTag = sHTMLTag;
			return this;
		},
		property: function (oPropertyBag) {
			this._properties.push(oPropertyBag);
			return this;
		},
		event: function (oEventBag) {
			this._events.push(oEventBag);
			return this;
		},
		method: function (oMethodBag) {
			this._methods.push(oMethodBag);
			return this;
		},
		attachDomRef: function () {
			this._attachToDom = true;

			return this;
		},
		attachAsIntegrationPopup: function () {
			this._attachAsIntegrationPopup = true;

			return this;
		},
		render: function (oRm, oControl) {
			if (this._ctx) {
				
				oRm.write("<" + this._htmlTag);
				if(this._attachAsIntegrationPopup){
					oRm.write(" data-sap-ui-integration-popup-content");
				}
				oRm.writeControlData(oControl); // writes the Control ID  - important!
				oRm.writeClasses(); // there is no class to write, but this enables
				// support for .addStyleClass(...)
				var sProperties = this._properties.map(function (oProperty) {
					//if the name of the property, inside the html, is different, use this instead
					var htmlName = oProperty.name;
					if (oProperty.htmlName) {
						htmlName = oProperty.htmlName;
					}
					var sMethodName = "get" + oProperty.name.charAt(0).toUpperCase() + oProperty.name.slice(1);
					if (oProperty.boolean === true) {
						if (oControl[sMethodName]() === true) {
							return htmlName;
						}
					} else {
						if (oControl[sMethodName]() != undefined) {
							return htmlName + "='" + oControl[sMethodName]() + "'";
						}
					}
				}.bind(this)).join(" ");

				oRm.write(" " + sProperties + ">");

				oRm.write("</" + this._htmlTag + ">");
			}
		},
		build: function () {
			this._loadPolyfills();
			if (this._ctx) {
				//check for attachToDom
				if (this._attachToDom) {
					$(document).ready(function () {
						//the dom will be removed when the custom control gets destroyed - no need to worry about cleanup
						var div = document.createElement("div");
						document.body.appendChild(div);
						this._ctx.placeAt(div);
					}.bind(this));

				}
				var tries = this._triesToWaitForMethod;
				var time = this._timeToWaitForMethod;
				//check for methods
				this._methods.forEach(function (oMethodBag) {
					this._ctx[oMethodBag.name] = function (oMethodEvent) {
						var promise = $.Deferred();
						var currTry = 1;
						setTimeout(function () {
							//if it is required to pass over dom references, do it
							if (oMethodBag.useDomRef === true && oMethodEvent && oMethodEvent.getDomRef) {
								oMethodEvent = oMethodEvent.getDomRef();
							}
							//if the name of the method, inside the html, is different, use this instead
							var htmlName = oMethodBag.name;
							if (oMethodBag.htmlName) {
								htmlName = oMethodBag.htmlName;
							}
							if (this.getDomRef() && this.getDomRef()[htmlName]) {
								this.getDomRef()[htmlName](oMethodEvent);
								promise.resolve();
							} else if (tries > currTry) {
								//we will try to wait until the method is available with given parameters
								var interval = setInterval(function () {
									if (this.getDomRef() && this.getDomRef()[htmlName]) {
										this.getDomRef()[htmlName](oMethodEvent);
										promise.resolve();
										clearInterval(interval);

									} else if (tries <= currTry) {
										promise.reject();
										clearInterval(interval);
									}
									currTry++;
								}.bind(this), time);

							} else {
								promise.reject();
							}

						}.bind(this), 300);
						return promise;
					}.bind(this._ctx);
				}.bind(this));

				//check for events
				this._ctx.removeEventDelegate({
					onAfterRendering: function () { }
				});
				this._ctx.addEventDelegate({
					onAfterRendering: function () {
						this._events.forEach(function (oEventBag) {
							//if the name of the event, inside the html, is different, use this instead
							var htmlName = oEventBag.name;
							if (oEventBag.htmlName) {
								htmlName = oEventBag.htmlName;
							}

							var _fCallback = function (event) {
								var sMethodName = "fire" + oEventBag.name.charAt(0).toUpperCase() + oEventBag.name.slice(1);
								//this will copy the value of the web standard property 'detail' to a given property
								if (!!oEventBag.detailConversion && event) {
									event[oEventBag.detailConversion] = event.detail;
								}
								this[sMethodName].bind(this)(event);
								//rebind the listener after succesful execution
							};
							this._ctx.getDomRef().addEventListener(htmlName, _fCallback.bind(this._ctx), {
								once: false
							});
						}.bind(this));
						//this is required to make sure that non-primitive properties are passed over to the web component!
						this._properties.forEach(function (oProperty) {
							//if the name of the property, inside the html, is different, use this instead
							var htmlName = oProperty.name;
							if (oProperty.htmlName) {
								htmlName = oProperty.htmlName;
							}
							var sMethodName = "get" + oProperty.name.charAt(0).toUpperCase() + oProperty.name.slice(1);

							if (oProperty.boolean === true) {
								//only append boolean values to dom, when they are true -> otherwise remove them from the dom element => native boolean dom elements are true as soon as they are added, independent of the value
								if (this._ctx[sMethodName]() === true) {
									this._ctx.getDomRef()[htmlName] = this._ctx[sMethodName]();
								}
							} else {
								if (this._ctx[sMethodName]() != undefined) {
									this._ctx.getDomRef()[htmlName] = this._ctx[sMethodName]();
								}
							}
						}.bind(this));
					}.bind(this)
				});
			}
			return this;
		},

		_loadPolyfills: function () {
			(function (arr) {
				arr.forEach(function (item) {
					if (item.hasOwnProperty('remove')) {
						return;
					}
					Object.defineProperty(item, 'remove', {
						configurable: true,
						enumerable: true,
						writable: true,
						value: function remove() {
							if (this.parentNode !== null)
								this.parentNode.removeChild(this);
						}
					});
				});
			})([Element.prototype, CharacterData.prototype, DocumentType.prototype]);
		}
	});
});

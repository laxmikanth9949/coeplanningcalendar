sap.ui.define([
	"sap/ui/base/Object",
	"sap/viz/ui5/controls/common/feeds/FeedItem",
	"sap/viz/ui5/data/DimensionDefinition",
	"sap/viz/ui5/data/MeasureDefinition"
], function (Object, FeedItem, DimensionDefinition, MeasureDefinition) {
	"use strict";
	return Object.extend("sapit.util.VizFrameBuilder", {

		_dataBinding: undefined,
		_measures: [],
		_dimensions: [],
		_feeds: [],
		_scales: [],
		_filters: [],
		_properties: undefined,
		_vizType: undefined,

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Lifecycle
		////////////////////////////////////////////////////////////////////////////////////////////////////

		constructor: function (ctx) {
			if (ctx) this._ctx = ctx;
			this._measures = [];
			this._dataBinding = undefined;
			this._dimensions = [];
			this._feeds = [];
			this._scales = [];
			this._properties = {};
			this._filters = [];
			this._vizType = undefined;
		},

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// public
		////////////////////////////////////////////////////////////////////////////////////////////////////

		updateVizFrame: function (oVizFrame) {
			oVizFrame.setVizType(this._vizType);
			oVizFrame.setVizProperties(this._properties);
			oVizFrame.setVizScales(this._scales);
			oVizFrame.setDataset(new sap.viz.ui5.data.FlattenedDataset({
				data: this._dataBinding,
				measures: this._measures,
				dimensions: this._dimensions
			}));

			oVizFrame.destroyFeeds();
			this._feeds.forEach(function (i) {
				oVizFrame.addFeed(i);
			});

			oVizFrame.getDataset().getBinding("data").filter(this._filters);
		},

		setContext: function (ctx) {
			this._ctx = ctx;
		},

		bindData: function (oData, sPath) {

			// bindData via objet or model+path
			if (typeof oData === "object") {
				this._bindDataObject.apply(this, arguments);
			} else {
				this._bindDataPath.apply(this, arguments);
			}

			// Sanatize data
			if (!this._dataBinding.parameters) this._dataBinding.parameters = {};
			if (!this._dataBinding.parameters.select) this._dataBinding.parameters.select = "";

			return this;
		},

		setVizType: function (sVizType) {
			this._vizType = sVizType;
			return this;
		},

		//////////////////////////////
		// Filters
		//////////////////////////////
		clearFilters: function () {
			this._filters = [];
			return this;
		},

		setFilters: function (aFilters) {
			this.clearFilters();
			aFilters.forEach(function (oFilter) {
				this.addFilter(oFilter);
			}.bind(this));
			return this;
		},

		addFilter: function (oFilter) {
			this._filters.push(oFilter);
			return this;
		},

		//////////////////////////////
		// Dimensions
		//////////////////////////////
		clearDimensions: function () {
			this._dimensions = [];
			return this;
		},
		setDimensions: function (aDimensions) {
			this.clearDimensions();
			aDimensions.forEach(function (oDimensions) {
				this.addDimension(oDimensions.feedType, oDimensions.name, oDimensions.column, oDimensions.formatter);
			}.bind(this));
			return this;
		},

		addDimension: function (sFeedType, sName, sColumn, fnFormatter) {

			if (typeof sName === "string")
				sName = [sName];
			if (typeof sColumn === "string")
				sColumn = [sColumn];
			if (fnFormatter && typeof fnFormatter === "string")
				fnFormatter = [fnFormatter];

			for (var i in sName) {
				this._dimensions.push(new DimensionDefinition({
					name: sName[i],
					dataType: sFeedType === "timeAxis" ? "date" : undefined,
					value: {
						path: sColumn[i],
						formatter: this._ctx && fnFormatter && fnFormatter[i] ? this._ctx[fnFormatter[i]] : undefined
					}
				}));
			}

			this._addFeed(sFeedType, "Dimension", sName, this.vizframeData);
			this._addToSelect(sColumn, this.vizframeData);

			return this;
		},

		//////////////////////////////
		// Measures
		//////////////////////////////
		clearMeasures: function () {
			this._measures = [];
			return this;
		},
		setMeasures: function (aMeasures) {
			this.clearMeasures();
			aMeasures.forEach(function (oMeasure) {
				this.addMeasure(oMeasure.feedType, oMeasure.name, oMeasure.column);
			}.bind(this));
			return this;
		},
		addMeasure: function (sFeedType, sName, sColumn) {
			this._measures.push(new MeasureDefinition({
				name: sName,
				value: "{" + sColumn + "}"
			}));
			this._addFeed(sFeedType, "Measure", [sName], this.vizframeData);
			this._addToSelect([sColumn], this.vizframeData);

			return this;
		},

		//////////////////////////////
		// Properties
		//////////////////////////////
		clearProperties: function () {
			this._properties = {};
			return this;
		},
		setProperties: function (oProperties) {
			this.clearProperties();
			for (var i in oProperties) {
				this.addProperty(i, oProperties[i]);
			}
			return this;
		},
		addProperty: function (sKey, sValue) {
			this._properties[sKey] = sValue;
			return this;
		},

		//////////////////////////////
		// Scales
		//////////////////////////////
		clearScales: function () {
			this._scales = {};
			return this;
		},
		setScales: function (oScales) {
			this.clearScales();
			for (var i in oScales) {
				this.addProperty(i, oScales[i]);
			}
			return this;
		},
		addScale: function (sKey, sValue) {
			this._scales[sKey] = sValue;
			return this;
		},

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// protected
		////////////////////////////////////////////////////////////////////////////////////////////////////

		_bindDataObject: function (oData) {
			this._dataBinding = oData;
		},

		_bindDataPath: function (sModel, sPath) {
			this._dataBinding = {
				model: sModel,
				path: sPath
			};
		},

		_addFeed: function (sFeedType, sType, sValues) {
			this._feeds.push(new FeedItem({
				uid: sFeedType,
				type: sType,
				values: sValues
			}));
		},

		_addToSelect: function (aValues) {
			var aSelectColumns = this._dataBinding.parameters.select
				.split(",")
				.filter(function (e) {
					return e !== "";
				})
				.concat(aValues);
			this._dataBinding.parameters.select = aSelectColumns.join(",");
		}
	});
});

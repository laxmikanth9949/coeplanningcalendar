sap.ui.define([], function () {
	"use strict";
	return {
		startUsageTracking: function (oComponent, bEnableUserTracking) {
			this.oCurrentComp = undefined;
			var bEnableUser = false;
			if (bEnableUserTracking === true) {
				bEnableUser = true;
			}
			sap.git = sap.git || {}, sap.git.usage = sap.git.usage || {}, sap.git.usage.Reporting = {
				_lp: null,
				_load: function (a) {
					this._lp = this._lp || sap.ui.getCore().loadLibrary("sap.git.usage", {
						url: "https://trackingshallwe.hana.ondemand.com/web-client/v3",
						async: !0
					}), this._lp.then(function () {
						a(sap.git.usage.MobileUsageReporting)
					}, this._loadFailed)
				},
				_loadFailed: function (a) {
					jQuery.sap.log.warning("[sap.git.usage.MobileUsageReporting]", "Loading failed: " + a);
				},
				setup: function (a) {
					this._load(function (b) {
						b.setup(a)
					})
				},
				addEvent: function (a, b) {
					this._load(function (c) {
						c.addEvent(a, b)
					})
				},
				setUser: function (a, b) {
					this._load(function (c) {
						c.setUser(a, b)
					})
				}
			};

			sap.git.usage.Reporting.setup(oComponent);
			this.oCurrentComp = oComponent;
			// if (bEnableUser === true) {
			// 	this._getUserInfoPromise().done(function (oUser) {
			// 		sap.git.usage.Reporting.setUser(this.oCurrentComp, oUser.name);
			// 	}.bind(this));
			// }

		},
		// _getUserInfoPromise: function () {
		// 	return $.ajax({
		// 		url: jQuery.sap.getModulePath("sapit") + "/services/userapi/currentUser",
		// 		type: 'GET'
		// 	});
		// },
		trackEvent: function (sCustomEvent, oComponent) {
			sap.git.usage.Reporting.addEvent(oComponent, sCustomEvent);

		}
	};
});
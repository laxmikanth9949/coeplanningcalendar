sap.ui.define([
	"sap/ui/base/Object"
], function (Object) {
	"use strict";
	return Object.extend("sapit.util.ITDirectTicketURLBuilder", {

		_itdssfBaseUrl: "https://fiorilaunchpad.sap.com/sites#Help-Inbox&/",
		_itdssfCreateRoute: "create",

		_urlProperties: {
			_processType: null,
			_category: null,
			_description: null,
			_priority: null,
			_equipment: null,
			_system: null,
			_comment: null,
			_country: null,
			_building: null,
			_roomNo: null,
			_materialNo: null,
			_affectedUserId: null
		},

		processType: function (sProcessType) {
			this._urlProperties._processType = sProcessType;
			return this;
		},

		category: function (sCategoryId) {
			this._urlProperties._category = sCategoryId;
			return this;
		},

		description: function (sDescription) {
			this._urlProperties._description = sDescription;
			return this;
		},

		priority: function (sPriority) {
			this._urlProperties._priority = sPriority;
			return this;
		},

		equipment: function (sEquipment) {
			this._urlProperties._equipment = sEquipment;
			return this;
		},

		system: function (sSystem) {
			this._urlProperties._system = sSystem;
			return this;
		},

		comment: function (sComment) {
			this._urlProperties._comment = sComment;
			return this;
		},

		country: function (sCountry) {
			this._urlProperties._country = sCountry;
			return this;
		},

		building: function (sBuilding) {
			this._urlProperties._building = sBuilding;
			return this;
		},

		roomNo: function (sRoomNo) {
			this._urlProperties._roomNo = sRoomNo;
			return this;
		},

		materialNo: function (sMaterialNo) {
			this._urlProperties._materialNo = sMaterialNo;
			return this;
		},

		affectedUserId: function (sAffectedUserId) {
			this._urlProperties._affectedUserId = sAffectedUserId;
			return this;
		},

		build: function () {
			var sUrl = this._itdssfBaseUrl + this._itdssfCreateRoute;
			for (var i in this._urlProperties) {
				sUrl += "/" + this._urlProperties[i];
			}
			return sUrl;
		},

		open: function (bNewTab) {
			var sUrl = this.build();
			sap.m.URLHelper.redirect(sUrl, bNewTab !== false);
		}
	});
});
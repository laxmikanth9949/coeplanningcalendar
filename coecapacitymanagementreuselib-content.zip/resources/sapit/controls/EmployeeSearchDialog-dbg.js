sap.ui.define(['sap/ui/core/XMLComposite', 'sap/ui/model/json/JSONModel'],
	function (XMLComposite, JSONModel) {
		"use strict";

		var EmployeeSearchDialog = XMLComposite.extend("sapit.controls.EmployeeSearchDialog", {

			////////////////////////////////////////////////////////////////////////////////////////////////////
			// Definition
			////////////////////////////////////////////////////////////////////////////////////////////////////

			/* eslint-disable no-undef */
			metadata: {
				library: "sapit",
				properties: {
					contentWidth: {
						type: "sap.ui.core.CSSSize",
						defaultValue: sapit.DialogWidth.SMALL

					},
					contentHeight: {
						type: "sap.ui.core.CSSSize",
						defaultValue: sapit.DialogHeight.MEDIUM
					},
					title: {
						type: "string",
						defaultValue: "Employee Search"
					},
					noDataText: {
						type: "string",
						defaultValue: ""
					},
					liveSearch: {
						type: "boolean",
						defaultValue: true
					},
					endpoint: {
						type: "string",
						defaultValue: jQuery.sap.getModulePath("sapit") + "/sapitapi"
					},
				},
				aggregations: {},
				events: {
					confirm: {
						parameters: {
							value: {
								type: "string"
							}
						}
					},
					cancel: {
						parameters: {}
					}
				}
			},

			/* eslint-enable no-undef */

			////////////////////////////////////////////////////////////////////////////////////////////////////
			// Lifecycle
			////////////////////////////////////////////////////////////////////////////////////////////////////

			init: function () {
				console.warn("sapit.controls.EmployeeSearchDialog is deprecated. Please use sapit.controls.EmployeeDataSearchDialog instead.");
				var oDialog = sap.ui.core.Fragment.byId(this.getId(), "dialog");
				oDialog.setModel(new JSONModel());
				this._oDialog = oDialog;
			},

			////////////////////////////////////////////////////////////////////////////////////////////////////
			// Public
			////////////////////////////////////////////////////////////////////////////////////////////////////

			open: function () {
				this._oDialog.open();
				this._oDialog.getModel().setData({});
			},

			close: function () {
				this._oDialog.close();
			},

			////////////////////////////////////////////////////////////////////////////////////////////////////
			// Dialog Callbacks
			////////////////////////////////////////////////////////////////////////////////////////////////////

			onLiveChange: function (oEvt) {
				if (this.getLiveSearch()) {
					this.onSearch(oEvt);
				}
			},

			onSearch: function (oEvt) {
				var sNewValue = oEvt.getParameter("value");
				//in case the value is empty, simply clear the data of the dialog
				if (!sNewValue) {
					this._oDialog.getModel().setData({
						items: []
					});
				} else {
					this._fetchUserInfo(sNewValue);
				}

			},

			onConfirm: function (oEvt) {
				var users = oEvt.getParameter("selectedContexts")[0].getObject(); // We only support singe select
				this.fireConfirm({
					value: users
				});
			},
			onCancel: function () {
				this.fireCancel({});
			},

			////////////////////////////////////////////////////////////////////////////////////////////////////
			// Protected
			////////////////////////////////////////////////////////////////////////////////////////////////////
			_fetchUserInfo: function (sQuery) {
				this._oDialog.setBusy(true);
				$.ajax({
						url: this.getEndpoint() + "/user-info?q=" + sQuery + "&limit=50"
					})
					.done(this._fetchUserInfoDone.bind(this))
					.fail(this._fetchUserInfoFail.bind(this));
			},

			_fetchUserInfoDone: function (oData) {
				this._oDialog.setBusy(false);
				this._oDialog.getModel().setData({
					items: oData
				});
			},

			_fetchUserInfoFail: function (jqXHR, textStatus, errorThrown) {
				this._oDialog.setBusy(false);
				jQuery.sap.log.warning("Failed to fetch UserInfo", "jqXHR=[" + jqXHR + "], textStatus=[" + textStatus + "], errorThrown=[" +
					errorThrown + "]", "sapit");
			}
		});

		return EmployeeSearchDialog;
	});
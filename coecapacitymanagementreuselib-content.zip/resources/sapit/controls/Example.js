/*!
 * ${copyright}
 */
sap.ui.define(["jquery.sap.global","sap/ui/core/Control"],function(jQuery,e){"use strict";var t=e.extend("sapit.controls.Example",{metadata:{library:"sapit",properties:{text:{type:"string",group:"Misc",defaultValue:null}},events:{press:{}}}});return t},true);
//# sourceMappingURL=Example.js.map
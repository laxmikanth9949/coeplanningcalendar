sap.ui.define([
	"sap/ui/core/Control",
	"../util/WebComponentControlBuilder"
], function (Control, WebComponentControlBuilder) {
	"use strict";

	return Control.extend("sapit.controls.EmployeeDataSearchDialog", {

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Definition
		////////////////////////////////////////////////////////////////////////////////////////////////////

		metadata: {
			library: "sapit",
			properties: {
				endpoint: {
					type: "string",
					defaultValue: "./sapit-employee-data"
				},
				functionEndpoint: {
					type: "string",
					defaultValue: "/Employees"
				},
				searchParameter: {
					type: "string",
					defaultValue: "$search"
				},
				limitParameter: {
					type: "string",
					defaultValue: "$top"
				},
				loadingDelay: {
					type: "string",
					defaultValue: "1000"
				},
				contentWidth: {
					type: "string",
					defaultValue: "30vw"
				},
				contentHeight: {
					type: "string",
					defaultValue: "30rem"

				},
				noDataText: {
					type: "string",
					defaultValue: "No employees found ..."
				},
				title: {
					type: "string",
					defaultValue: "Employee Search"
				},
				liveSearch: {
					type: "boolean",
					defaultValue: true
				},
				multiSelect: {
					type: "boolean",
					defaultValue: false
				}
			},
			events: {
				search: {
					event: {}
				},
				confirm: {
					event: {}
				},
				cancel: {
					event: {}
				}

			},
			methods: {
				open: {},
				close: {},
				clear: {}
			}
		},

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Lifecycle
		////////////////////////////////////////////////////////////////////////////////////////////////////
		init: function () {
			this.builder = new WebComponentControlBuilder(this);
			this.builder
				.htmlTag("sapit-employee-data-search-dialog")
				.attachDomRef()
				.attachAsIntegrationPopup()
				.property({
					name: "endpoint"
				})
				.property({
					name: "functionEndpoint",
					htmlName: "function-endpoint"
				})
				.property({
					name: "searchParameter",
					htmlName: "search-parameter"
				})
				.property({
					name: "limitParameter",
					htmlName: "limit-parameter"
				})
				.property({
					name: "loadingDelay",
					htmlName: "loading-delay"
				})
				.property({
					name: "contentWidth",
					htmlName: "content-width"
				})
				.property({
					name: "contentHeight",
					htmlName: "content-height"
				})
				.property({
					name: "title",
					htmlName: "title"
				})
				.property({
					name: "noDataText",
					htmlName: "no-data-text"
				})
				.property({
					name: "liveSearch",
					boolean: true,
					htmlName: "live-search"
				})
				.property({
					name: "multiSelect",
					boolean: true,
					htmlName: "multi-select"
				})

				.method({
					name: "open"
				})
				.method({
					name: "close"
				})
				.method({
					name: "clear"
				})
				.event({
					name: "search",
					detailConversion: "value"
				})
				.event({
					name: "confirm",
					detailConversion: "value"
				})
				.event({
					name: "cancel"
				})
				.build();
		},

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Renderer
		////////////////////////////////////////////////////////////////////////////////////////////////////

		renderer: function (oRm, oControl) {
			//we will use the webcomponentcontrol renderer to render our preconfigured properties
			oControl.builder.render(oRm, oControl);
		}

	});
});
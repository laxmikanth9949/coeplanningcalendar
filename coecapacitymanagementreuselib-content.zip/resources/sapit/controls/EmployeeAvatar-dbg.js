sap.ui.define(['sap/m/Avatar'],
	function (Avatar) {
		"use strict";

		/**
		 * Constructor for a new EmployeeAvatar.
		 *
		 * @param {string} [sId] ID for the new control, generated automatically if no ID is given
		 * @param {object} [mSettings] Initial settings for the new control
		 *
		 * @class
		 * The EmployeeAvatar control represents an Avatar for SAP Employee showing either a profile picture or the employees initials.
		 *
		 * @extends sap.f.Avatar
		 *
		 * @author SAP IT Platform CoE
		 * @version 2.0.33
		 *
		 * @constructor
		 * @private
		 * @alias sapit.controls.EmployeeAvatar
		 */
		var EmployeeAvatar = Avatar.extend("sapit.controls.EmployeeAvatar", {
			////////////////////////////////////////////////////////////////////////////////////////////////////
			// Definition
			////////////////////////////////////////////////////////////////////////////////////////////////////
			metadata: {
				library: "sapit",
				properties: {
					"employeeId": {
						type: "string",
						defaultValue: null,
						bindable: "bindable"
					},
					"firstName": {
						type: "string",
						defaultValue: null,
						bindable: "bindable"
					},
					"lastName": {
						type: "string",
						defaultValue: null,
						bindable: "bindable"
					},
					"showProfilePicture": {
						type: "boolean",
						defaultValue: true,
						bindable: "bindable"
					},
					"fetchUserInfo": {
						type: "boolean",
						defaultValue: false,
						bindable: "bindable"
					},
					endpoint: {
						type: "string",
						defaultValue: jQuery.sap.getModulePath("sapit") + "/sapitapi"
					},
				}
			},

			init: function () {
				this.setShowProfilePicture(false);
			},
			////////////////////////////////////////////////////////////////////////////////////////////////////
			// Public
			////////////////////////////////////////////////////////////////////////////////////////////////////

			setEmployeeId: function (sValue) {
				this.setProperty("employeeId", sValue, true);
				this._fetchUserInfo();
				this._setSrc();
			},

			setFirstName: function (sValue) {
				this.setProperty("firstName", sValue, true);
				this._setInitials();
			},

			setLastName: function (sValue) {
				this.setProperty("lastName", sValue, true);
				this._setInitials();
			},

			setShowProfilePicture: function (sValue) {
				this.setProperty("showProfilePicture", sValue);
				this._setSrc();
			},

			setFetchUserInfo: function (bValue) {
				this.setProperty("fetchUserInfo", bValue, true);
				this._fetchUserInfo();
			},

			////////////////////////////////////////////////////////////////////////////////////////////////////
			// Protected
			////////////////////////////////////////////////////////////////////////////////////////////////////

			_fetchUserInfo: function (bValue) {

				var bFetchUserInfo = this.getFetchUserInfo();
				var sEmployeeId = this.getEmployeeId();

				jQuery.sap.log.trace("Check if fetch userinfo is needed", "fetchUserInfo=[" + bFetchUserInfo + "], employeeId=[" + sEmployeeId +
					"]", "sapit");

				//reset data properties if the data should be fetched
				if (bFetchUserInfo) {
					this.setFirstName("");
					this.setLastName("");
				}

				if (sEmployeeId !== undefined && sEmployeeId !== "" && bFetchUserInfo) {
					$.ajax({
							url: this.getEndpoint() + "/Employees/" + sEmployeeId

						})
						.done(this._fetchUserInfoDone.bind(this))
						.fail(this._fetchUserInfoFail.bind(this));
				}
			},

			_fetchUserInfoDone: function (oData) {
				this.setFirstName(oData.firstName);
				this.setLastName(oData.lastName);
				//this.setShowProfilePicture(oData.profilePictureEnabled);
			},

			_fetchUserInfoFail: function (jqXHR, textStatus, errorThrown) {
				jQuery.sap.log.warning("Failed to fetch UserInfo", "jqXHR=[" + jqXHR + "], textStatus=[" + textStatus + "], errorThrown=[" +
					errorThrown + "]", "sapit");
			},

			_setInitials: function () {
				var sFirstName = this.getFirstName();
				var sLastName = this.getLastName();

				jQuery.sap.log.trace("Calculating initials", "firstName=[" + sFirstName + "], lastName=[" + sLastName + "]", "sapit");

				var sInitialFirstName = sFirstName.charAt(0).toUpperCase();
				var sInitialLasttName = sLastName.charAt(0).toUpperCase();

				this.setInitials(sInitialFirstName + sInitialLasttName);
			},

			_setSrc: function () {
				var sEmployeeId = this.getEmployeeId();
				var bShowProfilePicture = this.getShowProfilePicture();

				jQuery.sap.log.trace("Calculating src", "employeeId=[" + sEmployeeId + "], showProfilePicture=[" + bShowProfilePicture + "]",
					"sapit");

				if (sEmployeeId !== undefined && sEmployeeId !== "" && bShowProfilePicture) {
					this.setSrc(this.getEndpoint() + "/Employees/" + sEmployeeId +
						"/profilePicture?size=ORIGINAL");
				} else {
					// "", undefined or null leads to the avatar control to crash, this is why we need the dummy src => not true anymore, now its the other way around
					this.setSrc("");
				}
				setTimeout(() => this.rerender(), 100);
			}
		});

		return EmployeeAvatar;
	});

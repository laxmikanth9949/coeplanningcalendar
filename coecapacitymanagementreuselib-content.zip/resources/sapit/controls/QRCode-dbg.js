sap.ui.define([
	"sap/ui/core/Control",
	"sapit/thirdparty/qrcode"
], function (Control) {
	"use strict";

	return Control.extend("sapit.controls.QRCode", {

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Definition
		////////////////////////////////////////////////////////////////////////////////////////////////////

		metadata: {
			library: "sapit",
			properties: {
				code: {
					type: "string",
					defaultValue: ""
				},
				size: {
					type: "integer",
					defaultValue: 256
				},
				colorLight: {
					type: "color",
					defaultValue: "#ffffff"
				},
				colorDark: {
					type: "color",
					defaultValue: "#000000"
				},
				type: {
					type: "string",
					defaultValue: sapit.QrCodeType.INACTIVE
				}
			},
			events: {
				press: {
					parameters: {
						qrCode: {
							type: "object"
						}
					}
				}
			},
			methods: {
				getQrCode: {}
			}
		},

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Lifecycle
		////////////////////////////////////////////////////////////////////////////////////////////////////

		onAfterRendering: function () {
			var domRef = document.getElementById(this.getId());
			this.qrCode = new QRCode(domRef, {
				text: this.getCode(),
				width: parseInt(this.getSize()),
				height: parseInt(this.getSize()),
				colorLight: this.getColorLight(),
				colorDark: this.getColorDark()
			});
			this._qrCode(this.getType());
		},

		///////////////////////////////////////////////////////////////////////////////////////////////////
		// helper function
		///////////////////////////////////////////////////////////////////////////////////////////////////

		_qrCode: function (sType) {
			if (sType === sapit.QrCodeType.ACTIVE) {
				//open qr code dialog
				var that = this;
				$("#" + this.getId()).addClass("cursorZoomIn");
				$("#" + this.getId()).click(function () {
					var qrCode = new sap.m.Image({
						src: this.children[1].src,
						width: "22rem"
					});
					that.firePress({
						qrCode: qrCode
					});
				});
			} else {
				$("#" + this.getId()).removeClass();
				$("#" + this.getId()).off('click');
			}
		},

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Renderer
		////////////////////////////////////////////////////////////////////////////////////////////////////

		renderer: function (oRm, oControl) {
			oRm.write("<div");
			oRm.addStyle("width", oControl.getSize() + "px");
			oRm.writeClasses();
			oRm.writeStyles();
			oRm.writeAttributeEscaped("id", oControl.getId());
			oRm.write("/>");
		},

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// methods
		////////////////////////////////////////////////////////////////////////////////////////////////////
		getQrCode: function () {
			//return qr code as image
			var src = $("#" + this.getId())[0].children[1].src;
			var qrCode = new sap.m.Image({
				src: src,
				width: "22rem"
			});
			return qrCode;
		},

		setCode: function (sCode) {
			this.setProperty("code", sCode, true);
			if (this.qrCode) {
				if (this.getCode()) {
					this.qrCode.makeCode(this.getCode());
				} else {
					this.qrCode.clear();
				}
			}
		},

		setType: function (sType) {
			this.setProperty("type", sType, true);
			this._qrCode(sType);
		}
	});
});
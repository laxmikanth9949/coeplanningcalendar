sap.ui.define([
	"sap/ui/core/XMLComposite",
	'sap/ui/model/json/JSONModel'
], function (Control, JSONModel) {
	"use strict";

	return Control.extend("sapit.controls.BuildingSearchDialog", {

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Definition
		////////////////////////////////////////////////////////////////////////////////////////////////////

		metadata: {
			library: "sapit",
			properties: {
				contentWidth: {
					type: "sap.ui.core.CSSSize",
					defaultValue: sapit.DialogWidth.SMALL

				},
				contentHeight: {
					type: "sap.ui.core.CSSSize",
					defaultValue: sapit.DialogHeight.MEDIUM
				},
				title: {
					type: "string",
					defaultValue: "Building Search"
				},
				noDataText: {
					type: "string",
					defaultValue: ""
				},
				endpoint: {
					type: "string",
					defaultValue: jQuery.sap.getModulePath("sapit") + "/sapitapi"
				},
			},
			aggregations: {},
			events: {
				select: {
					parameters: {
						building: {
							type: "string"
						}
					}
				},
				cancel: {
					parameters: {}
				}
			}

		},

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Lifecycle Methods
		////////////////////////////////////////////////////////////////////////////////////////////////////

		init: function () {
			var oDialog = sap.ui.core.Fragment.byId(this.getId(), "dialog");
			oDialog.setModel(new JSONModel());
			this._oDialog = oDialog;
		},

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Public
		////////////////////////////////////////////////////////////////////////////////////////////////////

		open: function () {
			this._oDialog.open();
			this._oDialog.getModel().setData({});
		},

		close: function () {
			this._oDialog.close();
		},

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Dialog Callbacks
		////////////////////////////////////////////////////////////////////////////////////////////////////

		onSearch: function (oEvt) {
			var sNewValue = oEvt.getParameter("value");
			this._loadBuildings(sNewValue);
		},

		onConfirm: function (oEvt) {
			var oBuilding = oEvt.getParameter("selectedContexts")[0].getObject(); // We only support singe select
			this.fireSelect({
				building: oBuilding
			});
		},

		onCancel: function () {
			this.fireCancel({});
		},

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Service Requests
		////////////////////////////////////////////////////////////////////////////////////////////////////

		_loadBuildings: function (sValue) {
			this._oDialog.setBusy(true);
			$.ajax({
					url: this.getEndpoint() + "/buildings?q=" + sValue + "&limit=50"
				})
				.done(this._loadBuildingsDone.bind(this))
				.fail(this._loadBuildingsFail.bind(this));
		},

		_loadBuildingsDone: function (oData) {
			this._oDialog.setBusy(false);
			this._oDialog.getModel().setData({
				items: oData
			});
		},

		_loadBuildingsFail: function (jqXHR, textStatus, errorThrown) {
			jQuery.sap.log.warning("Failed to fetch Buildings", "jqXHR=[" + jqXHR + "], textStatus=[" + textStatus + "], errorThrown=[" +
				errorThrown + "]", "sapit");
		}

	});

});
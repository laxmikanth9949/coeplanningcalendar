sap.ui.define([
	"sap/ui/core/Control",
	"../util/WebComponentControlBuilder"
], function (Control, WebComponentControlBuilder) {
	"use strict";

	return Control.extend("sapit.controls.EmployeeDataInfoPopover", {

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Definition
		////////////////////////////////////////////////////////////////////////////////////////////////////

		metadata: {
			library: "sapit",
			properties: {
				endpoint: {
					type: "string",
					defaultValue: "./sapit-employee-data"
				},
				functionEndpoint: {
					type: "string",
					defaultValue: "/Employees/"
				},
				mode: {
					type: "string",
					defaultValue: "compact"
				},
				user: {
					type: "object"
				},
				userId: {
					type: "string"
				},
				fetchUser: {
					type: "boolean",
					defaultValue: true
				}
			},
			events: {

			},
			methods: {
				openBy: {}
			}
		},

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Lifecycle
		////////////////////////////////////////////////////////////////////////////////////////////////////
		init: function () {
			this.builder = new WebComponentControlBuilder(this);
			this.builder
				.htmlTag("sapit-employee-data-info-popover")
				.attachDomRef()
				.attachAsIntegrationPopup()
				.property({
					name: "endpoint"
				})
				.property({
					name: "functionEndpoint",
					htmlName: "function-endpoint"
				})
				.property({
					name: "mode"
				})
				.property({
					name: "user"
				})
				.property({
					name: "fetchUser",
					boolean: true,
					htmlName: "fetch-user"
				})
				.property({
					name: "userId",
					htmlName: "user-id"
				})

				.method({
					name: "openBy",
					htmlName: "openby",
					useDomRef: true
				})

				.build();
		},

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Renderer
		////////////////////////////////////////////////////////////////////////////////////////////////////

		renderer: function (oRm, oControl) {
			//we will use the webcomponentcontrol renderer to render our preconfigured properties
			oControl.builder.render(oRm, oControl);
		}

	});
});
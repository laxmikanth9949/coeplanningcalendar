sap.ui.define([
	"sap/ui/core/Control",
	"sap/m/FormattedText",
	"sapit/util/FormattedText"
], function (Control, FormattedTextControl, FormattedText) {
	"use strict";

	return FormattedTextControl.extend("sapit.controls.LinkifyText", {
		metadata: {
			library: "sapit",
			properties: {
				text: {
					type: "string",
					defaultValue: ""
				}
			},
			aggregations: {

			},
			events: {

			}
		},

		init: function () {
			// Add style classes of sap.m.Text
			this.addStyleClass("sapMText sapMTextMaxWidth sapUiSelectable");
		},

		setText: function (sText) {
			this.setProperty("text", sText);
			var sFormattedText = this.linkifyAndEscape(sText);
			this.setProperty("htmlText", sFormattedText);
		},
		linkifyAndEscape: function (inputText) {
			try {

				var replacedText, replacePatternLeftArrow, replacePatternRightArrow, replacePattern1, replacePattern2, replacePattern3, replaceText;

				// Prevent XSS (javascript execution)
				replacePatternLeftArrow = /</gim;
				replacePatternRightArrow = />/gim;
				replaceText = inputText.replace(replacePatternLeftArrow, "&lt;");
				replaceText = replaceText.replace(replacePatternRightArrow, "&gt;");

				//URLs starting with http://, https://, or ftp://
				replacePattern1 = /(\b(https?|ftp):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/gim;
				replacedText = replaceText.replace(replacePattern1,
					'<a href="$1" style="text-decoration: none !important;color: #0070b1 !important;" target="_blank" class="">$1</a>');

				//URLs starting with "www." (without // before it, or it'd re-link the ones done above).
				replacePattern2 = /(^|[^\/])(www\.[\S]+(\b|$))/gim;
				replacedText = replacedText.replace(replacePattern2,
					'$1<a href="http://$2" style="text-decoration: none !important;color: #0070b1 !important;" target="_blank" class="">$2</a>');

				//Change email addresses to mailto:: links.
			
				
				replacePattern3 = /([A-Z0-9._+-]+@[a-zA-Z_]+?\.[a-zA-Z]{2,6})/gim;
				replacedText = replacedText.replace(replacePattern3,
					'<a class="" style="text-decoration: none !important;color: #0070b1 !important;" href="mailto:$1">$1</a>');
				
			} catch (e) {
				replacedText = "";
				jQuery.sap.log.warning("sapit.controls.LinkifyText.linkifyAndEscape could not parse text.");
			}
			return replacedText;
		},
		renderer: {}
	});
});

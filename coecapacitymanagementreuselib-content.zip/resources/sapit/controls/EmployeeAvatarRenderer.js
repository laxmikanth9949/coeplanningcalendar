sap.ui.define(["sap/m/AvatarRenderer","sap/ui/core/Renderer"],function(e,r){"use strict";var n=r.extend(e);return n},true);
//# sourceMappingURL=EmployeeAvatarRenderer.js.map
sap.ui.define([
	'sap/ui/core/Control',
	'sap/ui/core/HTML',
	'sapit/thirdparty/easymde-o.min'
], function (Control, HTML) {
	"use strict";
	return Control.extend("sapit.controls.MarkdownText", {

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Definition
		////////////////////////////////////////////////////////////////////////////////////////////////////

		metadata: {
			properties: {
				text: {
					type: "string",
					defaultValue: ""
				},
				renderType: {
					type: "string",
					defaultValue: sapit.MdRenderType.Markdown
				}
			},
			aggregations: {
				_html: {
					type: "sap.ui.core.HTML",
					multiple: false,
					visibility: "hidden"
				}
			},
			events: {

			}
		},

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Lifecycle
		////////////////////////////////////////////////////////////////////////////////////////////////////
		init: function () {
			var oHTML = new HTML(this.getId() + "-markdownHtml", {
				content: "<div style='display:none;'>" + this.getText() + "</div>",
				sanitizeContent: true
			});
			oHTML.addStyleClass("sapitMarkdownText");
			this.setAggregation("_html", oHTML);
		},

		setText: function (sValue) {
			if (sValue !== undefined) {

				this.setProperty("text", sValue, false);

				var text = EasyMDEO.prototype.markdown(sValue);

				// TODO change to switch case and outsource formatting when we add more renderTypes
				if (this.getRenderType() === sapit.MdRenderType.TextWithBr) {
					text = text.replace(new RegExp("(<.+?>)", "g"), "");
					text = text.replace(new RegExp("(\\n)", "g"), "<br />");
				}

				this.getAggregation("_html").setContent("<div>" + text + "</div>");
			}

		},

		setRenderType: function (sValue) {
			var bValid = false;
			for (var i in sapit.MdRenderType) {
				if (sValue == sapit.MdRenderType[i]) bValid = true;
			}
			if (bValid) {
				this.setProperty("renderType", sValue, false);
				this.setText(this.getText());
			}
		},

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Renderer
		////////////////////////////////////////////////////////////////////////////////////////////////////

		renderer: function (oRm, oControl) {
			oRm.write("<div class='sapitMarkdownText'>");
			//oRm.addStyle("color", "var(--sapTextColor)");
			oRm.writeStyles();

			oRm.renderControl(oControl.getAggregation("_html"));
			oRm.write("</div>");
		}
	});
});
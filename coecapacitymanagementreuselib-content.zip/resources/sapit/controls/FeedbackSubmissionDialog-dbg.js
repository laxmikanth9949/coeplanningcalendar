sap.ui.define(
  ["sap/ui/core/Control", "../util/WebComponentControlBuilder"],
  function (Control, WebComponentControlBuilder) {
    "use strict";

    return Control.extend("sapit.controls.FeedbackSubmissionDialog", {
      ////////////////////////////////////////////////////////////////////////////////////////////////////
      // Definition
      ////////////////////////////////////////////////////////////////////////////////////////////////////

      metadata: {
        library: "sapit",
        properties: {
          endpoint: {
            type: "string",
            defaultValue: jQuery.sap.getModulePath("sapit") + "/feedback_api",
          },
          topicId: {
            type: "string",
            defaultValue: "",
          },
          topicName: {
            type: "string",
            defaultValue: "",
          },
          useTopicId: {
            type: "boolean",
            defaultValue: false,
          },
          topicMatchstring: {
            type: "string",
            defaultValue: "",
          },
          showSuccessMessage: {
            type: "boolean",
            defaultValue: false,
          },
          applicationIdentifier: {
            type: "string",
            defaultValue: "",
          },
          feedbackPlatformHost: {
            type: "string",
            defaultValue:
              "https://sapit-home-prod-004.launchpad.cfapps.eu10.hana.ondemand.com/site",
          },
          channelIdentifier: {
            type: "string",
            defaultValue: "SAPIT SAPUI5 Library",
          },
        },
        events: {
          success: {
            event: {},
          },
          fail: {
            event: {},
          },
          submitFeedback: {
            event: {},
          },
        },
        methods: {
          open: {},
          close: {},
          clear: {},
        },
      },

      ////////////////////////////////////////////////////////////////////////////////////////////////////
      // Lifecycle
      ////////////////////////////////////////////////////////////////////////////////////////////////////
      init: function () {
        this.builder = new WebComponentControlBuilder(this);
        this.builder
          .htmlTag("sapit-feedback-submission-dialog")
          .attachDomRef()
          .attachAsIntegrationPopup()
          .property({
            name: "endpoint",
          })
          .property({
            name: "topicMatchstring",
            htmlName: "topic-matchstring",
          })
          .property({
            name: "feedbackPlatformHost",
            htmlName: "feedback-platform-host",
          })
          .property({
            name: "topicName",
            htmlName: "topic-name",
          })
          .property({
            name: "showSuccessMessage",
            boolean: true,
            htmlName: "show-success-message",
          })
          .property({
            name: "useTopicId",
            boolean: true,
            htmlName: "use-topic-id",
          })
          .property({
            name: "topicId",
            htmlName: "topic-id",
          })
          .property({
            name: "channelIdentifier",
            htmlName: "channel-identifier",
          })
          .property({
            name: "applicationIdentifier",
            htmlName: "application-identifier",
          })
          .method({
            name: "open",
          })
          .method({
            name: "close",
          })
          .method({
            name: "clear",
          })
          .event({
            name: "submitFeedback",
            htmlName: "submit-feedback",
          })
          .event({
            name: "success",
          })
          .event({
            name: "fail",
          })
          .build();
      },

      ////////////////////////////////////////////////////////////////////////////////////////////////////
      // Renderer
      ////////////////////////////////////////////////////////////////////////////////////////////////////

      renderer: function (oRm, oControl) {
        //we will use the webcomponentcontrol renderer to render our preconfigured properties
        oControl.builder.render(oRm, oControl);
      },
    });
  }
);

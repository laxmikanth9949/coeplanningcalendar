sap.ui.define([
	"sap/ui/core/XMLComposite"
], function (Control) {
	"use strict";

	/**
	 * **Parameters as `object`**:
	 * - **icon**: `string`, the icon of the button
	 *
	 * @module EmployeePopover
	 */
	return Control.extend("sapit.controls.EmployeePopover", {
		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Definition
		////////////////////////////////////////////////////////////////////////////////////////////////////
		metadata: {
			library: "sapit",
			properties: {
				employeeId: {
					type: "string"
				},
				showAvatar: {
					type: "boolean",
					defaultValue: false,
					bindable: "bindable"
				},
				endpoint: {
					type: "string",
					defaultValue: jQuery.sap.getModulePath("sapit") + "/sapitapi"
				}
			}

		},

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Public
		////////////////////////////////////////////////////////////////////////////////////////////////////
		init: function () {
			console.warn("sapit.controls.EmployeePopover is deprecated. Please use sapit.controls.EmployeeDataInfoPopover instead.");
			var oUserModel = new sap.ui.model.json.JSONModel();
			this.setModel(oUserModel, "employee-popover-data");
		},
		setEmployeeId: function (sId) {
			this.setProperty("employeeId", sId, true);
			this._loadUser(sId);
		},
		openBy: function (oControl) {
			// get our own popover and open it with the provided control
			if (!this.popover) {
				this.popover = sap.ui.core.Fragment.byId(this.getId(), "popover");
			}
			this.popover.setModel(this.getModel("employee-popover-data"));
			this.popover.openBy(oControl);
		},

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Protected
		////////////////////////////////////////////////////////////////////////////////////////////////////
		_loadUser: function (sUserId) {
			//load the user data and stores it into a model
			$.ajax({
					url: this.getEndpoint() + "/user-info/" + sUserId
				})
				.done(this._loadUserDone.bind(this))
				.fail(this._loadUserFail.bind(this));
		},

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Callback
		////////////////////////////////////////////////////////////////////////////////////////////////////
		_loadUserDone: function (oData) {
			this.getModel("employee-popover-data").setData(oData);
			// this is required because the popover does not update when the model changes
			if (this.popover) {
				this.popover.rerender();
			}
		},

		_loadUserFail: function (jqXHR, textStatus, errorThrown) {
			jQuery.sap.log.warning("Failed to fetch UserInfo", "jqXHR=[" + jqXHR + "], textStatus=[" + textStatus + "], errorThrown=[" +
				errorThrown + "]", "sapit");
		}

	});

});
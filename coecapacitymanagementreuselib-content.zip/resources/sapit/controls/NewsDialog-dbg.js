sap.ui.define([
	"sap/ui/core/Control",
	"../util/WebComponentControlBuilder"
], function (Control, WebComponentControlBuilder) {
	"use strict";

	return Control.extend("sapit.controls.NewsDialog", {

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Definition
		////////////////////////////////////////////////////////////////////////////////////////////////////

		metadata: {
			library: "sapit",
			properties: {
				news: {
					type: "array"
				},
				enableReadNews: {
					type: "boolean",
					defaultValue: true
				},
				endpoint: {
					type: "string"
				},
				autoFetch: {
					type: "boolean",
					defaultValue: true
				},
				channelId: {
					type: "string"
				},
				idMapping: {
					type: "string",
					defaultValue: "ID"
				}
			},
			events: {
				close: {
					event: {}
				}
			},
			methods: {
				open: {}
			}
		},

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Lifecycle
		////////////////////////////////////////////////////////////////////////////////////////////////////
		init: function () {
			this.builder = new WebComponentControlBuilder(this);
			this.builder
				.htmlTag("sapit-news-dialog")
				.attachDomRef()
				.attachAsIntegrationPopup()
				.property({
					name: "news"
				})
				.property({
					name: "endpoint"
				})
				.property({
					name: "autoFetch",
					boolean: true,
					htmlName: "auto-fetch"
				})
				.property({
					name: "channelId",
					htmlName: "channel-id"
				})
				.property({
					name: "enableReadNews",
					boolean: true,
					htmlName: "enable-read-news"
				})
				.property({
					name: "idMapping",
					htmlName: "id-mapping"
				})
				.method({
					name: "open"
				})
				.event({
					name: "close"
				})
				.build();
		},

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Renderer
		////////////////////////////////////////////////////////////////////////////////////////////////////

		renderer: function (oRm, oControl) {
			//we will use the webcomponentcontrol renderer to render our preconfigured properties
			oControl.builder.render(oRm, oControl);
		}

	});
});
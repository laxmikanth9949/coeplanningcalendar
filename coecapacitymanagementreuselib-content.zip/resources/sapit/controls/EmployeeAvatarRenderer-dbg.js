sap.ui.define(['sap/m/AvatarRenderer', 'sap/ui/core/Renderer'],
	function (AvatarRenderer, Renderer) {
		"use strict";

		var EmployeeAvatarRenderer = Renderer.extend(AvatarRenderer);

		return EmployeeAvatarRenderer;

	}, /* bExport= */ true);
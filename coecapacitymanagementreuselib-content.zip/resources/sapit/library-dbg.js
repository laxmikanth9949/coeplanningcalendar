/*!
 * ${copyright}
 */

sap.ui.define(
  ["jquery.sap.global", "./constants"],
  function (jQuery, Constants) {
    "use strict";

    //helper to load the SAPIT Webcomponents
    function loadWebcomponent(src) {
      var wc = document.createElement("script");
      wc.type = "module";
      wc.crossOrigin = "use-credentials"; // required for Safari
      wc.src = src;
      document.head.appendChild(wc);
    }

    // include script to load sapitlibrary web components
    loadWebcomponent(
      sap.ui.require.toUrl("sapit") +
        "/thirdparty/webcomponents-lib/lib/sapit-feedback-submission-dialog.js"
    );

    loadWebcomponent(
      sap.ui.require.toUrl("sapit") +
        "/thirdparty/webcomponents-lib/lib/sapit-news-dialog.js"
    );

    loadWebcomponent(
      sap.ui.require.toUrl("sapit") +
        "/thirdparty/webcomponents-lib/lib/sapit-employee-data-info-popover.js"
    );

    loadWebcomponent(
      sap.ui.require.toUrl("sapit") +
        "/thirdparty/webcomponents-lib/lib/sapit-employee-data-search-dialog.js"
    );

    // delegate further initialization of this library to the Core
    sap.ui.getCore().initLibrary({
      name: "sapit",
      version: "1.0.0",
      dependencies: ["sap.ui.core", "sap.m"],
      types: [],
      interfaces: [],
      controls: [
        "sapit.controls.Example",
        "sapit.controls.EmployeeAvatar",
        "sapit.controls.EmployeeSearchDialog",
        "sapit.controls.UserSearchDialog",
        "sapit.controls.EmployeeDataSearchDialog",
        "sapit.controls.EmployeePopover",
        "sapit.controls.UserPopover",
        "sapit.controls.EmployeeDataInfoPopover",
        "sapit.controls.QRCode",
        "sapit.controls.MarkdownEditor",
        "sapit.controls.MarkdownText",
        "sapit.controls.BuildingSearchDialog",
        "sapit.controls.LinkifyText",
        "sapit.controls.FeedbackDialog",
        "sapit.controls.FeedbackSubmissionDialog",
        "sapit.controls.SystemNewsDialog",
        "sapit.controls.NewsDialog",
      ],
      elements: [
        "sapit.util.UsageTracking",
        "sapit.util.VizFrameBuilder",
        "sapit.util.ITDirectTicketURLBuilder",
        "sapit.util.FormattedText",
        "sapit.util.cFLPAdapter",
      ],
    });

    /* eslint-disable no-undef */
    // Assign Constants to namespace
    //TODO: JB - why dont we use the types property for that?
    jQuery.extend(sapit, Constants);

    return sapit;
  },
  /* bExport= */
  false
);

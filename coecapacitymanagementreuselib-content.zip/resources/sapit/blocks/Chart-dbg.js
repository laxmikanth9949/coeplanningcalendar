sap.ui.define(["sap/uxap/BlockBase"], function(BlockBase) {
	return BlockBase.extend("sapit.blocks.Chart", {
		metadata: {
		properties: {
				"charts": {
					bindable: true
				}
			}
		}
	});
}, true);
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sapit/util/VizFrameBuilder",
	"sap/ui/model/Filter"
], function(Controller, VizFrameBuilder, Filter) {
	"use strict";

	return Controller.extend("sapit.blocks.ChartController", {

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Lifecycle
		////////////////////////////////////////////////////////////////////////////////////////////////////

		onInit: function() {
			var oVizFrame = this.getView().byId("vizFrame");
			var oPopOver = this.getView().byId("popOver");
			oPopOver.connect(oVizFrame.getVizUid());

		},

		onAfterRendering: function() {
			if (!this.getView().getModel("filter"))
				this.getView().byId("dimensionFilter").setVisible(false);

			var oChartModel = this.oParentBlock.getModel("chart");
			if (oChartModel && !this.loaded) {
				var oChart = oChartModel.getProperty("/charts/0");
				this._updateChart(oChart);
				this.loaded = true;
			}
		},

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// UI Callbacks
		////////////////////////////////////////////////////////////////////////////////////////////////////
		onRefresh: function() {
			this._updateChart();
		},

		onChartChange: function(oEvt) {
			this._updateChart();
		},

		onFilterChange: function(oEvt) {
			this._updateChart();
		},

		showDimensionFilter: function() {
			return false;
		},

		////////////////////////////////////////////////////////////////////////////////////////////////////
		// Implemenation
		////////////////////////////////////////////////////////////////////////////////////////////////////

		_updateChart: function() {

			//Chart
			var sPath = this.getView().byId("chartSelect").getSelectedItem().getBindingContext("chart").getPath();
			var oChart = this.getView().getModel("chart").getProperty(sPath);

			// References
			var oVizFrame = this.getView().byId("vizFrame");
			var sText = this.getView().byId("dimensionFilter").getSelectedItem() ? this.getView().byId("dimensionFilter").getSelectedItem().getText() :
				"";

			// Merge properties
			var oDefaultProperties = this.getView().getModel("chart").getProperty("/properties");
			var oTitleProperty = {
				title: {
					text: sText + " " + oChart.name,
					visible: true
				}
			};
			var oProperties = jQuery.extend(true, oTitleProperty, oDefaultProperties, oChart.properties);

			// Merge filters
			var aFilters = [];
			var sKey = this.getView().byId("dimensionFilter").getSelectedKey();
			if (sKey && sKey !== "") {
				var sFilterColumn = this.getView().getModel("filter").getProperty("/column");
				var oFilter = new Filter(sFilterColumn, sap.ui.model.FilterOperator.EQ, sKey);
				aFilters.push(oFilter);
			}

			new VizFrameBuilder()
				.bindData("analytics", oChart.path)
				.setVizType(oChart.vizType)
				.setProperties(oProperties)
				.setMeasures(oChart.measures)
				.setDimensions(oChart.dimensions)
				.setFilters(aFilters)
				.updateVizFrame(oVizFrame);

		}

	});
});
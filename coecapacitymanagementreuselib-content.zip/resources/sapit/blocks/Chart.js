sap.ui.define(["sap/uxap/BlockBase"],function(e){return e.extend("sapit.blocks.Chart",{metadata:{properties:{charts:{bindable:true}}}})},true);
//# sourceMappingURL=Chart.js.map
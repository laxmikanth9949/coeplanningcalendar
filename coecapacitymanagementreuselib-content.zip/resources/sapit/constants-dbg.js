sap.ui.define([], function () {
	return {
		DialogWidth: {
			SMALL: "25rem",
			MEDIUM: "40rem",
			LARGE: "60rem"
		},

		DialogHeight: {
			SMALL: "25rem",
			MEDIUM: "30rem",
			LARGE: "50rem"
		},

		QrCodeType: {
			ACTIVE: "Active",
			INACTIVE: "Inactive"
		},

		MdRenderType: {
			Markdown: "Markdown",
			TextWithBr: "TextWithBr"
		}
	};
});
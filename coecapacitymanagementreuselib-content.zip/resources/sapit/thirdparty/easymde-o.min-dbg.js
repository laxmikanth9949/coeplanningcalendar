/**
 * easymde v2.6.0
 * Copyright Jeroen Akkerman
 * @link 
 * @license MIT
 */
! function (e) {
	window.EasyMDEO = e();
}(function () {
	return function o(a, l, s) {
		function u(t, e) {
			if (!l[t]) {
				if (!a[t]) {
					var n = "function" == typeof require && require;
					if (!e && n) return n(t, !0);
					if (c) return c(t, !0);
					var r = new Error("Cannot find module '" + t + "'");
					throw r.code = "MODULE_NOT_FOUND", r
				}
				var i = l[t] = {
					exports: {}
				};
				a[t][0].call(i.exports, function (e) {
					return u(a[t][1][e] || e)
				}, i, i.exports, o, a, l, s)
			}
			return l[t].exports
		}
		for (var c = "function" == typeof require && require, e = 0; e < s.length; e++) u(s[e]);
		return u
	}({
		1: [function (e, t, n) {
			"use strict";
			n.byteLength = function (e) {
				var t = d(e),
					n = t[0],
					r = t[1];
				return 3 * (n + r) / 4 - r
			}, n.toByteArray = function (e) {
				for (var t, n = d(e), r = n[0], i = n[1], o = new f((u = r, c = i, 3 * (u + c) / 4 - c)), a = 0, l = 0 < i ? r - 4 : r, s = 0; s <
					l; s += 4) t = h[e.charCodeAt(s)] << 18 | h[e.charCodeAt(s + 1)] << 12 | h[e.charCodeAt(s + 2)] << 6 | h[e.charCodeAt(s + 3)], o[
					a++] = t >> 16 & 255, o[a++] = t >> 8 & 255, o[a++] = 255 & t;
				var u, c;
				2 === i && (t = h[e.charCodeAt(s)] << 2 | h[e.charCodeAt(s + 1)] >> 4, o[a++] = 255 & t);
				1 === i && (t = h[e.charCodeAt(s)] << 10 | h[e.charCodeAt(s + 1)] << 4 | h[e.charCodeAt(s + 2)] >> 2, o[a++] = t >> 8 & 255, o[a++] =
					255 & t);
				return o
			}, n.fromByteArray = function (e) {
				for (var t, n = e.length, r = n % 3, i = [], o = 0, a = n - r; o < a; o += 16383) i.push(s(e, o, a < o + 16383 ? a : o + 16383));
				1 === r ? (t = e[n - 1], i.push(l[t >> 2] + l[t << 4 & 63] + "==")) : 2 === r && (t = (e[n - 2] << 8) + e[n - 1], i.push(l[t >>
					10] + l[t >> 4 & 63] + l[t << 2 & 63] + "="));
				return i.join("")
			};
			for (var l = [], h = [], f = "undefined" != typeof Uint8Array ? Uint8Array : Array, r =
					"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", i = 0, o = r.length; i < o; ++i) l[i] = r[i], h[r.charCodeAt(
				i)] = i;

			function d(e) {
				var t = e.length;
				if (0 < t % 4) throw new Error("Invalid string. Length must be a multiple of 4");
				var n = e.indexOf("=");
				return -1 === n && (n = t), [n, n === t ? 0 : 4 - n % 4]
			}

			function s(e, t, n) {
				for (var r, i, o = [], a = t; a < n; a += 3) r = (e[a] << 16 & 16711680) + (e[a + 1] << 8 & 65280) + (255 & e[a + 2]), o.push(l[(i =
					r) >> 18 & 63] + l[i >> 12 & 63] + l[i >> 6 & 63] + l[63 & i]);
				return o.join("")
			}
			h["-".charCodeAt(0)] = 62, h["_".charCodeAt(0)] = 63
		}, {}],
		2: [function (e, t, n) {}, {}],
		3: [function (e, t, R) {
			(function (h) {
				"use strict";
				var r = e("base64-js"),
					o = e("ieee754");
				R.Buffer = h, R.SlowBuffer = function (e) {
					+e != e && (e = 0);
					return h.alloc(+e)
				}, R.INSPECT_MAX_BYTES = 50;
				var n = 2147483647;

				function a(e) {
					if (n < e) throw new RangeError('The value "' + e + '" is invalid for option "size"');
					var t = new Uint8Array(e);
					return t.__proto__ = h.prototype, t
				}

				function h(e, t, n) {
					if ("number" != typeof e) return i(e, t, n);
					if ("string" == typeof t) throw new TypeError('The "string" argument must be of type string. Received type number');
					return s(e)
				}

				function i(e, t, n) {
					if ("string" == typeof e) return function (e, t) {
						"string" == typeof t && "" !== t || (t = "utf8");
						if (!h.isEncoding(t)) throw new TypeError("Unknown encoding: " + t);
						var n = 0 | f(e, t),
							r = a(n),
							i = r.write(e, t);
						i !== n && (r = r.slice(0, i));
						return r
					}(e, t);
					if (ArrayBuffer.isView(e)) return u(e);
					if (null == e) throw TypeError(
						"The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof e);
					if (I(e, ArrayBuffer) || e && I(e.buffer, ArrayBuffer)) return function (e, t, n) {
						if (t < 0 || e.byteLength < t) throw new RangeError('"offset" is outside of buffer bounds');
						if (e.byteLength < t + (n || 0)) throw new RangeError('"length" is outside of buffer bounds');
						var r;
						r = void 0 === t && void 0 === n ? new Uint8Array(e) : void 0 === n ? new Uint8Array(e, t) : new Uint8Array(e, t, n);
						return r.__proto__ = h.prototype, r
					}(e, t, n);
					if ("number" == typeof e) throw new TypeError('The "value" argument must not be of type number. Received type number');
					var r = e.valueOf && e.valueOf();
					if (null != r && r !== e) return h.from(r, t, n);
					var i = function (e) {
						if (h.isBuffer(e)) {
							var t = 0 | c(e.length),
								n = a(t);
							return 0 === n.length || e.copy(n, 0, 0, t), n
						}
						if (void 0 !== e.length) return "number" != typeof e.length || B(e.length) ? a(0) : u(e);
						if ("Buffer" === e.type && Array.isArray(e.data)) return u(e.data)
					}(e);
					if (i) return i;
					if ("undefined" != typeof Symbol && null != Symbol.toPrimitive && "function" == typeof e[Symbol.toPrimitive]) return h.from(e[
						Symbol.toPrimitive]("string"), t, n);
					throw new TypeError(
						"The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof e)
				}

				function l(e) {
					if ("number" != typeof e) throw new TypeError('"size" argument must be of type number');
					if (e < 0) throw new RangeError('The value "' + e + '" is invalid for option "size"')
				}

				function s(e) {
					return l(e), a(e < 0 ? 0 : 0 | c(e))
				}

				function u(e) {
					for (var t = e.length < 0 ? 0 : 0 | c(e.length), n = a(t), r = 0; r < t; r += 1) n[r] = 255 & e[r];
					return n
				}

				function c(e) {
					if (n <= e) throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + n.toString(16) + " bytes");
					return 0 | e
				}

				function f(e, t) {
					if (h.isBuffer(e)) return e.length;
					if (ArrayBuffer.isView(e) || I(e, ArrayBuffer)) return e.byteLength;
					if ("string" != typeof e) throw new TypeError(
						'The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof e);
					var n = e.length,
						r = 2 < arguments.length && !0 === arguments[2];
					if (!r && 0 === n) return 0;
					for (var i = !1;;) switch (t) {
					case "ascii":
					case "latin1":
					case "binary":
						return n;
					case "utf8":
					case "utf-8":
						return D(e).length;
					case "ucs2":
					case "ucs-2":
					case "utf16le":
					case "utf-16le":
						return 2 * n;
					case "hex":
						return n >>> 1;
					case "base64":
						return F(e).length;
					default:
						if (i) return r ? -1 : D(e).length;
						t = ("" + t).toLowerCase(), i = !0
					}
				}

				function d(e, t, n) {
					var r = e[t];
					e[t] = e[n], e[n] = r
				}

				function p(e, t, n, r, i) {
					if (0 === e.length) return -1;
					if ("string" == typeof n ? (r = n, n = 0) : 2147483647 < n ? n = 2147483647 : n < -2147483648 && (n = -2147483648), B(n = +n) &&
						(n = i ? 0 : e.length - 1), n < 0 && (n = e.length + n), n >= e.length) {
						if (i) return -1;
						n = e.length - 1
					} else if (n < 0) {
						if (!i) return -1;
						n = 0
					}
					if ("string" == typeof t && (t = h.from(t, r)), h.isBuffer(t)) return 0 === t.length ? -1 : m(e, t, n, r, i);
					if ("number" == typeof t) return t &= 255, "function" == typeof Uint8Array.prototype.indexOf ? i ? Uint8Array.prototype.indexOf.call(
						e, t, n) : Uint8Array.prototype.lastIndexOf.call(e, t, n) : m(e, [t], n, r, i);
					throw new TypeError("val must be string, number or Buffer")
				}

				function m(e, t, n, r, i) {
					var o, a = 1,
						l = e.length,
						s = t.length;
					if (void 0 !== r && ("ucs2" === (r = String(r).toLowerCase()) || "ucs-2" === r || "utf16le" === r || "utf-16le" === r)) {
						if (e.length < 2 || t.length < 2) return -1;
						l /= a = 2, s /= 2, n /= 2
					}

					function u(e, t) {
						return 1 === a ? e[t] : e.readUInt16BE(t * a)
					}
					if (i) {
						var c = -1;
						for (o = n; o < l; o++)
							if (u(e, o) === u(t, -1 === c ? 0 : o - c)) {
								if (-1 === c && (c = o), o - c + 1 === s) return c * a
							} else -1 !== c && (o -= o - c), c = -1
					} else
						for (l < n + s && (n = l - s), o = n; 0 <= o; o--) {
							for (var h = !0, f = 0; f < s; f++)
								if (u(e, o + f) !== u(t, f)) {
									h = !1;
									break
								}
							if (h) return o
						}
					return -1
				}

				function g(e, t, n, r) {
					n = Number(n) || 0;
					var i = e.length - n;
					r ? i < (r = Number(r)) && (r = i) : r = i;
					var o = t.length;
					o / 2 < r && (r = o / 2);
					for (var a = 0; a < r; ++a) {
						var l = parseInt(t.substr(2 * a, 2), 16);
						if (B(l)) return a;
						e[n + a] = l
					}
					return a
				}

				function v(e, t, n, r) {
					return O(function (e) {
						for (var t = [], n = 0; n < e.length; ++n) t.push(255 & e.charCodeAt(n));
						return t
					}(t), e, n, r)
				}

				function y(e, t, n) {
					return 0 === t && n === e.length ? r.fromByteArray(e) : r.fromByteArray(e.slice(t, n))
				}

				function x(e, t, n) {
					n = Math.min(e.length, n);
					for (var r = [], i = t; i < n;) {
						var o, a, l, s, u = e[i],
							c = null,
							h = 239 < u ? 4 : 223 < u ? 3 : 191 < u ? 2 : 1;
						if (i + h <= n) switch (h) {
						case 1:
							u < 128 && (c = u);
							break;
						case 2:
							128 == (192 & (o = e[i + 1])) && 127 < (s = (31 & u) << 6 | 63 & o) && (c = s);
							break;
						case 3:
							o = e[i + 1], a = e[i + 2], 128 == (192 & o) && 128 == (192 & a) && 2047 < (s = (15 & u) << 12 | (63 & o) << 6 | 63 & a) && (
								s < 55296 || 57343 < s) && (c = s);
							break;
						case 4:
							o = e[i + 1], a = e[i + 2], l = e[i + 3], 128 == (192 & o) && 128 == (192 & a) && 128 == (192 & l) && 65535 < (s = (15 & u) <<
								18 | (63 & o) << 12 | (63 & a) << 6 | 63 & l) && s < 1114112 && (c = s)
						}
						null === c ? (c = 65533, h = 1) : 65535 < c && (c -= 65536, r.push(c >>> 10 & 1023 | 55296), c = 56320 | 1023 & c), r.push(c),
							i += h
					}
					return function (e) {
						var t = e.length;
						if (t <= b) return String.fromCharCode.apply(String, e);
						var n = "",
							r = 0;
						for (; r < t;) n += String.fromCharCode.apply(String, e.slice(r, r += b));
						return n
					}(r)
				}
				R.kMaxLength = n, (h.TYPED_ARRAY_SUPPORT = function () {
					try {
						var e = new Uint8Array(1);
						return e.__proto__ = {
							__proto__: Uint8Array.prototype,
							foo: function () {
								return 42
							}
						}, 42 === e.foo()
					} catch (e) {
						return !1
					}
				}()) || "undefined" == typeof console || "function" != typeof console.error || console.error(
					"This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."
				), Object.defineProperty(h.prototype, "parent", {
					enumerable: !0,
					get: function () {
						if (h.isBuffer(this)) return this.buffer
					}
				}), Object.defineProperty(h.prototype, "offset", {
					enumerable: !0,
					get: function () {
						if (h.isBuffer(this)) return this.byteOffset
					}
				}), "undefined" != typeof Symbol && null != Symbol.species && h[Symbol.species] === h && Object.defineProperty(h, Symbol.species, {
					value: null,
					configurable: !0,
					enumerable: !1,
					writable: !1
				}), h.poolSize = 8192, h.from = function (e, t, n) {
					return i(e, t, n)
				}, h.prototype.__proto__ = Uint8Array.prototype, h.__proto__ = Uint8Array, h.alloc = function (e, t, n) {
					return i = t, o = n, l(r = e), r <= 0 ? a(r) : void 0 !== i ? "string" == typeof o ? a(r).fill(i, o) : a(r).fill(i) : a(r);
					var r, i, o
				}, h.allocUnsafe = function (e) {
					return s(e)
				}, h.allocUnsafeSlow = function (e) {
					return s(e)
				}, h.isBuffer = function (e) {
					return null != e && !0 === e._isBuffer && e !== h.prototype
				}, h.compare = function (e, t) {
					if (I(e, Uint8Array) && (e = h.from(e, e.offset, e.byteLength)), I(t, Uint8Array) && (t = h.from(t, t.offset, t.byteLength)), !
						h.isBuffer(e) || !h.isBuffer(t)) throw new TypeError('The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array');
					if (e === t) return 0;
					for (var n = e.length, r = t.length, i = 0, o = Math.min(n, r); i < o; ++i)
						if (e[i] !== t[i]) {
							n = e[i], r = t[i];
							break
						}
					return n < r ? -1 : r < n ? 1 : 0
				}, h.isEncoding = function (e) {
					switch (String(e).toLowerCase()) {
					case "hex":
					case "utf8":
					case "utf-8":
					case "ascii":
					case "latin1":
					case "binary":
					case "base64":
					case "ucs2":
					case "ucs-2":
					case "utf16le":
					case "utf-16le":
						return !0;
					default:
						return !1
					}
				}, h.concat = function (e, t) {
					if (!Array.isArray(e)) throw new TypeError('"list" argument must be an Array of Buffers');
					if (0 === e.length) return h.alloc(0);
					var n;
					if (void 0 === t)
						for (n = t = 0; n < e.length; ++n) t += e[n].length;
					var r = h.allocUnsafe(t),
						i = 0;
					for (n = 0; n < e.length; ++n) {
						var o = e[n];
						if (I(o, Uint8Array) && (o = h.from(o)), !h.isBuffer(o)) throw new TypeError('"list" argument must be an Array of Buffers');
						o.copy(r, i), i += o.length
					}
					return r
				}, h.byteLength = f, h.prototype._isBuffer = !0, h.prototype.swap16 = function () {
					var e = this.length;
					if (e % 2 != 0) throw new RangeError("Buffer size must be a multiple of 16-bits");
					for (var t = 0; t < e; t += 2) d(this, t, t + 1);
					return this
				}, h.prototype.swap32 = function () {
					var e = this.length;
					if (e % 4 != 0) throw new RangeError("Buffer size must be a multiple of 32-bits");
					for (var t = 0; t < e; t += 4) d(this, t, t + 3), d(this, t + 1, t + 2);
					return this
				}, h.prototype.swap64 = function () {
					var e = this.length;
					if (e % 8 != 0) throw new RangeError("Buffer size must be a multiple of 64-bits");
					for (var t = 0; t < e; t += 8) d(this, t, t + 7), d(this, t + 1, t + 6), d(this, t + 2, t + 5), d(this, t + 3, t + 4);
					return this
				}, h.prototype.toLocaleString = h.prototype.toString = function () {
					var e = this.length;
					return 0 === e ? "" : 0 === arguments.length ? x(this, 0, e) : function (e, t, n) {
						var r = !1;
						if ((void 0 === t || t < 0) && (t = 0), t > this.length) return "";
						if ((void 0 === n || n > this.length) && (n = this.length), n <= 0) return "";
						if ((n >>>= 0) <= (t >>>= 0)) return "";
						for (e || (e = "utf8");;) switch (e) {
						case "hex":
							return C(this, t, n);
						case "utf8":
						case "utf-8":
							return x(this, t, n);
						case "ascii":
							return w(this, t, n);
						case "latin1":
						case "binary":
							return k(this, t, n);
						case "base64":
							return y(this, t, n);
						case "ucs2":
						case "ucs-2":
						case "utf16le":
						case "utf-16le":
							return S(this, t, n);
						default:
							if (r) throw new TypeError("Unknown encoding: " + e);
							e = (e + "").toLowerCase(), r = !0
						}
					}.apply(this, arguments)
				}, h.prototype.equals = function (e) {
					if (!h.isBuffer(e)) throw new TypeError("Argument must be a Buffer");
					return this === e || 0 === h.compare(this, e)
				}, h.prototype.inspect = function () {
					var e = "",
						t = R.INSPECT_MAX_BYTES;
					return e = this.toString("hex", 0, t).replace(/(.{2})/g, "$1 ").trim(), this.length > t && (e += " ... "), "<Buffer " + e + ">"
				}, h.prototype.compare = function (e, t, n, r, i) {
					if (I(e, Uint8Array) && (e = h.from(e, e.offset, e.byteLength)), !h.isBuffer(e)) throw new TypeError(
						'The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof e);
					if (void 0 === t && (t = 0), void 0 === n && (n = e ? e.length : 0), void 0 === r && (r = 0), void 0 === i && (i = this.length),
						t < 0 || n > e.length || r < 0 || i > this.length) throw new RangeError("out of range index");
					if (i <= r && n <= t) return 0;
					if (i <= r) return -1;
					if (n <= t) return 1;
					if (this === e) return 0;
					for (var o = (i >>>= 0) - (r >>>= 0), a = (n >>>= 0) - (t >>>= 0), l = Math.min(o, a), s = this.slice(r, i), u = e.slice(t, n),
							c = 0; c < l; ++c)
						if (s[c] !== u[c]) {
							o = s[c], a = u[c];
							break
						}
					return o < a ? -1 : a < o ? 1 : 0
				}, h.prototype.includes = function (e, t, n) {
					return -1 !== this.indexOf(e, t, n)
				}, h.prototype.indexOf = function (e, t, n) {
					return p(this, e, t, n, !0)
				}, h.prototype.lastIndexOf = function (e, t, n) {
					return p(this, e, t, n, !1)
				}, h.prototype.write = function (e, t, n, r) {
					if (void 0 === t) r = "utf8", n = this.length, t = 0;
					else if (void 0 === n && "string" == typeof t) r = t, n = this.length, t = 0;
					else {
						if (!isFinite(t)) throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported");
						t >>>= 0, isFinite(n) ? (n >>>= 0, void 0 === r && (r = "utf8")) : (r = n, n = void 0)
					}
					var i = this.length - t;
					if ((void 0 === n || i < n) && (n = i), 0 < e.length && (n < 0 || t < 0) || t > this.length) throw new RangeError(
						"Attempt to write outside buffer bounds");
					r || (r = "utf8");
					for (var o, a, l, s, u, c, h, f, d, p = !1;;) switch (r) {
					case "hex":
						return g(this, e, t, n);
					case "utf8":
					case "utf-8":
						return f = t, d = n, O(D(e, (h = this).length - f), h, f, d);
					case "ascii":
						return v(this, e, t, n);
					case "latin1":
					case "binary":
						return v(this, e, t, n);
					case "base64":
						return s = this, u = t, c = n, O(F(e), s, u, c);
					case "ucs2":
					case "ucs-2":
					case "utf16le":
					case "utf-16le":
						return a = t, l = n, O(function (e, t) {
							for (var n, r, i, o = [], a = 0; a < e.length && !((t -= 2) < 0); ++a) n = e.charCodeAt(a), r = n >> 8, i = n % 256, o.push(
								i), o.push(r);
							return o
						}(e, (o = this).length - a), o, a, l);
					default:
						if (p) throw new TypeError("Unknown encoding: " + r);
						r = ("" + r).toLowerCase(), p = !0
					}
				}, h.prototype.toJSON = function () {
					return {
						type: "Buffer",
						data: Array.prototype.slice.call(this._arr || this, 0)
					}
				};
				var b = 4096;

				function w(e, t, n) {
					var r = "";
					n = Math.min(e.length, n);
					for (var i = t; i < n; ++i) r += String.fromCharCode(127 & e[i]);
					return r
				}

				function k(e, t, n) {
					var r = "";
					n = Math.min(e.length, n);
					for (var i = t; i < n; ++i) r += String.fromCharCode(e[i]);
					return r
				}

				function C(e, t, n) {
					var r = e.length;
					(!t || t < 0) && (t = 0), (!n || n < 0 || r < n) && (n = r);
					for (var i = "", o = t; o < n; ++o) i += N(e[o]);
					return i
				}

				function S(e, t, n) {
					for (var r = e.slice(t, n), i = "", o = 0; o < r.length; o += 2) i += String.fromCharCode(r[o] + 256 * r[o + 1]);
					return i
				}

				function L(e, t, n) {
					if (e % 1 != 0 || e < 0) throw new RangeError("offset is not uint");
					if (n < e + t) throw new RangeError("Trying to access beyond buffer length")
				}

				function T(e, t, n, r, i, o) {
					if (!h.isBuffer(e)) throw new TypeError('"buffer" argument must be a Buffer instance');
					if (i < t || t < o) throw new RangeError('"value" argument is out of bounds');
					if (n + r > e.length) throw new RangeError("Index out of range")
				}

				function M(e, t, n, r, i, o) {
					if (n + r > e.length) throw new RangeError("Index out of range");
					if (n < 0) throw new RangeError("Index out of range")
				}

				function A(e, t, n, r, i) {
					return t = +t, n >>>= 0, i || M(e, 0, n, 4), o.write(e, t, n, r, 23, 4), n + 4
				}

				function E(e, t, n, r, i) {
					return t = +t, n >>>= 0, i || M(e, 0, n, 8), o.write(e, t, n, r, 52, 8), n + 8
				}
				h.prototype.slice = function (e, t) {
					var n = this.length;
					(e = ~~e) < 0 ? (e += n) < 0 && (e = 0) : n < e && (e = n), (t = void 0 === t ? n : ~~t) < 0 ? (t += n) < 0 && (t = 0) : n < t &&
						(t = n), t < e && (t = e);
					var r = this.subarray(e, t);
					return r.__proto__ = h.prototype, r
				}, h.prototype.readUIntLE = function (e, t, n) {
					e >>>= 0, t >>>= 0, n || L(e, t, this.length);
					for (var r = this[e], i = 1, o = 0; ++o < t && (i *= 256);) r += this[e + o] * i;
					return r
				}, h.prototype.readUIntBE = function (e, t, n) {
					e >>>= 0, t >>>= 0, n || L(e, t, this.length);
					for (var r = this[e + --t], i = 1; 0 < t && (i *= 256);) r += this[e + --t] * i;
					return r
				}, h.prototype.readUInt8 = function (e, t) {
					return e >>>= 0, t || L(e, 1, this.length), this[e]
				}, h.prototype.readUInt16LE = function (e, t) {
					return e >>>= 0, t || L(e, 2, this.length), this[e] | this[e + 1] << 8
				}, h.prototype.readUInt16BE = function (e, t) {
					return e >>>= 0, t || L(e, 2, this.length), this[e] << 8 | this[e + 1]
				}, h.prototype.readUInt32LE = function (e, t) {
					return e >>>= 0, t || L(e, 4, this.length), (this[e] | this[e + 1] << 8 | this[e + 2] << 16) + 16777216 * this[e + 3]
				}, h.prototype.readUInt32BE = function (e, t) {
					return e >>>= 0, t || L(e, 4, this.length), 16777216 * this[e] + (this[e + 1] << 16 | this[e + 2] << 8 | this[e + 3])
				}, h.prototype.readIntLE = function (e, t, n) {
					e >>>= 0, t >>>= 0, n || L(e, t, this.length);
					for (var r = this[e], i = 1, o = 0; ++o < t && (i *= 256);) r += this[e + o] * i;
					return (i *= 128) <= r && (r -= Math.pow(2, 8 * t)), r
				}, h.prototype.readIntBE = function (e, t, n) {
					e >>>= 0, t >>>= 0, n || L(e, t, this.length);
					for (var r = t, i = 1, o = this[e + --r]; 0 < r && (i *= 256);) o += this[e + --r] * i;
					return (i *= 128) <= o && (o -= Math.pow(2, 8 * t)), o
				}, h.prototype.readInt8 = function (e, t) {
					return e >>>= 0, t || L(e, 1, this.length), 128 & this[e] ? -1 * (255 - this[e] + 1) : this[e]
				}, h.prototype.readInt16LE = function (e, t) {
					e >>>= 0, t || L(e, 2, this.length);
					var n = this[e] | this[e + 1] << 8;
					return 32768 & n ? 4294901760 | n : n
				}, h.prototype.readInt16BE = function (e, t) {
					e >>>= 0, t || L(e, 2, this.length);
					var n = this[e + 1] | this[e] << 8;
					return 32768 & n ? 4294901760 | n : n
				}, h.prototype.readInt32LE = function (e, t) {
					return e >>>= 0, t || L(e, 4, this.length), this[e] | this[e + 1] << 8 | this[e + 2] << 16 | this[e + 3] << 24
				}, h.prototype.readInt32BE = function (e, t) {
					return e >>>= 0, t || L(e, 4, this.length), this[e] << 24 | this[e + 1] << 16 | this[e + 2] << 8 | this[e + 3]
				}, h.prototype.readFloatLE = function (e, t) {
					return e >>>= 0, t || L(e, 4, this.length), o.read(this, e, !0, 23, 4)
				}, h.prototype.readFloatBE = function (e, t) {
					return e >>>= 0, t || L(e, 4, this.length), o.read(this, e, !1, 23, 4)
				}, h.prototype.readDoubleLE = function (e, t) {
					return e >>>= 0, t || L(e, 8, this.length), o.read(this, e, !0, 52, 8)
				}, h.prototype.readDoubleBE = function (e, t) {
					return e >>>= 0, t || L(e, 8, this.length), o.read(this, e, !1, 52, 8)
				}, h.prototype.writeUIntLE = function (e, t, n, r) {
					(e = +e, t >>>= 0, n >>>= 0, r) || T(this, e, t, n, Math.pow(2, 8 * n) - 1, 0);
					var i = 1,
						o = 0;
					for (this[t] = 255 & e; ++o < n && (i *= 256);) this[t + o] = e / i & 255;
					return t + n
				}, h.prototype.writeUIntBE = function (e, t, n, r) {
					(e = +e, t >>>= 0, n >>>= 0, r) || T(this, e, t, n, Math.pow(2, 8 * n) - 1, 0);
					var i = n - 1,
						o = 1;
					for (this[t + i] = 255 & e; 0 <= --i && (o *= 256);) this[t + i] = e / o & 255;
					return t + n
				}, h.prototype.writeUInt8 = function (e, t, n) {
					return e = +e, t >>>= 0, n || T(this, e, t, 1, 255, 0), this[t] = 255 & e, t + 1
				}, h.prototype.writeUInt16LE = function (e, t, n) {
					return e = +e, t >>>= 0, n || T(this, e, t, 2, 65535, 0), this[t] = 255 & e, this[t + 1] = e >>> 8, t + 2
				}, h.prototype.writeUInt16BE = function (e, t, n) {
					return e = +e, t >>>= 0, n || T(this, e, t, 2, 65535, 0), this[t] = e >>> 8, this[t + 1] = 255 & e, t + 2
				}, h.prototype.writeUInt32LE = function (e, t, n) {
					return e = +e, t >>>= 0, n || T(this, e, t, 4, 4294967295, 0), this[t + 3] = e >>> 24, this[t + 2] = e >>> 16, this[t + 1] = e >>>
						8, this[t] = 255 & e, t + 4
				}, h.prototype.writeUInt32BE = function (e, t, n) {
					return e = +e, t >>>= 0, n || T(this, e, t, 4, 4294967295, 0), this[t] = e >>> 24, this[t + 1] = e >>> 16, this[t + 2] = e >>>
						8, this[t + 3] = 255 & e, t + 4
				}, h.prototype.writeIntLE = function (e, t, n, r) {
					if (e = +e, t >>>= 0, !r) {
						var i = Math.pow(2, 8 * n - 1);
						T(this, e, t, n, i - 1, -i)
					}
					var o = 0,
						a = 1,
						l = 0;
					for (this[t] = 255 & e; ++o < n && (a *= 256);) e < 0 && 0 === l && 0 !== this[t + o - 1] && (l = 1), this[t + o] = (e / a >> 0) -
						l & 255;
					return t + n
				}, h.prototype.writeIntBE = function (e, t, n, r) {
					if (e = +e, t >>>= 0, !r) {
						var i = Math.pow(2, 8 * n - 1);
						T(this, e, t, n, i - 1, -i)
					}
					var o = n - 1,
						a = 1,
						l = 0;
					for (this[t + o] = 255 & e; 0 <= --o && (a *= 256);) e < 0 && 0 === l && 0 !== this[t + o + 1] && (l = 1), this[t + o] = (e / a >>
						0) - l & 255;
					return t + n
				}, h.prototype.writeInt8 = function (e, t, n) {
					return e = +e, t >>>= 0, n || T(this, e, t, 1, 127, -128), e < 0 && (e = 255 + e + 1), this[t] = 255 & e, t + 1
				}, h.prototype.writeInt16LE = function (e, t, n) {
					return e = +e, t >>>= 0, n || T(this, e, t, 2, 32767, -32768), this[t] = 255 & e, this[t + 1] = e >>> 8, t + 2
				}, h.prototype.writeInt16BE = function (e, t, n) {
					return e = +e, t >>>= 0, n || T(this, e, t, 2, 32767, -32768), this[t] = e >>> 8, this[t + 1] = 255 & e, t + 2
				}, h.prototype.writeInt32LE = function (e, t, n) {
					return e = +e, t >>>= 0, n || T(this, e, t, 4, 2147483647, -2147483648), this[t] = 255 & e, this[t + 1] = e >>> 8, this[t + 2] =
						e >>> 16, this[t + 3] = e >>> 24, t + 4
				}, h.prototype.writeInt32BE = function (e, t, n) {
					return e = +e, t >>>= 0, n || T(this, e, t, 4, 2147483647, -2147483648), e < 0 && (e = 4294967295 + e + 1), this[t] = e >>> 24,
						this[t + 1] = e >>> 16, this[t + 2] = e >>> 8, this[t + 3] = 255 & e, t + 4
				}, h.prototype.writeFloatLE = function (e, t, n) {
					return A(this, e, t, !0, n)
				}, h.prototype.writeFloatBE = function (e, t, n) {
					return A(this, e, t, !1, n)
				}, h.prototype.writeDoubleLE = function (e, t, n) {
					return E(this, e, t, !0, n)
				}, h.prototype.writeDoubleBE = function (e, t, n) {
					return E(this, e, t, !1, n)
				}, h.prototype.copy = function (e, t, n, r) {
					if (!h.isBuffer(e)) throw new TypeError("argument should be a Buffer");
					if (n || (n = 0), r || 0 === r || (r = this.length), t >= e.length && (t = e.length), t || (t = 0), 0 < r && r < n && (r = n),
						r === n) return 0;
					if (0 === e.length || 0 === this.length) return 0;
					if (t < 0) throw new RangeError("targetStart out of bounds");
					if (n < 0 || n >= this.length) throw new RangeError("Index out of range");
					if (r < 0) throw new RangeError("sourceEnd out of bounds");
					r > this.length && (r = this.length), e.length - t < r - n && (r = e.length - t + n);
					var i = r - n;
					if (this === e && "function" == typeof Uint8Array.prototype.copyWithin) this.copyWithin(t, n, r);
					else if (this === e && n < t && t < r)
						for (var o = i - 1; 0 <= o; --o) e[o + t] = this[o + n];
					else Uint8Array.prototype.set.call(e, this.subarray(n, r), t);
					return i
				}, h.prototype.fill = function (e, t, n, r) {
					if ("string" == typeof e) {
						if ("string" == typeof t ? (r = t, t = 0, n = this.length) : "string" == typeof n && (r = n, n = this.length), void 0 !== r &&
							"string" != typeof r) throw new TypeError("encoding must be a string");
						if ("string" == typeof r && !h.isEncoding(r)) throw new TypeError("Unknown encoding: " + r);
						if (1 === e.length) {
							var i = e.charCodeAt(0);
							("utf8" === r && i < 128 || "latin1" === r) && (e = i)
						}
					} else "number" == typeof e && (e &= 255);
					if (t < 0 || this.length < t || this.length < n) throw new RangeError("Out of range index");
					if (n <= t) return this;
					var o;
					if (t >>>= 0, n = void 0 === n ? this.length : n >>> 0, e || (e = 0), "number" == typeof e)
						for (o = t; o < n; ++o) this[o] = e;
					else {
						var a = h.isBuffer(e) ? e : h.from(e, r),
							l = a.length;
						if (0 === l) throw new TypeError('The value "' + e + '" is invalid for argument "value"');
						for (o = 0; o < n - t; ++o) this[o + t] = a[o % l]
					}
					return this
				};
				var t = /[^+/0-9A-Za-z-_]/g;

				function N(e) {
					return e < 16 ? "0" + e.toString(16) : e.toString(16)
				}

				function D(e, t) {
					var n;
					t = t || 1 / 0;
					for (var r = e.length, i = null, o = [], a = 0; a < r; ++a) {
						if (55295 < (n = e.charCodeAt(a)) && n < 57344) {
							if (!i) {
								if (56319 < n) {
									-1 < (t -= 3) && o.push(239, 191, 189);
									continue
								}
								if (a + 1 === r) {
									-1 < (t -= 3) && o.push(239, 191, 189);
									continue
								}
								i = n;
								continue
							}
							if (n < 56320) {
								-1 < (t -= 3) && o.push(239, 191, 189), i = n;
								continue
							}
							n = 65536 + (i - 55296 << 10 | n - 56320)
						} else i && -1 < (t -= 3) && o.push(239, 191, 189);
						if (i = null, n < 128) {
							if ((t -= 1) < 0) break;
							o.push(n)
						} else if (n < 2048) {
							if ((t -= 2) < 0) break;
							o.push(n >> 6 | 192, 63 & n | 128)
						} else if (n < 65536) {
							if ((t -= 3) < 0) break;
							o.push(n >> 12 | 224, n >> 6 & 63 | 128, 63 & n | 128)
						} else {
							if (!(n < 1114112)) throw new Error("Invalid code point");
							if ((t -= 4) < 0) break;
							o.push(n >> 18 | 240, n >> 12 & 63 | 128, n >> 6 & 63 | 128, 63 & n | 128)
						}
					}
					return o
				}

				function F(e) {
					return r.toByteArray(function (e) {
						if ((e = (e = e.split("=")[0]).trim().replace(t, "")).length < 2) return "";
						for (; e.length % 4 != 0;) e += "=";
						return e
					}(e))
				}

				function O(e, t, n, r) {
					for (var i = 0; i < r && !(i + n >= t.length || i >= e.length); ++i) t[i + n] = e[i];
					return i
				}

				function I(e, t) {
					return e instanceof t || null != e && null != e.constructor && null != e.constructor.name && e.constructor.name === t.name
				}

				function B(e) {
					return e != e
				}
			}).call(this, e("buffer").Buffer)
		}, {
			"base64-js": 1,
			buffer: 3,
			ieee754: 16
		}],
		4: [function (e, t, n) {
			"use strict";
			var l = e("typo-js");

			function s(a) {
				"function" == typeof (a = a || {}).codeMirrorInstance && "function" == typeof a.codeMirrorInstance.defineMode ? (String.prototype.includes ||
					(String.prototype.includes = function () {
						return -1 !== String.prototype.indexOf.apply(this, arguments)
					}), a.codeMirrorInstance.defineMode("spell-checker", function (e) {
						if (!s.aff_loading) {
							s.aff_loading = !0;
							var t = new XMLHttpRequest;
							t.open("GET", "https://cdn.jsdelivr.net/codemirror.spell-checker/latest/en_US.aff", !0), t.onload = function () {
								4 === t.readyState && 200 === t.status && (s.aff_data = t.responseText, 2 == ++s.num_loaded && (s.typo = new l("en_US", s.aff_data,
									s.dic_data, {
										platform: "any"
									})))
							}, t.send(null)
						}
						if (!s.dic_loading) {
							s.dic_loading = !0;
							var n = new XMLHttpRequest;
							n.open("GET", "https://cdn.jsdelivr.net/codemirror.spell-checker/latest/en_US.dic", !0), n.onload = function () {
								4 === n.readyState && 200 === n.status && (s.dic_data = n.responseText, 2 == ++s.num_loaded && (s.typo = new l("en_US", s.aff_data,
									s.dic_data, {
										platform: "any"
									})))
							}, n.send(null)
						}
						var r = '!"#$%&()*+,-./:;<=>?@[\\]^_`{|}~ ',
							i = {
								token: function (e) {
									var t = e.peek(),
										n = "";
									if (r.includes(t)) return e.next(), null;
									for (; null != (t = e.peek()) && !r.includes(t);) n += t, e.next();
									return s.typo && !s.typo.check(n) ? "spell-error" : null
								}
							},
							o = a.codeMirrorInstance.getMode(e, e.backdrop || "text/plain");
						return a.codeMirrorInstance.overlayMode(o, i, !0)
					})) : console.log("CodeMirror Spell Checker: You must provide an instance of CodeMirror via the option `codeMirrorInstance`")
			}
			s.num_loaded = 0, s.aff_loading = !1, s.dic_loading = !1, s.aff_data = "", s.dic_data = "", t.exports = s
		}, {
			"typo-js": 18
		}],
		5: [function (e, t, n) {
			(function (o) {
				"use strict";
				o.defineOption("fullScreen", !1, function (e, t, n) {
					var r, i;
					(n == o.Init && (n = !1), !n != !t) && (t ? (i = (r = e).getWrapperElement(), r.state.fullScreenRestore = {
							scrollTop: window.pageYOffset,
							scrollLeft: window.pageXOffset,
							width: i.style.width,
							height: i.style.height
						}, i.style.width = "", i.style.height = "auto", i.className += " CodeMirror-fullscreen", document.documentElement.style.overflow =
						"hidden", r.refresh()) : function (e) {
						var t = e.getWrapperElement();
						t.className = t.className.replace(/\s*CodeMirror-fullscreen\b/, ""), document.documentElement.style.overflow = "";
						var n = e.state.fullScreenRestore;
						t.style.width = n.width, t.style.height = n.height, window.scrollTo(n.scrollLeft, n.scrollTop), e.refresh()
					}(e))
				})
			})("object" == typeof n && "object" == typeof t ? e("../../lib/codemirror") : CodeMirror)
		}, {
			"../../lib/codemirror": 11
		}],
		6: [function (e, t, n) {
			(function (o) {
				function a(e) {
					e.state.placeholder && (e.state.placeholder.parentNode.removeChild(e.state.placeholder), e.state.placeholder = null)
				}

				function r(e) {
					a(e);
					var t = e.state.placeholder = document.createElement("pre");
					t.style.cssText = "height: 0; overflow: visible", t.style.direction = e.getOption("direction"), t.className =
						"CodeMirror-placeholder";
					var n = e.getOption("placeholder");
					"string" == typeof n && (n = document.createTextNode(n)), t.appendChild(n), e.display.lineSpace.insertBefore(t, e.display.lineSpace
						.firstChild)
				}

				function l(e) {
					i(e) && r(e)
				}

				function s(e) {
					var t = e.getWrapperElement(),
						n = i(e);
					t.className = t.className.replace(" CodeMirror-empty", "") + (n ? " CodeMirror-empty" : ""), n ? r(e) : a(e)
				}

				function i(e) {
					return 1 === e.lineCount() && "" === e.getLine(0)
				}
				o.defineOption("placeholder", "", function (e, t, n) {
					var r = n && n != o.Init;
					if (t && !r) e.on("blur", l), e.on("change", s), e.on("swapDoc", s), s(e);
					else if (!t && r) {
						e.off("blur", l), e.off("change", s), e.off("swapDoc", s), a(e);
						var i = e.getWrapperElement();
						i.className = i.className.replace(" CodeMirror-empty", "")
					}
					t && !e.hasFocus() && l(e)
				})
			})("object" == typeof n && "object" == typeof t ? e("../../lib/codemirror") : CodeMirror)
		}, {
			"../../lib/codemirror": 11
		}],
		7: [function (e, t, n) {
			(function (g) {
				"use strict";
				var v = /^(\s*)(>[> ]*|[*+-] \[[x ]\]\s|[*+-]\s|(\d+)([.)]))(\s*)/,
					y = /^(\s*)(>[> ]*|[*+-] \[[x ]\]|[*+-]|(\d+)[.)])(\s*)$/,
					x = /[*+-]\s/;

				function b(e, t) {
					var n = t.line,
						r = 0,
						i = 0,
						o = v.exec(e.getLine(n)),
						a = o[1];
					do {
						var l = n + (r += 1),
							s = e.getLine(l),
							u = v.exec(s);
						if (u) {
							var c = u[1],
								h = parseInt(o[3], 10) + r - i,
								f = parseInt(u[3], 10),
								d = f;
							if (a !== c || isNaN(f)) {
								if (a.length > c.length) return;
								if (a.length < c.length && 1 === r) return;
								i += 1
							} else h === f && (d = f + 1), f < h && (d = h + 1), e.replaceRange(s.replace(v, c + d + u[4] + u[5]), {
								line: l,
								ch: 0
							}, {
								line: l,
								ch: s.length
							})
						}
					} while (u)
				}
				g.commands.newlineAndIndentContinueMarkdownList = function (e) {
					if (e.getOption("disableInput")) return g.Pass;
					for (var t = e.listSelections(), n = [], r = 0; r < t.length; r++) {
						var i = t[r].head,
							o = e.getStateAfter(i.line),
							a = e.getMode().innerMode(o);
						if ("markdown" !== a.mode.name) return void e.execCommand("newlineAndIndent");
						var l = !1 !== (o = a.state).list,
							s = 0 !== o.quote,
							u = e.getLine(i.line),
							c = v.exec(u),
							h = /^\s*$/.test(u.slice(0, i.ch));
						if (!t[r].empty() || !l && !s || !c || h) return void e.execCommand("newlineAndIndent");
						if (y.test(u)) />\s*$/.test(u) || e.replaceRange("", {
							line: i.line,
							ch: 0
						}, {
							line: i.line,
							ch: i.ch + 1
						}), n[r] = "\n";
						else {
							var f = c[1],
								d = c[5],
								p = !(x.test(c[2]) || 0 <= c[2].indexOf(">")),
								m = p ? parseInt(c[3], 10) + 1 + c[4] : c[2].replace("x", " ");
							n[r] = "\n" + f + m + d, p && b(e, i)
						}
					}
					e.replaceSelections(n)
				}
			})("object" == typeof n && "object" == typeof t ? e("../../lib/codemirror") : CodeMirror)
		}, {
			"../../lib/codemirror": 11
		}],
		8: [function (e, t, n) {
			(function (t) {
				"use strict";
				t.overlayMode = function (r, i, o) {
					return {
						startState: function () {
							return {
								base: t.startState(r),
								overlay: t.startState(i),
								basePos: 0,
								baseCur: null,
								overlayPos: 0,
								overlayCur: null,
								streamSeen: null
							}
						},
						copyState: function (e) {
							return {
								base: t.copyState(r, e.base),
								overlay: t.copyState(i, e.overlay),
								basePos: e.basePos,
								baseCur: null,
								overlayPos: e.overlayPos,
								overlayCur: null
							}
						},
						token: function (e, t) {
							return (e != t.streamSeen || Math.min(t.basePos, t.overlayPos) < e.start) && (t.streamSeen = e, t.basePos = t.overlayPos = e
									.start), e.start == t.basePos && (t.baseCur = r.token(e, t.base), t.basePos = e.pos), e.start == t.overlayPos && (e.pos =
									e.start, t.overlayCur = i.token(e, t.overlay), t.overlayPos = e.pos), e.pos = Math.min(t.basePos, t.overlayPos), null == t
								.overlayCur ? t.baseCur : null != t.baseCur && t.overlay.combineTokens || o && null == t.overlay.combineTokens ? t.baseCur +
								" " + t.overlayCur : t.overlayCur
						},
						indent: r.indent && function (e, t, n) {
							return r.indent(e.base, t, n)
						},
						electricChars: r.electricChars,
						innerMode: function (e) {
							return {
								state: e.base,
								mode: r
							}
						},
						blankLine: function (e) {
							var t, n;
							return r.blankLine && (t = r.blankLine(e.base)), i.blankLine && (n = i.blankLine(e.overlay)), null == n ? t : o && null != t ?
								t + " " + n : n
						}
					}
				}
			})("object" == typeof n && "object" == typeof t ? e("../../lib/codemirror") : CodeMirror)
		}, {
			"../../lib/codemirror": 11
		}],
		9: [function (e, t, n) {
			(function (i) {
				"use strict";
				var v, y, x = i.Pos;

				function p(e, t) {
					for (var n, r, i = null != (r = (n = e).flags) ? r : (n.ignoreCase ? "i" : "") + (n.global ? "g" : "") + (n.multiline ? "m" : ""),
							o = i, a = 0; a < t.length; a++) - 1 == o.indexOf(t.charAt(a)) && (o += t.charAt(a));
					return i == o ? e : new RegExp(e.source, o)
				}

				function m(e, t, n) {
					t = p(t, "g");
					for (var r = n.line, i = n.ch, o = e.lastLine(); r <= o; r++, i = 0) {
						t.lastIndex = i;
						var a = e.getLine(r),
							l = t.exec(a);
						if (l) return {
							from: x(r, l.index),
							to: x(r, l.index + l[0].length),
							match: l
						}
					}
				}

				function g(e, t) {
					for (var n, r = 0;;) {
						t.lastIndex = r;
						var i = t.exec(e);
						if (!i) return n;
						if ((r = (n = i).index + (n[0].length || 1)) == e.length) return n
					}
				}

				function b(e, t, n, r) {
					if (e.length == t.length) return n;
					for (var i = 0, o = n + Math.max(0, e.length - t.length);;) {
						if (i == o) return i;
						var a = i + o >> 1,
							l = r(e.slice(0, a)).length;
						if (l == n) return a;
						n < l ? o = a : i = a + 1
					}
				}

				function r(n, r, e, t) {
					var i;
					this.atOccurrence = !1, this.doc = n, e = e ? n.clipPos(e) : x(0, 0), this.pos = {
						from: e,
						to: e
					}, "object" == typeof t ? i = t.caseFold : (i = t, t = null), "string" == typeof r ? (null == i && (i = !1), this.matches =
						function (e, t) {
							return (e ? function (e, t, n, r) {
								if (!t.length) return null;
								var i = r ? v : y,
									o = i(t).split(/\r|\n\r?/);
								e: for (var a = n.line, l = n.ch, s = e.firstLine() - 1 + o.length; s <= a; a--, l = -1) {
									var u = e.getLine(a); - 1 < l && (u = u.slice(0, l));
									var c = i(u);
									if (1 == o.length) {
										var h = c.lastIndexOf(o[0]);
										if (-1 == h) continue e;
										return {
											from: x(a, b(u, c, h, i)),
											to: x(a, b(u, c, h + o[0].length, i))
										}
									}
									var f = o[o.length - 1];
									if (c.slice(0, f.length) == f) {
										var d = 1;
										for (n = a - o.length + 1; d < o.length - 1; d++)
											if (i(e.getLine(n + d)) != o[d]) continue e;
										var p = e.getLine(a + 1 - o.length),
											m = i(p);
										if (m.slice(m.length - o[0].length) == o[0]) return {
											from: x(a + 1 - o.length, b(p, m, p.length - o[0].length, i)),
											to: x(a, b(u, c, f.length, i))
										}
									}
								}
							} : function (e, t, n, r) {
								if (!t.length) return null;
								var i = r ? v : y,
									o = i(t).split(/\r|\n\r?/);
								e: for (var a = n.line, l = n.ch, s = e.lastLine() + 1 - o.length; a <= s; a++, l = 0) {
									var u = e.getLine(a).slice(l),
										c = i(u);
									if (1 == o.length) {
										var h = c.indexOf(o[0]);
										if (-1 == h) continue e;
										return n = b(u, c, h, i) + l, {
											from: x(a, b(u, c, h, i) + l),
											to: x(a, b(u, c, h + o[0].length, i) + l)
										}
									}
									var f = c.length - o[0].length;
									if (c.slice(f) == o[0]) {
										for (var d = 1; d < o.length - 1; d++)
											if (i(e.getLine(a + d)) != o[d]) continue e;
										var p = e.getLine(a + o.length - 1),
											m = i(p),
											g = o[o.length - 1];
										if (m.slice(0, g.length) == g) return {
											from: x(a, b(u, c, f, i) + l),
											to: x(a + o.length - 1, b(p, m, g.length, i))
										}
									}
								}
							})(n, r, t, i)
						}) : (r = p(r, "gm"), t && !1 === t.multiline ? this.matches = function (e, t) {
						return (e ? function (e, t, n) {
							t = p(t, "g");
							for (var r = n.line, i = n.ch, o = e.firstLine(); o <= r; r--, i = -1) {
								var a = e.getLine(r); - 1 < i && (a = a.slice(0, i));
								var l = g(a, t);
								if (l) return {
									from: x(r, l.index),
									to: x(r, l.index + l[0].length),
									match: l
								}
							}
						} : m)(n, r, t)
					} : this.matches = function (e, t) {
						return (e ? function (e, t, n) {
							t = p(t, "gm");
							for (var r, i = 1, o = n.line, a = e.firstLine(); a <= o;) {
								for (var l = 0; l < i; l++) {
									var s = e.getLine(o--);
									r = null == r ? s.slice(0, n.ch) : s + "\n" + r
								}
								i *= 2;
								var u = g(r, t);
								if (u) {
									var c = r.slice(0, u.index).split("\n"),
										h = u[0].split("\n"),
										f = o + c.length,
										d = c[c.length - 1].length;
									return {
										from: x(f, d),
										to: x(f + h.length - 1, 1 == h.length ? d + h[0].length : h[h.length - 1].length),
										match: u
									}
								}
							}
						} : function (e, t, n) {
							if (!/\\s|\\n|\n|\\W|\\D|\[\^/.test(t.source)) return m(e, t, n);
							t = p(t, "gm");
							for (var r, i = 1, o = n.line, a = e.lastLine(); o <= a;) {
								for (var l = 0; l < i && !(a < o); l++) {
									var s = e.getLine(o++);
									r = null == r ? s : r + "\n" + s
								}
								i *= 2, t.lastIndex = n.ch;
								var u = t.exec(r);
								if (u) {
									var c = r.slice(0, u.index).split("\n"),
										h = u[0].split("\n"),
										f = n.line + c.length - 1,
										d = c[c.length - 1].length;
									return {
										from: x(f, d),
										to: x(f + h.length - 1, 1 == h.length ? d + h[0].length : h[h.length - 1].length),
										match: u
									}
								}
							}
						})(n, r, t)
					})
				}
				y = String.prototype.normalize ? (v = function (e) {
					return e.normalize("NFD").toLowerCase()
				}, function (e) {
					return e.normalize("NFD")
				}) : (v = function (e) {
					return e.toLowerCase()
				}, function (e) {
					return e
				}), r.prototype = {
					findNext: function () {
						return this.find(!1)
					},
					findPrevious: function () {
						return this.find(!0)
					},
					find: function (e) {
						for (var t = this.matches(e, this.doc.clipPos(e ? this.pos.from : this.pos.to)); t && 0 == i.cmpPos(t.from, t.to);) e ? t.from
							.ch ? t.from = x(t.from.line, t.from.ch - 1) : t = t.from.line == this.doc.firstLine() ? null : this.matches(e, this.doc.clipPos(
								x(t.from.line - 1))) : t.to.ch < this.doc.getLine(t.to.line).length ? t.to = x(t.to.line, t.to.ch + 1) : t = t.to.line ==
							this.doc.lastLine() ? null : this.matches(e, x(t.to.line + 1, 0));
						if (t) return this.pos = t, this.atOccurrence = !0, this.pos.match || !0;
						var n = x(e ? this.doc.firstLine() : this.doc.lastLine() + 1, 0);
						return this.pos = {
							from: n,
							to: n
						}, this.atOccurrence = !1
					},
					from: function () {
						if (this.atOccurrence) return this.pos.from
					},
					to: function () {
						if (this.atOccurrence) return this.pos.to
					},
					replace: function (e, t) {
						if (this.atOccurrence) {
							var n = i.splitLines(e);
							this.doc.replaceRange(n, this.pos.from, this.pos.to, t), this.pos.to = x(this.pos.from.line + n.length - 1, n[n.length - 1].length +
								(1 == n.length ? this.pos.from.ch : 0))
						}
					}
				}, i.defineExtension("getSearchCursor", function (e, t, n) {
					return new r(this.doc, e, t, n)
				}), i.defineDocExtension("getSearchCursor", function (e, t, n) {
					return new r(this, e, t, n)
				}), i.defineExtension("selectMatches", function (e, t) {
					for (var n = [], r = this.getSearchCursor(e, this.getCursor("from"), t); r.findNext() && !(0 < i.cmpPos(r.to(), this.getCursor(
							"to")));) n.push({
						anchor: r.from(),
						head: r.to()
					});
					n.length && this.setSelections(n, 0)
				})
			})("object" == typeof n && "object" == typeof t ? e("../../lib/codemirror") : CodeMirror)
		}, {
			"../../lib/codemirror": 11
		}],
		10: [function (e, t, n) {
			(function (i) {
				"use strict";

				function o(e) {
					e.state.markedSelection && e.operation(function () {
						! function (e) {
							if (!e.somethingSelected()) return s(e);
							if (1 < e.listSelections().length) return u(e);
							var t = e.getCursor("start"),
								n = e.getCursor("end"),
								r = e.state.markedSelection;
							if (!r.length) return l(e, t, n);
							var i = r[0].find(),
								o = r[r.length - 1].find();
							if (!i || !o || n.line - t.line <= f || 0 <= p(t, o.to) || p(n, i.from) <= 0) return u(e);
							for (; 0 < p(t, i.from);) r.shift().clear(), i = r[0].find();
							p(t, i.from) < 0 && (i.to.line - t.line < f ? (r.shift().clear(), l(e, t, i.to, 0)) : l(e, t, i.from, 0));
							for (; p(n, o.to) < 0;) r.pop().clear(), o = r[r.length - 1].find();
							0 < p(n, o.to) && (n.line - o.from.line < f ? (r.pop().clear(), l(e, o.from, n)) : l(e, o.to, n))
						}(e)
					})
				}

				function a(e) {
					e.state.markedSelection && e.state.markedSelection.length && e.operation(function () {
						s(e)
					})
				}
				i.defineOption("styleSelectedText", !1, function (e, t, n) {
					var r = n && n != i.Init;
					t && !r ? (e.state.markedSelection = [], e.state.markedSelectionStyle = "string" == typeof t ? t : "CodeMirror-selectedtext",
						u(e), e.on("cursorActivity", o), e.on("change", a)) : !t && r && (e.off("cursorActivity", o), e.off("change", a), s(e), e.state
						.markedSelection = e.state.markedSelectionStyle = null)
				});
				var f = 8,
					d = i.Pos,
					p = i.cmpPos;

				function l(e, t, n, r) {
					if (0 != p(t, n))
						for (var i = e.state.markedSelection, o = e.state.markedSelectionStyle, a = t.line;;) {
							var l = a == t.line ? t : d(a, 0),
								s = a + f,
								u = s >= n.line,
								c = u ? n : d(s, 0),
								h = e.markText(l, c, {
									className: o
								});
							if (null == r ? i.push(h) : i.splice(r++, 0, h), u) break;
							a = s
						}
				}

				function s(e) {
					for (var t = e.state.markedSelection, n = 0; n < t.length; ++n) t[n].clear();
					t.length = 0
				}

				function u(e) {
					s(e);
					for (var t = e.listSelections(), n = 0; n < t.length; n++) l(e, t[n].from(), t[n].to())
				}
			})("object" == typeof n && "object" == typeof t ? e("../../lib/codemirror") : CodeMirror)
		}, {
			"../../lib/codemirror": 11
		}],
		11: [function (e, t, n) {
			var r, i;
			r = this, i = function () {
				"use strict";
				var e = navigator.userAgent,
					t = navigator.platform,
					m = /gecko\/\d/i.test(e),
					n = /MSIE \d/.test(e),
					r = /Trident\/(?:[7-9]|\d{2,})\..*rv:(\d+)/.exec(e),
					i = /Edge\/(\d+)/.exec(e),
					w = n || r || i,
					k = w && (n ? document.documentMode || 6 : +(i || r)[1]),
					x = !i && /WebKit\//.test(e),
					o = x && /Qt\/\d+\.\d+/.test(e),
					a = !i && /Chrome\//.test(e),
					g = /Opera\//.test(e),
					s = /Apple Computer/.test(navigator.vendor),
					l = /Mac OS X 1\d\D([8-9]|\d\d)\D/.test(e),
					u = /PhantomJS/.test(e),
					c = !i && /AppleWebKit/.test(e) && /Mobile\/\w+/.test(e),
					h = /Android/.test(e),
					f = c || h || /webOS|BlackBerry|Opera Mini|Opera Mobi|IEMobile/i.test(e),
					b = c || /Mac/.test(t),
					d = /\bCrOS\b/.test(e),
					p = /win/i.test(t),
					v = g && e.match(/Version\/(\d*\.\d*)/);
				v && (v = Number(v[1])), v && 15 <= v && (x = !(g = !1));
				var y = b && (o || g && (null == v || v < 12.11)),
					C = m || w && 9 <= k;

				function S(e) {
					return new RegExp("(^|\\s)" + e + "(?:$|\\s)\\s*")
				}
				var L, T = function (e, t) {
					var n = e.className,
						r = S(t).exec(n);
					if (r) {
						var i = n.slice(r.index + r[0].length);
						e.className = n.slice(0, r.index) + (i ? r[1] + i : "")
					}
				};

				function M(e) {
					for (var t = e.childNodes.length; 0 < t; --t) e.removeChild(e.firstChild);
					return e
				}

				function A(e, t) {
					return M(e).appendChild(t)
				}

				function N(e, t, n, r) {
					var i = document.createElement(e);
					if (n && (i.className = n), r && (i.style.cssText = r), "string" == typeof t) i.appendChild(document.createTextNode(t));
					else if (t)
						for (var o = 0; o < t.length; ++o) i.appendChild(t[o]);
					return i
				}

				function E(e, t, n, r) {
					var i = N(e, t, n, r);
					return i.setAttribute("role", "presentation"), i
				}

				function D(e, t) {
					if (3 == t.nodeType && (t = t.parentNode), e.contains) return e.contains(t);
					do {
						if (11 == t.nodeType && (t = t.host), t == e) return !0
					} while (t = t.parentNode)
				}

				function F() {
					var t;
					try {
						t = document.activeElement
					} catch (e) {
						t = document.body || null
					}
					for (; t && t.shadowRoot && t.shadowRoot.activeElement;) t = t.shadowRoot.activeElement;
					return t
				}

				function O(e, t) {
					var n = e.className;
					S(t).test(n) || (e.className += (n ? " " : "") + t)
				}

				function I(e, t) {
					for (var n = e.split(" "), r = 0; r < n.length; r++) n[r] && !S(n[r]).test(t) && (t += " " + n[r]);
					return t
				}
				L = document.createRange ? function (e, t, n, r) {
					var i = document.createRange();
					return i.setEnd(r || e, n), i.setStart(e, t), i
				} : function (e, t, n) {
					var r = document.body.createTextRange();
					try {
						r.moveToElementText(e.parentNode)
					} catch (e) {
						return r
					}
					return r.collapse(!0), r.moveEnd("character", n), r.moveStart("character", t), r
				};
				var B = function (e) {
					e.select()
				};

				function R(e) {
					var t = Array.prototype.slice.call(arguments, 1);
					return function () {
						return e.apply(null, t)
					}
				}

				function H(e, t, n) {
					for (var r in t || (t = {}), e) !e.hasOwnProperty(r) || !1 === n && t.hasOwnProperty(r) || (t[r] = e[r]);
					return t
				}

				function z(e, t, n, r, i) {
					null == t && -1 == (t = e.search(/[^\s\u00a0]/)) && (t = e.length);
					for (var o = r || 0, a = i || 0;;) {
						var l = e.indexOf("\t", o);
						if (l < 0 || t <= l) return a + (t - o);
						a += l - o, a += n - a % n, o = l + 1
					}
				}
				c ? B = function (e) {
					e.selectionStart = 0, e.selectionEnd = e.value.length
				} : w && (B = function (e) {
					try {
						e.select()
					} catch (e) {}
				});
				var P = function () {
					this.id = null
				};

				function _(e, t) {
					for (var n = 0; n < e.length; ++n)
						if (e[n] == t) return n;
					return -1
				}
				P.prototype.set = function (e, t) {
					clearTimeout(this.id), this.id = setTimeout(t, e)
				};
				var W = 30,
					j = {
						toString: function () {
							return "CodeMirror.Pass"
						}
					},
					U = {
						scroll: !1
					},
					q = {
						origin: "*mouse"
					},
					$ = {
						origin: "+move"
					};

				function G(e, t, n) {
					for (var r = 0, i = 0;;) {
						var o = e.indexOf("\t", r); - 1 == o && (o = e.length);
						var a = o - r;
						if (o == e.length || t <= i + a) return r + Math.min(a, t - i);
						if (i += o - r, r = o + 1, t <= (i += n - i % n)) return r
					}
				}
				var V = [""];

				function X(e) {
					for (; V.length <= e;) V.push(K(V) + " ");
					return V[e]
				}

				function K(e) {
					return e[e.length - 1]
				}

				function Z(e, t) {
					for (var n = [], r = 0; r < e.length; r++) n[r] = t(e[r], r);
					return n
				}

				function Y() {}

				function J(e, t) {
					var n;
					return n = Object.create ? Object.create(e) : (Y.prototype = e, new Y), t && H(t, n), n
				}
				var Q = /[\u00df\u0587\u0590-\u05f4\u0600-\u06ff\u3040-\u309f\u30a0-\u30ff\u3400-\u4db5\u4e00-\u9fcc\uac00-\ud7af]/;

				function ee(e) {
					return /\w/.test(e) || "" < e && (e.toUpperCase() != e.toLowerCase() || Q.test(e))
				}

				function te(e, t) {
					return t ? !!(-1 < t.source.indexOf("\\w") && ee(e)) || t.test(e) : ee(e)
				}

				function ne(e) {
					for (var t in e)
						if (e.hasOwnProperty(t) && e[t]) return !1;
					return !0
				}
				var re =
					/[\u0300-\u036f\u0483-\u0489\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7\u0610-\u061a\u064b-\u065e\u0670\u06d6-\u06dc\u06de-\u06e4\u06e7\u06e8\u06ea-\u06ed\u0711\u0730-\u074a\u07a6-\u07b0\u07eb-\u07f3\u0816-\u0819\u081b-\u0823\u0825-\u0827\u0829-\u082d\u0900-\u0902\u093c\u0941-\u0948\u094d\u0951-\u0955\u0962\u0963\u0981\u09bc\u09be\u09c1-\u09c4\u09cd\u09d7\u09e2\u09e3\u0a01\u0a02\u0a3c\u0a41\u0a42\u0a47\u0a48\u0a4b-\u0a4d\u0a51\u0a70\u0a71\u0a75\u0a81\u0a82\u0abc\u0ac1-\u0ac5\u0ac7\u0ac8\u0acd\u0ae2\u0ae3\u0b01\u0b3c\u0b3e\u0b3f\u0b41-\u0b44\u0b4d\u0b56\u0b57\u0b62\u0b63\u0b82\u0bbe\u0bc0\u0bcd\u0bd7\u0c3e-\u0c40\u0c46-\u0c48\u0c4a-\u0c4d\u0c55\u0c56\u0c62\u0c63\u0cbc\u0cbf\u0cc2\u0cc6\u0ccc\u0ccd\u0cd5\u0cd6\u0ce2\u0ce3\u0d3e\u0d41-\u0d44\u0d4d\u0d57\u0d62\u0d63\u0dca\u0dcf\u0dd2-\u0dd4\u0dd6\u0ddf\u0e31\u0e34-\u0e3a\u0e47-\u0e4e\u0eb1\u0eb4-\u0eb9\u0ebb\u0ebc\u0ec8-\u0ecd\u0f18\u0f19\u0f35\u0f37\u0f39\u0f71-\u0f7e\u0f80-\u0f84\u0f86\u0f87\u0f90-\u0f97\u0f99-\u0fbc\u0fc6\u102d-\u1030\u1032-\u1037\u1039\u103a\u103d\u103e\u1058\u1059\u105e-\u1060\u1071-\u1074\u1082\u1085\u1086\u108d\u109d\u135f\u1712-\u1714\u1732-\u1734\u1752\u1753\u1772\u1773\u17b7-\u17bd\u17c6\u17c9-\u17d3\u17dd\u180b-\u180d\u18a9\u1920-\u1922\u1927\u1928\u1932\u1939-\u193b\u1a17\u1a18\u1a56\u1a58-\u1a5e\u1a60\u1a62\u1a65-\u1a6c\u1a73-\u1a7c\u1a7f\u1b00-\u1b03\u1b34\u1b36-\u1b3a\u1b3c\u1b42\u1b6b-\u1b73\u1b80\u1b81\u1ba2-\u1ba5\u1ba8\u1ba9\u1c2c-\u1c33\u1c36\u1c37\u1cd0-\u1cd2\u1cd4-\u1ce0\u1ce2-\u1ce8\u1ced\u1dc0-\u1de6\u1dfd-\u1dff\u200c\u200d\u20d0-\u20f0\u2cef-\u2cf1\u2de0-\u2dff\u302a-\u302f\u3099\u309a\ua66f-\ua672\ua67c\ua67d\ua6f0\ua6f1\ua802\ua806\ua80b\ua825\ua826\ua8c4\ua8e0-\ua8f1\ua926-\ua92d\ua947-\ua951\ua980-\ua982\ua9b3\ua9b6-\ua9b9\ua9bc\uaa29-\uaa2e\uaa31\uaa32\uaa35\uaa36\uaa43\uaa4c\uaab0\uaab2-\uaab4\uaab7\uaab8\uaabe\uaabf\uaac1\uabe5\uabe8\uabed\udc00-\udfff\ufb1e\ufe00-\ufe0f\ufe20-\ufe26\uff9e\uff9f]/;

				function ie(e) {
					return 768 <= e.charCodeAt(0) && re.test(e)
				}

				function oe(e, t, n) {
					for (;
						(n < 0 ? 0 < t : t < e.length) && ie(e.charAt(t));) t += n;
					return t
				}

				function ae(e, t, n) {
					for (var r = n < t ? -1 : 1;;) {
						if (t == n) return t;
						var i = (t + n) / 2,
							o = r < 0 ? Math.ceil(i) : Math.floor(i);
						if (o == t) return e(o) ? t : n;
						e(o) ? n = o : t = o + r
					}
				}

				function le(e, t, n) {
					var r = this;
					this.input = n, r.scrollbarFiller = N("div", null, "CodeMirror-scrollbar-filler"), r.scrollbarFiller.setAttribute(
						"cm-not-content", "true"), r.gutterFiller = N("div", null, "CodeMirror-gutter-filler"), r.gutterFiller.setAttribute(
						"cm-not-content", "true"), r.lineDiv = E("div", null, "CodeMirror-code"), r.selectionDiv = N("div", null, null,
						"position: relative; z-index: 1"), r.cursorDiv = N("div", null, "CodeMirror-cursors"), r.measure = N("div", null,
						"CodeMirror-measure"), r.lineMeasure = N("div", null, "CodeMirror-measure"), r.lineSpace = E("div", [r.measure, r.lineMeasure,
						r.selectionDiv, r.cursorDiv, r.lineDiv
					], null, "position: relative; outline: none");
					var i = E("div", [r.lineSpace], "CodeMirror-lines");
					r.mover = N("div", [i], null, "position: relative"), r.sizer = N("div", [r.mover], "CodeMirror-sizer"), r.sizerWidth = null, r.heightForcer =
						N("div", null, null, "position: absolute; height: " + W + "px; width: 1px;"), r.gutters = N("div", null, "CodeMirror-gutters"),
						r.lineGutter = null, r.scroller = N("div", [r.sizer, r.heightForcer, r.gutters], "CodeMirror-scroll"), r.scroller.setAttribute(
							"tabIndex", "-1"), r.wrapper = N("div", [r.scrollbarFiller, r.gutterFiller, r.scroller], "CodeMirror"), w && k < 8 && (r.gutters
							.style.zIndex = -1, r.scroller.style.paddingRight = 0), x || m && f || (r.scroller.draggable = !0), e && (e.appendChild ? e.appendChild(
							r.wrapper) : e(r.wrapper)), r.viewFrom = r.viewTo = t.first, r.reportedViewFrom = r.reportedViewTo = t.first, r.view = [], r.renderedView =
						null, r.externalMeasured = null, r.viewOffset = 0, r.lastWrapHeight = r.lastWrapWidth = 0, r.updateLineNumbers = null, r.nativeBarWidth =
						r.barHeight = r.barWidth = 0, r.scrollbarsClipped = !1, r.lineNumWidth = r.lineNumInnerWidth = r.lineNumChars = null, r.alignWidgets = !
						1, r.cachedCharWidth = r.cachedTextHeight = r.cachedPaddingH = null, r.maxLine = null, r.maxLineLength = 0, r.maxLineChanged = !
						1, r.wheelDX = r.wheelDY = r.wheelStartX = r.wheelStartY = null, r.shift = !1, r.selForContextMenu = null, r.activeTouch = null,
						n.init(r)
				}

				function se(e, t) {
					if ((t -= e.first) < 0 || t >= e.size) throw new Error("There is no line " + (t + e.first) + " in the document.");
					for (var n = e; !n.lines;)
						for (var r = 0;; ++r) {
							var i = n.children[r],
								o = i.chunkSize();
							if (t < o) {
								n = i;
								break
							}
							t -= o
						}
					return n.lines[t]
				}

				function ue(e, n, r) {
					var i = [],
						o = n.line;
					return e.iter(n.line, r.line + 1, function (e) {
						var t = e.text;
						o == r.line && (t = t.slice(0, r.ch)), o == n.line && (t = t.slice(n.ch)), i.push(t), ++o
					}), i
				}

				function ce(e, t, n) {
					var r = [];
					return e.iter(t, n, function (e) {
						r.push(e.text)
					}), r
				}

				function he(e, t) {
					var n = t - e.height;
					if (n)
						for (var r = e; r; r = r.parent) r.height += n
				}

				function fe(e) {
					if (null == e.parent) return null;
					for (var t = e.parent, n = _(t.lines, e), r = t.parent; r; r = (t = r).parent)
						for (var i = 0; r.children[i] != t; ++i) n += r.children[i].chunkSize();
					return n + t.first
				}

				function de(e, t) {
					var n = e.first;
					e: do {
						for (var r = 0; r < e.children.length; ++r) {
							var i = e.children[r],
								o = i.height;
							if (t < o) {
								e = i;
								continue e
							}
							t -= o, n += i.chunkSize()
						}
						return n
					} while (!e.lines);
					for (var a = 0; a < e.lines.length; ++a) {
						var l = e.lines[a].height;
						if (t < l) break;
						t -= l
					}
					return n + a
				}

				function pe(e, t) {
					return t >= e.first && t < e.first + e.size
				}

				function me(e, t) {
					return String(e.lineNumberFormatter(t + e.firstLineNumber))
				}

				function ge(e, t, n) {
					if (void 0 === n && (n = null), !(this instanceof ge)) return new ge(e, t, n);
					this.line = e, this.ch = t, this.sticky = n
				}

				function ve(e, t) {
					return e.line - t.line || e.ch - t.ch
				}

				function ye(e, t) {
					return e.sticky == t.sticky && 0 == ve(e, t)
				}

				function xe(e) {
					return ge(e.line, e.ch)
				}

				function be(e, t) {
					return ve(e, t) < 0 ? t : e
				}

				function we(e, t) {
					return ve(e, t) < 0 ? e : t
				}

				function ke(e, t) {
					return Math.max(e.first, Math.min(t, e.first + e.size - 1))
				}

				function Ce(e, t) {
					if (t.line < e.first) return ge(e.first, 0);
					var n, r, i, o = e.first + e.size - 1;
					return t.line > o ? ge(o, se(e, o).text.length) : (r = se(e, (n = t).line).text.length, null == (i = n.ch) || r < i ? ge(n.line,
						r) : i < 0 ? ge(n.line, 0) : n)
				}

				function Se(e, t) {
					for (var n = [], r = 0; r < t.length; r++) n[r] = Ce(e, t[r]);
					return n
				}
				var Le = !1,
					Te = !1;

				function Me(e, t, n) {
					this.marker = e, this.from = t, this.to = n
				}

				function Ae(e, t) {
					if (e)
						for (var n = 0; n < e.length; ++n) {
							var r = e[n];
							if (r.marker == t) return r
						}
				}

				function Ee(e, t) {
					for (var n, r = 0; r < e.length; ++r) e[r] != t && (n || (n = [])).push(e[r]);
					return n
				}

				function Ne(e, t) {
					if (t.full) return null;
					var n = pe(e, t.from.line) && se(e, t.from.line).markedSpans,
						r = pe(e, t.to.line) && se(e, t.to.line).markedSpans;
					if (!n && !r) return null;
					var i = t.from.ch,
						o = t.to.ch,
						a = 0 == ve(t.from, t.to),
						l = function (e, t, n) {
							var r;
							if (e)
								for (var i = 0; i < e.length; ++i) {
									var o = e[i],
										a = o.marker;
									if (null == o.from || (a.inclusiveLeft ? o.from <= t : o.from < t) || o.from == t && "bookmark" == a.type && (!n || !o.marker
											.insertLeft)) {
										var l = null == o.to || (a.inclusiveRight ? o.to >= t : o.to > t);
										(r || (r = [])).push(new Me(a, o.from, l ? null : o.to))
									}
								}
							return r
						}(n, i, a),
						s = function (e, t, n) {
							var r;
							if (e)
								for (var i = 0; i < e.length; ++i) {
									var o = e[i],
										a = o.marker;
									if (null == o.to || (a.inclusiveRight ? o.to >= t : o.to > t) || o.from == t && "bookmark" == a.type && (!n || o.marker.insertLeft)) {
										var l = null == o.from || (a.inclusiveLeft ? o.from <= t : o.from < t);
										(r || (r = [])).push(new Me(a, l ? null : o.from - t, null == o.to ? null : o.to - t))
									}
								}
							return r
						}(r, o, a),
						u = 1 == t.text.length,
						c = K(t.text).length + (u ? i : 0);
					if (l)
						for (var h = 0; h < l.length; ++h) {
							var f = l[h];
							if (null == f.to) {
								var d = Ae(s, f.marker);
								d ? u && (f.to = null == d.to ? null : d.to + c) : f.to = i
							}
						}
					if (s)
						for (var p = 0; p < s.length; ++p) {
							var m = s[p];
							if (null != m.to && (m.to += c), null == m.from) Ae(l, m.marker) || (m.from = c, u && (l || (l = [])).push(m));
							else m.from += c, u && (l || (l = [])).push(m)
						}
					l && (l = De(l)), s && s != l && (s = De(s));
					var g = [l];
					if (!u) {
						var v, y = t.text.length - 2;
						if (0 < y && l)
							for (var x = 0; x < l.length; ++x) null == l[x].to && (v || (v = [])).push(new Me(l[x].marker, null, null));
						for (var b = 0; b < y; ++b) g.push(v);
						g.push(s)
					}
					return g
				}

				function De(e) {
					for (var t = 0; t < e.length; ++t) {
						var n = e[t];
						null != n.from && n.from == n.to && !1 !== n.marker.clearWhenEmpty && e.splice(t--, 1)
					}
					return e.length ? e : null
				}

				function Fe(e) {
					var t = e.markedSpans;
					if (t) {
						for (var n = 0; n < t.length; ++n) t[n].marker.detachLine(e);
						e.markedSpans = null
					}
				}

				function Oe(e, t) {
					if (t) {
						for (var n = 0; n < t.length; ++n) t[n].marker.attachLine(e);
						e.markedSpans = t
					}
				}

				function Ie(e) {
					return e.inclusiveLeft ? -1 : 0
				}

				function Be(e) {
					return e.inclusiveRight ? 1 : 0
				}

				function Re(e, t) {
					var n = e.lines.length - t.lines.length;
					if (0 != n) return n;
					var r = e.find(),
						i = t.find(),
						o = ve(r.from, i.from) || Ie(e) - Ie(t);
					if (o) return -o;
					var a = ve(r.to, i.to) || Be(e) - Be(t);
					return a || t.id - e.id
				}

				function He(e, t) {
					var n, r = Te && e.markedSpans;
					if (r)
						for (var i = void 0, o = 0; o < r.length; ++o)(i = r[o]).marker.collapsed && null == (t ? i.from : i.to) && (!n || Re(n, i.marker) <
							0) && (n = i.marker);
					return n
				}

				function ze(e) {
					return He(e, !0)
				}

				function Pe(e) {
					return He(e, !1)
				}

				function _e(e, t) {
					var n, r = Te && e.markedSpans;
					if (r)
						for (var i = 0; i < r.length; ++i) {
							var o = r[i];
							o.marker.collapsed && (null == o.from || o.from < t) && (null == o.to || o.to > t) && (!n || Re(n, o.marker) < 0) && (n = o.marker)
						}
					return n
				}

				function We(e, t, n, r, i) {
					var o = se(e, t),
						a = Te && o.markedSpans;
					if (a)
						for (var l = 0; l < a.length; ++l) {
							var s = a[l];
							if (s.marker.collapsed) {
								var u = s.marker.find(0),
									c = ve(u.from, n) || Ie(s.marker) - Ie(i),
									h = ve(u.to, r) || Be(s.marker) - Be(i);
								if (!(0 <= c && h <= 0 || c <= 0 && 0 <= h) && (c <= 0 && (s.marker.inclusiveRight && i.inclusiveLeft ? 0 <= ve(u.to, n) : 0 <
										ve(u.to, n)) || 0 <= c && (s.marker.inclusiveRight && i.inclusiveLeft ? ve(u.from, r) <= 0 : ve(u.from, r) < 0))) return !0
							}
						}
				}

				function je(e) {
					for (var t; t = ze(e);) e = t.find(-1, !0).line;
					return e
				}

				function Ue(e, t) {
					var n = se(e, t),
						r = je(n);
					return n == r ? t : fe(r)
				}

				function qe(e, t) {
					if (t > e.lastLine()) return t;
					var n, r = se(e, t);
					if (!$e(e, r)) return t;
					for (; n = Pe(r);) r = n.find(1, !0).line;
					return fe(r) + 1
				}

				function $e(e, t) {
					var n = Te && t.markedSpans;
					if (n)
						for (var r = void 0, i = 0; i < n.length; ++i)
							if ((r = n[i]).marker.collapsed) {
								if (null == r.from) return !0;
								if (!r.marker.widgetNode && 0 == r.from && r.marker.inclusiveLeft && Ge(e, t, r)) return !0
							}
				}

				function Ge(e, t, n) {
					if (null == n.to) {
						var r = n.marker.find(1, !0);
						return Ge(e, r.line, Ae(r.line.markedSpans, n.marker))
					}
					if (n.marker.inclusiveRight && n.to == t.text.length) return !0;
					for (var i = void 0, o = 0; o < t.markedSpans.length; ++o)
						if ((i = t.markedSpans[o]).marker.collapsed && !i.marker.widgetNode && i.from == n.to && (null == i.to || i.to != n.from) && (i
								.marker.inclusiveLeft || n.marker.inclusiveRight) && Ge(e, t, i)) return !0
				}

				function Ve(e) {
					for (var t = 0, n = (e = je(e)).parent, r = 0; r < n.lines.length; ++r) {
						var i = n.lines[r];
						if (i == e) break;
						t += i.height
					}
					for (var o = n.parent; o; o = (n = o).parent)
						for (var a = 0; a < o.children.length; ++a) {
							var l = o.children[a];
							if (l == n) break;
							t += l.height
						}
					return t
				}

				function Xe(e) {
					if (0 == e.height) return 0;
					for (var t, n = e.text.length, r = e; t = ze(r);) {
						var i = t.find(0, !0);
						r = i.from.line, n += i.from.ch - i.to.ch
					}
					for (r = e; t = Pe(r);) {
						var o = t.find(0, !0);
						n -= r.text.length - o.from.ch, n += (r = o.to.line).text.length - o.to.ch
					}
					return n
				}

				function Ke(e) {
					var n = e.display,
						t = e.doc;
					n.maxLine = se(t, t.first), n.maxLineLength = Xe(n.maxLine), n.maxLineChanged = !0, t.iter(function (e) {
						var t = Xe(e);
						t > n.maxLineLength && (n.maxLineLength = t, n.maxLine = e)
					})
				}
				var Ze = null;

				function Ye(e, t, n) {
					var r;
					Ze = null;
					for (var i = 0; i < e.length; ++i) {
						var o = e[i];
						if (o.from < t && o.to > t) return i;
						o.to == t && (o.from != o.to && "before" == n ? r = i : Ze = i), o.from == t && (o.from != o.to && "before" != n ? r = i : Ze =
							i)
					}
					return null != r ? r : Ze
				}
				var Je = function () {
					var H =
						"bbbbbbbbbtstwsbbbbbbbbbbbbbbssstwNN%%%NNNNNN,N,N1111111111NNNNNNNLLLLLLLLLLLLLLLLLLLLLLLLLLNNNNNNLLLLLLLLLLLLLLLLLLLLLLLLLLNNNNbbbbbbsbbbbbbbbbbbbbbbbbbbbbbbbbb,N%%%%NNNNLNNNNN%%11NLNNN1LNNNNNLLLLLLLLLLLLLLLLLLLLLLLNLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLN",
						z =
						"nnnnnnNNr%%r,rNNmmmmmmmmmmmrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrmmmmmmmmmmmmmmmmmmmmmnnnnnnnnnn%nnrrrmrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrrmmmmmmmnNmmmmmmrrmmNmmmmrr1111111111";
					var P = /[\u0590-\u05f4\u0600-\u06ff\u0700-\u08ac]/,
						_ = /[stwN]/,
						W = /[LRr]/,
						j = /[Lb1n]/,
						U = /[1n]/;

					function q(e, t, n) {
						this.level = e, this.from = t, this.to = n
					}
					return function (e, t) {
						var n = "ltr" == t ? "L" : "R";
						if (0 == e.length || "ltr" == t && !P.test(e)) return !1;
						for (var r, i = e.length, o = [], a = 0; a < i; ++a) o.push((r = e.charCodeAt(a)) <= 247 ? H.charAt(r) : 1424 <= r && r <=
							1524 ? "R" : 1536 <= r && r <= 1785 ? z.charAt(r - 1536) : 1774 <= r && r <= 2220 ? "r" : 8192 <= r && r <= 8203 ? "w" :
							8204 == r ? "b" : "L");
						for (var l = 0, s = n; l < i; ++l) {
							var u = o[l];
							"m" == u ? o[l] = s : s = u
						}
						for (var c = 0, h = n; c < i; ++c) {
							var f = o[c];
							"1" == f && "r" == h ? o[c] = "n" : W.test(f) && "r" == (h = f) && (o[c] = "R")
						}
						for (var d = 1, p = o[0]; d < i - 1; ++d) {
							var m = o[d];
							"+" == m && "1" == p && "1" == o[d + 1] ? o[d] = "1" : "," != m || p != o[d + 1] || "1" != p && "n" != p || (o[d] = p), p =
								m
						}
						for (var g = 0; g < i; ++g) {
							var v = o[g];
							if ("," == v) o[g] = "N";
							else if ("%" == v) {
								var y = void 0;
								for (y = g + 1; y < i && "%" == o[y]; ++y);
								for (var x = g && "!" == o[g - 1] || y < i && "1" == o[y] ? "1" : "N", b = g; b < y; ++b) o[b] = x;
								g = y - 1
							}
						}
						for (var w = 0, k = n; w < i; ++w) {
							var C = o[w];
							"L" == k && "1" == C ? o[w] = "L" : W.test(C) && (k = C)
						}
						for (var S = 0; S < i; ++S)
							if (_.test(o[S])) {
								var L = void 0;
								for (L = S + 1; L < i && _.test(o[L]); ++L);
								for (var T = "L" == (S ? o[S - 1] : n), M = T == ("L" == (L < i ? o[L] : n)) ? T ? "L" : "R" : n, A = S; A < L; ++A) o[A] =
									M;
								S = L - 1
							}
						for (var E, N = [], D = 0; D < i;)
							if (j.test(o[D])) {
								var F = D;
								for (++D; D < i && j.test(o[D]); ++D);
								N.push(new q(0, F, D))
							} else {
								var O = D,
									I = N.length;
								for (++D; D < i && "L" != o[D]; ++D);
								for (var B = O; B < D;)
									if (U.test(o[B])) {
										O < B && N.splice(I, 0, new q(1, O, B));
										var R = B;
										for (++B; B < D && U.test(o[B]); ++B);
										N.splice(I, 0, new q(2, R, B)), O = B
									} else ++B;
								O < D && N.splice(I, 0, new q(1, O, D))
							}
						return "ltr" == t && (1 == N[0].level && (E = e.match(/^\s+/)) && (N[0].from = E[0].length, N.unshift(new q(0, 0, E[0].length))),
								1 == K(N).level && (E = e.match(/\s+$/)) && (K(N).to -= E[0].length, N.push(new q(0, i - E[0].length, i)))), "rtl" == t ? N
							.reverse() : N
					}
				}();

				function Qe(e, t) {
					var n = e.order;
					return null == n && (n = e.order = Je(e.text, t)), n
				}
				var et = [],
					tt = function (e, t, n) {
						if (e.addEventListener) e.addEventListener(t, n, !1);
						else if (e.attachEvent) e.attachEvent("on" + t, n);
						else {
							var r = e._handlers || (e._handlers = {});
							r[t] = (r[t] || et).concat(n)
						}
					};

				function nt(e, t) {
					return e._handlers && e._handlers[t] || et
				}

				function rt(e, t, n) {
					if (e.removeEventListener) e.removeEventListener(t, n, !1);
					else if (e.detachEvent) e.detachEvent("on" + t, n);
					else {
						var r = e._handlers,
							i = r && r[t];
						if (i) {
							var o = _(i, n); - 1 < o && (r[t] = i.slice(0, o).concat(i.slice(o + 1)))
						}
					}
				}

				function it(e, t) {
					var n = nt(e, t);
					if (n.length)
						for (var r = Array.prototype.slice.call(arguments, 2), i = 0; i < n.length; ++i) n[i].apply(null, r)
				}

				function ot(e, t, n) {
					return "string" == typeof t && (t = {
						type: t,
						preventDefault: function () {
							this.defaultPrevented = !0
						}
					}), it(e, n || t.type, e, t), ht(t) || t.codemirrorIgnore
				}

				function at(e) {
					var t = e._handlers && e._handlers.cursorActivity;
					if (t)
						for (var n = e.curOp.cursorActivityHandlers || (e.curOp.cursorActivityHandlers = []), r = 0; r < t.length; ++r) - 1 == _(n, t[r]) &&
							n.push(t[r])
				}

				function lt(e, t) {
					return 0 < nt(e, t).length
				}

				function st(e) {
					e.prototype.on = function (e, t) {
						tt(this, e, t)
					}, e.prototype.off = function (e, t) {
						rt(this, e, t)
					}
				}

				function ut(e) {
					e.preventDefault ? e.preventDefault() : e.returnValue = !1
				}

				function ct(e) {
					e.stopPropagation ? e.stopPropagation() : e.cancelBubble = !0
				}

				function ht(e) {
					return null != e.defaultPrevented ? e.defaultPrevented : 0 == e.returnValue
				}

				function ft(e) {
					ut(e), ct(e)
				}

				function dt(e) {
					return e.target || e.srcElement
				}

				function pt(e) {
					var t = e.which;
					return null == t && (1 & e.button ? t = 1 : 2 & e.button ? t = 3 : 4 & e.button && (t = 2)), b && e.ctrlKey && 1 == t && (t = 3),
						t
				}
				var mt, gt, vt = function () {
					if (w && k < 9) return !1;
					var e = N("div");
					return "draggable" in e || "dragDrop" in e
				}();

				function yt(e) {
					if (null == mt) {
						var t = N("span", "​");
						A(e, N("span", [t, document.createTextNode("x")])), 0 != e.firstChild.offsetHeight && (mt = t.offsetWidth <= 1 && 2 < t.offsetHeight &&
							!(w && k < 8))
					}
					var n = mt ? N("span", "​") : N("span", " ", null, "display: inline-block; width: 1px; margin-right: -1px");
					return n.setAttribute("cm-text", ""), n
				}

				function xt(e) {
					if (null != gt) return gt;
					var t = A(e, document.createTextNode("AخA")),
						n = L(t, 0, 1).getBoundingClientRect(),
						r = L(t, 1, 2).getBoundingClientRect();
					return M(e), !(!n || n.left == n.right) && (gt = r.right - n.right < 3)
				}
				var bt, wt = 3 != "\n\nb".split(/\n/).length ? function (e) {
						for (var t = 0, n = [], r = e.length; t <= r;) {
							var i = e.indexOf("\n", t); - 1 == i && (i = e.length);
							var o = e.slice(t, "\r" == e.charAt(i - 1) ? i - 1 : i),
								a = o.indexOf("\r"); - 1 != a ? (n.push(o.slice(0, a)), t += a + 1) : (n.push(o), t = i + 1)
						}
						return n
					} : function (e) {
						return e.split(/\r\n?|\n/)
					},
					kt = window.getSelection ? function (e) {
						try {
							return e.selectionStart != e.selectionEnd
						} catch (e) {
							return !1
						}
					} : function (e) {
						var t;
						try {
							t = e.ownerDocument.selection.createRange()
						} catch (e) {}
						return !(!t || t.parentElement() != e) && 0 != t.compareEndPoints("StartToEnd", t)
					},
					Ct = "oncopy" in (bt = N("div")) || (bt.setAttribute("oncopy", "return;"), "function" == typeof bt.oncopy),
					St = null;
				var Lt = {},
					Tt = {};

				function Mt(e) {
					if ("string" == typeof e && Tt.hasOwnProperty(e)) e = Tt[e];
					else if (e && "string" == typeof e.name && Tt.hasOwnProperty(e.name)) {
						var t = Tt[e.name];
						"string" == typeof t && (t = {
							name: t
						}), (e = J(t, e)).name = t.name
					} else {
						if ("string" == typeof e && /^[\w\-]+\/[\w\-]+\+xml$/.test(e)) return Mt("application/xml");
						if ("string" == typeof e && /^[\w\-]+\/[\w\-]+\+json$/.test(e)) return Mt("application/json")
					}
					return "string" == typeof e ? {
						name: e
					} : e || {
						name: "null"
					}
				}

				function At(e, t) {
					t = Mt(t);
					var n = Lt[t.name];
					if (!n) return At(e, "text/plain");
					var r = n(e, t);
					if (Et.hasOwnProperty(t.name)) {
						var i = Et[t.name];
						for (var o in i) i.hasOwnProperty(o) && (r.hasOwnProperty(o) && (r["_" + o] = r[o]), r[o] = i[o])
					}
					if (r.name = t.name, t.helperType && (r.helperType = t.helperType), t.modeProps)
						for (var a in t.modeProps) r[a] = t.modeProps[a];
					return r
				}
				var Et = {};

				function Nt(e, t) {
					H(t, Et.hasOwnProperty(e) ? Et[e] : Et[e] = {})
				}

				function Dt(e, t) {
					if (!0 === t) return t;
					if (e.copyState) return e.copyState(t);
					var n = {};
					for (var r in t) {
						var i = t[r];
						i instanceof Array && (i = i.concat([])), n[r] = i
					}
					return n
				}

				function Ft(e, t) {
					for (var n; e.innerMode && (n = e.innerMode(t)) && n.mode != e;) t = n.state, e = n.mode;
					return n || {
						mode: e,
						state: t
					}
				}

				function Ot(e, t, n) {
					return !e.startState || e.startState(t, n)
				}
				var It = function (e, t, n) {
					this.pos = this.start = 0, this.string = e, this.tabSize = t || 8, this.lastColumnPos = this.lastColumnValue = 0, this.lineStart =
						0, this.lineOracle = n
				};
				It.prototype.eol = function () {
					return this.pos >= this.string.length
				}, It.prototype.sol = function () {
					return this.pos == this.lineStart
				}, It.prototype.peek = function () {
					return this.string.charAt(this.pos) || void 0
				}, It.prototype.next = function () {
					if (this.pos < this.string.length) return this.string.charAt(this.pos++)
				}, It.prototype.eat = function (e) {
					var t = this.string.charAt(this.pos);
					if ("string" == typeof e ? t == e : t && (e.test ? e.test(t) : e(t))) return ++this.pos, t
				}, It.prototype.eatWhile = function (e) {
					for (var t = this.pos; this.eat(e););
					return this.pos > t
				}, It.prototype.eatSpace = function () {
					for (var e = this.pos;
						/[\s\u00a0]/.test(this.string.charAt(this.pos));) ++this.pos;
					return this.pos > e
				}, It.prototype.skipToEnd = function () {
					this.pos = this.string.length
				}, It.prototype.skipTo = function (e) {
					var t = this.string.indexOf(e, this.pos);
					if (-1 < t) return this.pos = t, !0
				}, It.prototype.backUp = function (e) {
					this.pos -= e
				}, It.prototype.column = function () {
					return this.lastColumnPos < this.start && (this.lastColumnValue = z(this.string, this.start, this.tabSize, this.lastColumnPos,
						this.lastColumnValue), this.lastColumnPos = this.start), this.lastColumnValue - (this.lineStart ? z(this.string, this.lineStart,
						this.tabSize) : 0)
				}, It.prototype.indentation = function () {
					return z(this.string, null, this.tabSize) - (this.lineStart ? z(this.string, this.lineStart, this.tabSize) : 0)
				}, It.prototype.match = function (e, t, n) {
					if ("string" != typeof e) {
						var r = this.string.slice(this.pos).match(e);
						return r && 0 < r.index ? null : (r && !1 !== t && (this.pos += r[0].length), r)
					}
					var i = function (e) {
						return n ? e.toLowerCase() : e
					};
					if (i(this.string.substr(this.pos, e.length)) == i(e)) return !1 !== t && (this.pos += e.length), !0
				}, It.prototype.current = function () {
					return this.string.slice(this.start, this.pos)
				}, It.prototype.hideFirstChars = function (e, t) {
					this.lineStart += e;
					try {
						return t()
					} finally {
						this.lineStart -= e
					}
				}, It.prototype.lookAhead = function (e) {
					var t = this.lineOracle;
					return t && t.lookAhead(e)
				}, It.prototype.baseToken = function () {
					var e = this.lineOracle;
					return e && e.baseToken(this.pos)
				};
				var Bt = function (e, t) {
						this.state = e, this.lookAhead = t
					},
					Rt = function (e, t, n, r) {
						this.state = t, this.doc = e, this.line = n, this.maxLookAhead = r || 0, this.baseTokens = null, this.baseTokenPos = 1
					};

				function Ht(t, n, r, e) {
					var s = [t.state.modeGen],
						i = {};
					Gt(t, n.text, t.doc.mode, r, function (e, t) {
						return s.push(e, t)
					}, i, e);
					for (var u = r.state, o = function (e) {
							r.baseTokens = s;
							var o = t.state.overlays[e],
								a = 1,
								l = 0;
							r.state = !0, Gt(t, n.text, o.mode, r, function (e, t) {
								for (var n = a; l < e;) {
									var r = s[a];
									e < r && s.splice(a, 1, e, s[a + 1], r), a += 2, l = Math.min(e, r)
								}
								if (t)
									if (o.opaque) s.splice(n, a - n, e, "overlay " + t), a = n + 2;
									else
										for (; n < a; n += 2) {
											var i = s[n + 1];
											s[n + 1] = (i ? i + " " : "") + "overlay " + t
										}
							}, i), r.state = u, r.baseTokens = null, r.baseTokenPos = 1
						}, a = 0; a < t.state.overlays.length; ++a) o(a);
					return {
						styles: s,
						classes: i.bgClass || i.textClass ? i : null
					}
				}

				function zt(e, t, n) {
					if (!t.styles || t.styles[0] != e.state.modeGen) {
						var r = Pt(e, fe(t)),
							i = t.text.length > e.options.maxHighlightLength && Dt(e.doc.mode, r.state),
							o = Ht(e, t, r);
						i && (r.state = i), t.stateAfter = r.save(!i), t.styles = o.styles, o.classes ? t.styleClasses = o.classes : t.styleClasses &&
							(t.styleClasses = null), n === e.doc.highlightFrontier && (e.doc.modeFrontier = Math.max(e.doc.modeFrontier, ++e.doc.highlightFrontier))
					}
					return t.styles
				}

				function Pt(n, r, e) {
					var t = n.doc,
						i = n.display;
					if (!t.mode.startState) return new Rt(t, !0, r);
					var o = function (e, t, n) {
							for (var r, i, o = e.doc, a = n ? -1 : t - (e.doc.mode.innerMode ? 1e3 : 100), l = t; a < l; --l) {
								if (l <= o.first) return o.first;
								var s = se(o, l - 1),
									u = s.stateAfter;
								if (u && (!n || l + (u instanceof Bt ? u.lookAhead : 0) <= o.modeFrontier)) return l;
								var c = z(s.text, null, e.options.tabSize);
								(null == i || c < r) && (i = l - 1, r = c)
							}
							return i
						}(n, r, e),
						a = o > t.first && se(t, o - 1).stateAfter,
						l = a ? Rt.fromSaved(t, a, o) : new Rt(t, Ot(t.mode), o);
					return t.iter(o, r, function (e) {
						_t(n, e.text, l);
						var t = l.line;
						e.stateAfter = t == r - 1 || t % 5 == 0 || t >= i.viewFrom && t < i.viewTo ? l.save() : null, l.nextLine()
					}), e && (t.modeFrontier = l.line), l
				}

				function _t(e, t, n, r) {
					var i = e.doc.mode,
						o = new It(t, e.options.tabSize, n);
					for (o.start = o.pos = r || 0, "" == t && Wt(i, n.state); !o.eol();) jt(i, o, n.state), o.start = o.pos
				}

				function Wt(e, t) {
					if (e.blankLine) return e.blankLine(t);
					if (e.innerMode) {
						var n = Ft(e, t);
						return n.mode.blankLine ? n.mode.blankLine(n.state) : void 0
					}
				}

				function jt(e, t, n, r) {
					for (var i = 0; i < 10; i++) {
						r && (r[0] = Ft(e, n).mode);
						var o = e.token(t, n);
						if (t.pos > t.start) return o
					}
					throw new Error("Mode " + e.name + " failed to advance stream.")
				}
				Rt.prototype.lookAhead = function (e) {
					var t = this.doc.getLine(this.line + e);
					return null != t && e > this.maxLookAhead && (this.maxLookAhead = e), t
				}, Rt.prototype.baseToken = function (e) {
					if (!this.baseTokens) return null;
					for (; this.baseTokens[this.baseTokenPos] <= e;) this.baseTokenPos += 2;
					var t = this.baseTokens[this.baseTokenPos + 1];
					return {
						type: t && t.replace(/( |^)overlay .*/, ""),
						size: this.baseTokens[this.baseTokenPos] - e
					}
				}, Rt.prototype.nextLine = function () {
					this.line++, 0 < this.maxLookAhead && this.maxLookAhead--
				}, Rt.fromSaved = function (e, t, n) {
					return t instanceof Bt ? new Rt(e, Dt(e.mode, t.state), n, t.lookAhead) : new Rt(e, Dt(e.mode, t), n)
				}, Rt.prototype.save = function (e) {
					var t = !1 !== e ? Dt(this.doc.mode, this.state) : this.state;
					return 0 < this.maxLookAhead ? new Bt(t, this.maxLookAhead) : t
				};
				var Ut = function (e, t, n) {
					this.start = e.start, this.end = e.pos, this.string = e.current(), this.type = t || null, this.state = n
				};

				function qt(e, t, n, r) {
					var i, o, a = e.doc,
						l = a.mode,
						s = se(a, (t = Ce(a, t)).line),
						u = Pt(e, t.line, n),
						c = new It(s.text, e.options.tabSize, u);
					for (r && (o = []);
						(r || c.pos < t.ch) && !c.eol();) c.start = c.pos, i = jt(l, c, u.state), r && o.push(new Ut(c, i, Dt(a.mode, u.state)));
					return r ? o : new Ut(c, i, u.state)
				}

				function $t(e, t) {
					if (e)
						for (;;) {
							var n = e.match(/(?:^|\s+)line-(background-)?(\S+)/);
							if (!n) break;
							e = e.slice(0, n.index) + e.slice(n.index + n[0].length);
							var r = n[1] ? "bgClass" : "textClass";
							null == t[r] ? t[r] = n[2] : new RegExp("(?:^|s)" + n[2] + "(?:$|s)").test(t[r]) || (t[r] += " " + n[2])
						}
					return e
				}

				function Gt(e, t, n, r, i, o, a) {
					var l = n.flattenSpans;
					null == l && (l = e.options.flattenSpans);
					var s, u = 0,
						c = null,
						h = new It(t, e.options.tabSize, r),
						f = e.options.addModeClass && [null];
					for ("" == t && $t(Wt(n, r.state), o); !h.eol();) {
						if (s = h.pos > e.options.maxHighlightLength ? (l = !1, a && _t(e, t, r, h.pos), h.pos = t.length, null) : $t(jt(n, h, r.state,
								f), o), f) {
							var d = f[0].name;
							d && (s = "m-" + (s ? d + " " + s : d))
						}
						if (!l || c != s) {
							for (; u < h.start;) i(u = Math.min(h.start, u + 5e3), c);
							c = s
						}
						h.start = h.pos
					}
					for (; u < h.pos;) {
						var p = Math.min(h.pos, u + 5e3);
						i(p, c), u = p
					}
				}
				var Vt = function (e, t, n) {
					this.text = e, Oe(this, t), this.height = n ? n(this) : 1
				};
				Vt.prototype.lineNo = function () {
					return fe(this)
				}, st(Vt);
				var Xt = {},
					Kt = {};

				function Zt(e, t) {
					if (!e || /^\s*$/.test(e)) return null;
					var n = t.addModeClass ? Kt : Xt;
					return n[e] || (n[e] = e.replace(/\S+/g, "cm-$&"))
				}

				function Yt(e, t) {
					var n = E("span", null, null, x ? "padding-right: .1px" : null),
						r = {
							pre: E("pre", [n], "CodeMirror-line"),
							content: n,
							col: 0,
							pos: 0,
							cm: e,
							trailingSpace: !1,
							splitSpaces: e.getOption("lineWrapping")
						};
					t.measure = {};
					for (var i = 0; i <= (t.rest ? t.rest.length : 0); i++) {
						var o = i ? t.rest[i - 1] : t.line,
							a = void 0;
						r.pos = 0, r.addToken = Qt, xt(e.display.measure) && (a = Qe(o, e.doc.direction)) && (r.addToken = en(r.addToken, a)), r.map = [],
							nn(o, r, zt(e, o, t != e.display.externalMeasured && fe(o))), o.styleClasses && (o.styleClasses.bgClass && (r.bgClass = I(o.styleClasses
								.bgClass, r.bgClass || "")), o.styleClasses.textClass && (r.textClass = I(o.styleClasses.textClass, r.textClass || ""))), 0 ==
							r.map.length && r.map.push(0, 0, r.content.appendChild(yt(e.display.measure))), 0 == i ? (t.measure.map = r.map, t.measure.cache = {}) :
							((t.measure.maps || (t.measure.maps = [])).push(r.map), (t.measure.caches || (t.measure.caches = [])).push({}))
					}
					if (x) {
						var l = r.content.lastChild;
						(/\bcm-tab\b/.test(l.className) || l.querySelector && l.querySelector(".cm-tab")) && (r.content.className = "cm-tab-wrap-hack")
					}
					return it(e, "renderLine", e, t.line, r.pre), r.pre.className && (r.textClass = I(r.pre.className, r.textClass || "")), r
				}

				function Jt(e) {
					var t = N("span", "•", "cm-invalidchar");
					return t.title = "\\u" + e.charCodeAt(0).toString(16), t.setAttribute("aria-label", t.title), t
				}

				function Qt(e, t, n, r, i, o, a) {
					if (t) {
						var l, s = e.splitSpaces ? function (e, t) {
								if (1 < e.length && !/  /.test(e)) return e;
								for (var n = t, r = "", i = 0; i < e.length; i++) {
									var o = e.charAt(i);
									" " != o || !n || i != e.length - 1 && 32 != e.charCodeAt(i + 1) || (o = " "), r += o, n = " " == o
								}
								return r
							}(t, e.trailingSpace) : t,
							u = e.cm.state.specialChars,
							c = !1;
						if (u.test(t)) {
							l = document.createDocumentFragment();
							for (var h = 0;;) {
								u.lastIndex = h;
								var f = u.exec(t),
									d = f ? f.index - h : t.length - h;
								if (d) {
									var p = document.createTextNode(s.slice(h, h + d));
									w && k < 9 ? l.appendChild(N("span", [p])) : l.appendChild(p), e.map.push(e.pos, e.pos + d, p), e.col += d, e.pos += d
								}
								if (!f) break;
								h += d + 1;
								var m = void 0;
								if ("\t" == f[0]) {
									var g = e.cm.options.tabSize,
										v = g - e.col % g;
									(m = l.appendChild(N("span", X(v), "cm-tab"))).setAttribute("role", "presentation"), m.setAttribute("cm-text", "\t"), e.col +=
										v
								} else "\r" == f[0] || "\n" == f[0] ? (m = l.appendChild(N("span", "\r" == f[0] ? "␍" : "␤", "cm-invalidchar"))).setAttribute(
									"cm-text", f[0]) : ((m = e.cm.options.specialCharPlaceholder(f[0])).setAttribute("cm-text", f[0]), w && k < 9 ? l.appendChild(
									N("span", [m])) : l.appendChild(m)), e.col += 1;
								e.map.push(e.pos, e.pos + 1, m), e.pos++
							}
						} else e.col += t.length, l = document.createTextNode(s), e.map.push(e.pos, e.pos + t.length, l), w && k < 9 && (c = !0), e.pos +=
							t.length;
						if (e.trailingSpace = 32 == s.charCodeAt(t.length - 1), n || r || i || c || o) {
							var y = n || "";
							r && (y += r), i && (y += i);
							var x = N("span", [l], y, o);
							if (a)
								for (var b in a) a.hasOwnProperty(b) && "style" != b && "class" != b && x.setAttribute(b, a[b]);
							return e.content.appendChild(x)
						}
						e.content.appendChild(l)
					}
				}

				function en(h, f) {
					return function (e, t, n, r, i, o, a) {
						n = n ? n + " cm-force-border" : "cm-force-border";
						for (var l = e.pos, s = l + t.length;;) {
							for (var u = void 0, c = 0; c < f.length && !((u = f[c]).to > l && u.from <= l); c++);
							if (u.to >= s) return h(e, t, n, r, i, o, a);
							h(e, t.slice(0, u.to - l), n, r, null, o, a), r = null, t = t.slice(u.to - l), l = u.to
						}
					}
				}

				function tn(e, t, n, r) {
					var i = !r && n.widgetNode;
					i && e.map.push(e.pos, e.pos + t, i), !r && e.cm.display.input.needsContentAttribute && (i || (i = e.content.appendChild(
						document.createElement("span"))), i.setAttribute("cm-marker", n.id)), i && (e.cm.display.input.setUneditable(i), e.content.appendChild(
						i)), e.pos += t, e.trailingSpace = !1
				}

				function nn(e, t, n) {
					var r = e.markedSpans,
						i = e.text,
						o = 0;
					if (r)
						for (var a, l, s, u, c, h, f, d = i.length, p = 0, m = 1, g = "", v = 0;;) {
							if (v == p) {
								s = u = c = l = "", h = f = null, v = 1 / 0;
								for (var y = [], x = void 0, b = 0; b < r.length; ++b) {
									var w = r[b],
										k = w.marker;
									if ("bookmark" == k.type && w.from == p && k.widgetNode) y.push(k);
									else if (w.from <= p && (null == w.to || w.to > p || k.collapsed && w.to == p && w.from == p)) {
										if (null != w.to && w.to != p && v > w.to && (v = w.to, u = ""), k.className && (s += " " + k.className), k.css && (l = (l ?
												l + ";" : "") + k.css), k.startStyle && w.from == p && (c += " " + k.startStyle), k.endStyle && w.to == v && (x || (x = []))
											.push(k.endStyle, w.to), k.title && ((f || (f = {})).title = k.title), k.attributes)
											for (var C in k.attributes)(f || (f = {}))[C] = k.attributes[C];
										k.collapsed && (!h || Re(h.marker, k) < 0) && (h = w)
									} else w.from > p && v > w.from && (v = w.from)
								}
								if (x)
									for (var S = 0; S < x.length; S += 2) x[S + 1] == v && (u += " " + x[S]);
								if (!h || h.from == p)
									for (var L = 0; L < y.length; ++L) tn(t, 0, y[L]);
								if (h && (h.from || 0) == p) {
									if (tn(t, (null == h.to ? d + 1 : h.to) - p, h.marker, null == h.from), null == h.to) return;
									h.to == p && (h = !1)
								}
							}
							if (d <= p) break;
							for (var T = Math.min(d, v);;) {
								if (g) {
									var M = p + g.length;
									if (!h) {
										var A = T < M ? g.slice(0, T - p) : g;
										t.addToken(t, A, a ? a + s : s, c, p + A.length == v ? u : "", l, f)
									}
									if (T <= M) {
										g = g.slice(T - p), p = T;
										break
									}
									p = M, c = ""
								}
								g = i.slice(o, o = n[m++]), a = Zt(n[m++], t.cm.options)
							}
						} else
							for (var E = 1; E < n.length; E += 2) t.addToken(t, i.slice(o, o = n[E]), Zt(n[E + 1], t.cm.options))
				}

				function rn(e, t, n) {
					this.line = t, this.rest = function (e) {
						for (var t, n; t = Pe(e);) e = t.find(1, !0).line, (n || (n = [])).push(e);
						return n
					}(t), this.size = this.rest ? fe(K(this.rest)) - n + 1 : 1, this.node = this.text = null, this.hidden = $e(e, t)
				}

				function on(e, t, n) {
					for (var r, i = [], o = t; o < n; o = r) {
						var a = new rn(e.doc, se(e.doc, o), o);
						r = o + a.size, i.push(a)
					}
					return i
				}
				var an = null;
				var ln = null;

				function sn(e, t) {
					var n = nt(e, t);
					if (n.length) {
						var r, i = Array.prototype.slice.call(arguments, 2);
						an ? r = an.delayedCallbacks : ln ? r = ln : (r = ln = [], setTimeout(un, 0));
						for (var o = function (e) {
								r.push(function () {
									return n[e].apply(null, i)
								})
							}, a = 0; a < n.length; ++a) o(a)
					}
				}

				function un() {
					var e = ln;
					ln = null;
					for (var t = 0; t < e.length; ++t) e[t]()
				}

				function cn(e, t, n, r) {
					for (var i = 0; i < t.changes.length; i++) {
						var o = t.changes[i];
						"text" == o ? dn(e, t) : "gutter" == o ? mn(e, t, n, r) : "class" == o ? pn(e, t) : "widget" == o && gn(e, t, r)
					}
					t.changes = null
				}

				function hn(e) {
					return e.node == e.text && (e.node = N("div", null, null, "position: relative"), e.text.parentNode && e.text.parentNode.replaceChild(
						e.node, e.text), e.node.appendChild(e.text), w && k < 8 && (e.node.style.zIndex = 2)), e.node
				}

				function fn(e, t) {
					var n = e.display.externalMeasured;
					return n && n.line == t.line ? (e.display.externalMeasured = null, t.measure = n.measure, n.built) : Yt(e, t)
				}

				function dn(e, t) {
					var n = t.text.className,
						r = fn(e, t);
					t.text == t.node && (t.node = r.pre), t.text.parentNode.replaceChild(r.pre, t.text), t.text = r.pre, r.bgClass != t.bgClass || r
						.textClass != t.textClass ? (t.bgClass = r.bgClass, t.textClass = r.textClass, pn(e, t)) : n && (t.text.className = n)
				}

				function pn(e, t) {
					! function (e, t) {
						var n = t.bgClass ? t.bgClass + " " + (t.line.bgClass || "") : t.line.bgClass;
						if (n && (n += " CodeMirror-linebackground"), t.background) n ? t.background.className = n : (t.background.parentNode.removeChild(
							t.background), t.background = null);
						else if (n) {
							var r = hn(t);
							t.background = r.insertBefore(N("div", null, n), r.firstChild), e.display.input.setUneditable(t.background)
						}
					}(e, t), t.line.wrapClass ? hn(t).className = t.line.wrapClass : t.node != t.text && (t.node.className = "");
					var n = t.textClass ? t.textClass + " " + (t.line.textClass || "") : t.line.textClass;
					t.text.className = n || ""
				}

				function mn(e, t, n, r) {
					if (t.gutter && (t.node.removeChild(t.gutter), t.gutter = null), t.gutterBackground && (t.node.removeChild(t.gutterBackground),
							t.gutterBackground = null), t.line.gutterClass) {
						var i = hn(t);
						t.gutterBackground = N("div", null, "CodeMirror-gutter-background " + t.line.gutterClass, "left: " + (e.options.fixedGutter ? r
								.fixedPos : -r.gutterTotalWidth) + "px; width: " + r.gutterTotalWidth + "px"), e.display.input.setUneditable(t.gutterBackground),
							i.insertBefore(t.gutterBackground, t.text)
					}
					var o = t.line.gutterMarkers;
					if (e.options.lineNumbers || o) {
						var a = hn(t),
							l = t.gutter = N("div", null, "CodeMirror-gutter-wrapper", "left: " + (e.options.fixedGutter ? r.fixedPos : -r.gutterTotalWidth) +
								"px");
						if (e.display.input.setUneditable(l), a.insertBefore(l, t.text), t.line.gutterClass && (l.className += " " + t.line.gutterClass), !
							e.options.lineNumbers || o && o["CodeMirror-linenumbers"] || (t.lineNumber = l.appendChild(N("div", me(e.options, n),
								"CodeMirror-linenumber CodeMirror-gutter-elt", "left: " + r.gutterLeft["CodeMirror-linenumbers"] + "px; width: " + e.display
								.lineNumInnerWidth + "px"))), o)
							for (var s = 0; s < e.options.gutters.length; ++s) {
								var u = e.options.gutters[s],
									c = o.hasOwnProperty(u) && o[u];
								c && l.appendChild(N("div", [c], "CodeMirror-gutter-elt", "left: " + r.gutterLeft[u] + "px; width: " + r.gutterWidth[u] +
									"px"))
							}
					}
				}

				function gn(e, t, n) {
					t.alignable && (t.alignable = null);
					for (var r = t.node.firstChild, i = void 0; r; r = i) i = r.nextSibling, "CodeMirror-linewidget" == r.className && t.node.removeChild(
						r);
					vn(e, t, n)
				}

				function vn(e, t, n) {
					if (yn(e, t.line, t, n, !0), t.rest)
						for (var r = 0; r < t.rest.length; r++) yn(e, t.rest[r], t, n, !1)
				}

				function yn(e, t, n, r, i) {
					if (t.widgets)
						for (var o = hn(n), a = 0, l = t.widgets; a < l.length; ++a) {
							var s = l[a],
								u = N("div", [s.node], "CodeMirror-linewidget");
							s.handleMouseEvents || u.setAttribute("cm-ignore-events", "true"), xn(s, u, n, r), e.display.input.setUneditable(u), i && s.above ?
								o.insertBefore(u, n.gutter || n.text) : o.appendChild(u), sn(s, "redraw")
						}
				}

				function xn(e, t, n, r) {
					if (e.noHScroll) {
						(n.alignable || (n.alignable = [])).push(t);
						var i = r.wrapperWidth;
						t.style.left = r.fixedPos + "px", e.coverGutter || (i -= r.gutterTotalWidth, t.style.paddingLeft = r.gutterTotalWidth + "px"),
							t.style.width = i + "px"
					}
					e.coverGutter && (t.style.zIndex = 5, t.style.position = "relative", e.noHScroll || (t.style.marginLeft = -r.gutterTotalWidth +
						"px"))
				}

				function bn(e) {
					if (null != e.height) return e.height;
					var t = e.doc.cm;
					if (!t) return 0;
					if (!D(document.body, e.node)) {
						var n = "position: relative;";
						e.coverGutter && (n += "margin-left: -" + t.display.gutters.offsetWidth + "px;"), e.noHScroll && (n += "width: " + t.display.wrapper
							.clientWidth + "px;"), A(t.display.measure, N("div", [e.node], null, n))
					}
					return e.height = e.node.parentNode.offsetHeight
				}

				function wn(e, t) {
					for (var n = dt(t); n != e.wrapper; n = n.parentNode)
						if (!n || 1 == n.nodeType && "true" == n.getAttribute("cm-ignore-events") || n.parentNode == e.sizer && n != e.mover) return !0
				}

				function kn(e) {
					return e.lineSpace.offsetTop
				}

				function Cn(e) {
					return e.mover.offsetHeight - e.lineSpace.offsetHeight
				}

				function Sn(e) {
					if (e.cachedPaddingH) return e.cachedPaddingH;
					var t = A(e.measure, N("pre", "x")),
						n = window.getComputedStyle ? window.getComputedStyle(t) : t.currentStyle,
						r = {
							left: parseInt(n.paddingLeft),
							right: parseInt(n.paddingRight)
						};
					return isNaN(r.left) || isNaN(r.right) || (e.cachedPaddingH = r), r
				}

				function Ln(e) {
					return W - e.display.nativeBarWidth
				}

				function Tn(e) {
					return e.display.scroller.clientWidth - Ln(e) - e.display.barWidth
				}

				function Mn(e) {
					return e.display.scroller.clientHeight - Ln(e) - e.display.barHeight
				}

				function An(e, t, n) {
					if (e.line == t) return {
						map: e.measure.map,
						cache: e.measure.cache
					};
					for (var r = 0; r < e.rest.length; r++)
						if (e.rest[r] == t) return {
							map: e.measure.maps[r],
							cache: e.measure.caches[r]
						};
					for (var i = 0; i < e.rest.length; i++)
						if (fe(e.rest[i]) > n) return {
							map: e.measure.maps[i],
							cache: e.measure.caches[i],
							before: !0
						}
				}

				function En(e, t, n, r) {
					return Fn(e, Dn(e, t), n, r)
				}

				function Nn(e, t) {
					if (t >= e.display.viewFrom && t < e.display.viewTo) return e.display.view[lr(e, t)];
					var n = e.display.externalMeasured;
					return n && t >= n.lineN && t < n.lineN + n.size ? n : void 0
				}

				function Dn(e, t) {
					var n = fe(t),
						r = Nn(e, n);
					r && !r.text ? r = null : r && r.changes && (cn(e, r, n, nr(e)), e.curOp.forceUpdate = !0), r || (r = function (e, t) {
						var n = fe(t = je(t)),
							r = e.display.externalMeasured = new rn(e.doc, t, n);
						r.lineN = n;
						var i = r.built = Yt(e, r);
						return r.text = i.pre, A(e.display.lineMeasure, i.pre), r
					}(e, t));
					var i = An(r, t, n);
					return {
						line: t,
						view: r,
						rect: null,
						map: i.map,
						cache: i.cache,
						before: i.before,
						hasHeights: !1
					}
				}

				function Fn(e, t, n, r, i) {
					t.before && (n = -1);
					var o, a = n + (r || "");
					return t.cache.hasOwnProperty(a) ? o = t.cache[a] : (t.rect || (t.rect = t.view.text.getBoundingClientRect()), t.hasHeights || (!
						function (e, t, n) {
							var r = e.options.lineWrapping,
								i = r && Tn(e);
							if (!t.measure.heights || r && t.measure.width != i) {
								var o = t.measure.heights = [];
								if (r) {
									t.measure.width = i;
									for (var a = t.text.firstChild.getClientRects(), l = 0; l < a.length - 1; l++) {
										var s = a[l],
											u = a[l + 1];
										2 < Math.abs(s.bottom - u.bottom) && o.push((s.bottom + u.top) / 2 - n.top)
									}
								}
								o.push(n.bottom - n.top)
							}
						}(e, t.view, t.rect), t.hasHeights = !0), (o = function (e, t, n, r) {
						var i, o = Bn(t.map, n, r),
							a = o.node,
							l = o.start,
							s = o.end,
							u = o.collapse;
						if (3 == a.nodeType) {
							for (var c = 0; c < 4; c++) {
								for (; l && ie(t.line.text.charAt(o.coverStart + l));) --l;
								for (; o.coverStart + s < o.coverEnd && ie(t.line.text.charAt(o.coverStart + s));) ++s;
								if ((i = w && k < 9 && 0 == l && s == o.coverEnd - o.coverStart ? a.parentNode.getBoundingClientRect() : Rn(L(a, l, s).getClientRects(),
										r)).left || i.right || 0 == l) break;
								s = l, l -= 1, u = "right"
							}
							w && k < 11 && (i = function (e, t) {
								if (!window.screen || null == screen.logicalXDPI || screen.logicalXDPI == screen.deviceXDPI || ! function (e) {
										if (null != St) return St;
										var t = A(e, N("span", "x")),
											n = t.getBoundingClientRect(),
											r = L(t, 0, 1).getBoundingClientRect();
										return St = 1 < Math.abs(n.left - r.left)
									}(e)) return t;
								var n = screen.logicalXDPI / screen.deviceXDPI,
									r = screen.logicalYDPI / screen.deviceYDPI;
								return {
									left: t.left * n,
									right: t.right * n,
									top: t.top * r,
									bottom: t.bottom * r
								}
							}(e.display.measure, i))
						} else {
							var h;
							0 < l && (u = r = "right"), i = e.options.lineWrapping && 1 < (h = a.getClientRects()).length ? h["right" == r ? h.length -
								1 : 0] : a.getBoundingClientRect()
						}
						if (w && k < 9 && !l && (!i || !i.left && !i.right)) {
							var f = a.parentNode.getClientRects()[0];
							i = f ? {
								left: f.left,
								right: f.left + tr(e.display),
								top: f.top,
								bottom: f.bottom
							} : In
						}
						for (var d = i.top - t.rect.top, p = i.bottom - t.rect.top, m = (d + p) / 2, g = t.view.measure.heights, v = 0; v < g.length -
							1 && !(m < g[v]); v++);
						var y = v ? g[v - 1] : 0,
							x = g[v],
							b = {
								left: ("right" == u ? i.right : i.left) - t.rect.left,
								right: ("left" == u ? i.left : i.right) - t.rect.left,
								top: y,
								bottom: x
							};
						i.left || i.right || (b.bogus = !0);
						e.options.singleCursorHeightPerLine || (b.rtop = d, b.rbottom = p);
						return b
					}(e, t, n, r)).bogus || (t.cache[a] = o)), {
						left: o.left,
						right: o.right,
						top: i ? o.rtop : o.top,
						bottom: i ? o.rbottom : o.bottom
					}
				}
				var On, In = {
					left: 0,
					right: 0,
					top: 0,
					bottom: 0
				};

				function Bn(e, t, n) {
					for (var r, i, o, a, l, s, u = 0; u < e.length; u += 3)
						if (l = e[u], s = e[u + 1], t < l ? (i = 0, o = 1, a = "left") : t < s ? o = (i = t - l) + 1 : (u == e.length - 3 || t == s &&
								e[u + 3] > t) && (i = (o = s - l) - 1, s <= t && (a = "right")), null != i) {
							if (r = e[u + 2], l == s && n == (r.insertLeft ? "left" : "right") && (a = n), "left" == n && 0 == i)
								for (; u && e[u - 2] == e[u - 3] && e[u - 1].insertLeft;) r = e[2 + (u -= 3)], a = "left";
							if ("right" == n && i == s - l)
								for (; u < e.length - 3 && e[u + 3] == e[u + 4] && !e[u + 5].insertLeft;) r = e[(u += 3) + 2], a = "right";
							break
						}
					return {
						node: r,
						start: i,
						end: o,
						collapse: a,
						coverStart: l,
						coverEnd: s
					}
				}

				function Rn(e, t) {
					var n = In;
					if ("left" == t)
						for (var r = 0; r < e.length && (n = e[r]).left == n.right; r++);
					else
						for (var i = e.length - 1; 0 <= i && (n = e[i]).left == n.right; i--);
					return n
				}

				function Hn(e) {
					if (e.measure && (e.measure.cache = {}, e.measure.heights = null, e.rest))
						for (var t = 0; t < e.rest.length; t++) e.measure.caches[t] = {}
				}

				function zn(e) {
					e.display.externalMeasure = null, M(e.display.lineMeasure);
					for (var t = 0; t < e.display.view.length; t++) Hn(e.display.view[t])
				}

				function Pn(e) {
					zn(e), e.display.cachedCharWidth = e.display.cachedTextHeight = e.display.cachedPaddingH = null, e.options.lineWrapping || (e.display
						.maxLineChanged = !0), e.display.lineNumChars = null
				}

				function _n() {
					return a && h ? -(document.body.getBoundingClientRect().left - parseInt(getComputedStyle(document.body).marginLeft)) : window.pageXOffset ||
						(document.documentElement || document.body).scrollLeft
				}

				function Wn() {
					return a && h ? -(document.body.getBoundingClientRect().top - parseInt(getComputedStyle(document.body).marginTop)) : window.pageYOffset ||
						(document.documentElement || document.body).scrollTop
				}

				function jn(e) {
					var t = 0;
					if (e.widgets)
						for (var n = 0; n < e.widgets.length; ++n) e.widgets[n].above && (t += bn(e.widgets[n]));
					return t
				}

				function Un(e, t, n, r, i) {
					if (!i) {
						var o = jn(t);
						n.top += o, n.bottom += o
					}
					if ("line" == r) return n;
					r || (r = "local");
					var a = Ve(t);
					if ("local" == r ? a += kn(e.display) : a -= e.display.viewOffset, "page" == r || "window" == r) {
						var l = e.display.lineSpace.getBoundingClientRect();
						a += l.top + ("window" == r ? 0 : Wn());
						var s = l.left + ("window" == r ? 0 : _n());
						n.left += s, n.right += s
					}
					return n.top += a, n.bottom += a, n
				}

				function qn(e, t, n) {
					if ("div" == n) return t;
					var r = t.left,
						i = t.top;
					if ("page" == n) r -= _n(), i -= Wn();
					else if ("local" == n || !n) {
						var o = e.display.sizer.getBoundingClientRect();
						r += o.left, i += o.top
					}
					var a = e.display.lineSpace.getBoundingClientRect();
					return {
						left: r - a.left,
						top: i - a.top
					}
				}

				function $n(e, t, n, r, i) {
					return r || (r = se(e.doc, t.line)), Un(e, r, En(e, r, t.ch, i), n)
				}

				function Gn(r, e, i, o, a, l) {
					function s(e, t) {
						var n = Fn(r, a, e, t ? "right" : "left", l);
						return t ? n.left = n.right : n.right = n.left, Un(r, o, n, i)
					}
					o = o || se(r.doc, e.line), a || (a = Dn(r, o));
					var u = Qe(o, r.doc.direction),
						t = e.ch,
						n = e.sticky;
					if (t >= o.text.length ? (t = o.text.length, n = "before") : t <= 0 && (t = 0, n = "after"), !u) return s("before" == n ? t - 1 :
						t, "before" == n);

					function c(e, t, n) {
						return s(n ? e - 1 : e, 1 == u[t].level != n)
					}
					var h = Ye(u, t, n),
						f = Ze,
						d = c(t, h, "before" == n);
					return null != f && (d.other = c(t, f, "before" != n)), d
				}

				function Vn(e, t) {
					var n = 0;
					t = Ce(e.doc, t), e.options.lineWrapping || (n = tr(e.display) * t.ch);
					var r = se(e.doc, t.line),
						i = Ve(r) + kn(e.display);
					return {
						left: n,
						right: n,
						top: i,
						bottom: i + r.height
					}
				}

				function Xn(e, t, n, r, i) {
					var o = ge(e, t, n);
					return o.xRel = i, r && (o.outside = !0), o
				}

				function Kn(e, t, n) {
					var r = e.doc;
					if ((n += e.display.viewOffset) < 0) return Xn(r.first, 0, null, !0, -1);
					var i = de(r, n),
						o = r.first + r.size - 1;
					if (o < i) return Xn(r.first + r.size - 1, se(r, o).text.length, null, !0, 1);
					t < 0 && (t = 0);
					for (var a = se(r, i);;) {
						var l = Qn(e, a, i, t, n),
							s = _e(a, l.ch + (0 < l.xRel ? 1 : 0));
						if (!s) return l;
						var u = s.find(1);
						if (u.line == i) return u;
						a = se(r, i = u.line)
					}
				}

				function Zn(t, e, n, r) {
					r -= jn(e);
					var i = e.text.length,
						o = ae(function (e) {
							return Fn(t, n, e - 1).bottom <= r
						}, i, 0);
					return {
						begin: o,
						end: i = ae(function (e) {
							return Fn(t, n, e).top > r
						}, o, i)
					}
				}

				function Yn(e, t, n, r) {
					return n || (n = Dn(e, t)), Zn(e, t, n, Un(e, t, Fn(e, n, r), "line").top)
				}

				function Jn(e, t, n, r) {
					return !(e.bottom <= n) && (e.top > n || (r ? e.left : e.right) > t)
				}

				function Qn(n, e, t, r, i) {
					i -= Ve(e);
					var o = Dn(n, e),
						a = jn(e),
						l = 0,
						s = e.text.length,
						u = !0,
						c = Qe(e, n.doc.direction);
					if (c) {
						var h = (n.options.lineWrapping ? function (e, t, n, r, i, o, a) {
							var l = Zn(e, t, r, a),
								s = l.begin,
								u = l.end;
							/\s/.test(t.text.charAt(u - 1)) && u--;
							for (var c = null, h = null, f = 0; f < i.length; f++) {
								var d = i[f];
								if (!(d.from >= u || d.to <= s)) {
									var p = 1 != d.level,
										m = Fn(e, r, p ? Math.min(u, d.to) - 1 : Math.max(s, d.from)).right,
										g = m < o ? o - m + 1e9 : m - o;
									(!c || g < h) && (c = d, h = g)
								}
							}
							c || (c = i[i.length - 1]);
							c.from < s && (c = {
								from: s,
								to: c.to,
								level: c.level
							});
							c.to > u && (c = {
								from: c.from,
								to: u,
								level: c.level
							});
							return c
						} : function (r, i, o, a, l, s, u) {
							var e = ae(function (e) {
									var t = l[e],
										n = 1 != t.level;
									return Jn(Gn(r, ge(o, n ? t.to : t.from, n ? "before" : "after"), "line", i, a), s, u, !0)
								}, 0, l.length - 1),
								t = l[e];
							if (0 < e) {
								var n = 1 != t.level,
									c = Gn(r, ge(o, n ? t.from : t.to, n ? "after" : "before"), "line", i, a);
								Jn(c, s, u, !0) && c.top > u && (t = l[e - 1])
							}
							return t
						})(n, e, t, o, c, r, i);
						l = (u = 1 != h.level) ? h.from : h.to - 1, s = u ? h.to : h.from - 1
					}
					var f, d, p = null,
						m = null,
						g = ae(function (e) {
							var t = Fn(n, o, e);
							return t.top += a, t.bottom += a, !!Jn(t, r, i, !1) && (t.top <= i && t.left <= r && (p = e, m = t), !0)
						}, l, s),
						v = !1;
					if (m) {
						var y = r - m.left < m.right - r,
							x = y == u;
						g = p + (x ? 0 : 1), d = x ? "after" : "before", f = y ? m.left : m.right
					} else {
						u || g != s && g != l || g++, d = 0 == g ? "after" : g == e.text.length ? "before" : Fn(n, o, g - (u ? 1 : 0)).bottom + a <= i ==
							u ? "after" : "before";
						var b = Gn(n, ge(t, g, d), "line", e, o);
						f = b.left, v = i < b.top || i >= b.bottom
					}
					return Xn(t, g = oe(e.text, g, 1), d, v, r - f)
				}

				function er(e) {
					if (null != e.cachedTextHeight) return e.cachedTextHeight;
					if (null == On) {
						On = N("pre");
						for (var t = 0; t < 49; ++t) On.appendChild(document.createTextNode("x")), On.appendChild(N("br"));
						On.appendChild(document.createTextNode("x"))
					}
					A(e.measure, On);
					var n = On.offsetHeight / 50;
					return 3 < n && (e.cachedTextHeight = n), M(e.measure), n || 1
				}

				function tr(e) {
					if (null != e.cachedCharWidth) return e.cachedCharWidth;
					var t = N("span", "xxxxxxxxxx"),
						n = N("pre", [t]);
					A(e.measure, n);
					var r = t.getBoundingClientRect(),
						i = (r.right - r.left) / 10;
					return 2 < i && (e.cachedCharWidth = i), i || 10
				}

				function nr(e) {
					for (var t = e.display, n = {}, r = {}, i = t.gutters.clientLeft, o = t.gutters.firstChild, a = 0; o; o = o.nextSibling, ++a) n[
						e.options.gutters[a]] = o.offsetLeft + o.clientLeft + i, r[e.options.gutters[a]] = o.clientWidth;
					return {
						fixedPos: rr(t),
						gutterTotalWidth: t.gutters.offsetWidth,
						gutterLeft: n,
						gutterWidth: r,
						wrapperWidth: t.wrapper.clientWidth
					}
				}

				function rr(e) {
					return e.scroller.getBoundingClientRect().left - e.sizer.getBoundingClientRect().left
				}

				function ir(r) {
					var i = er(r.display),
						o = r.options.lineWrapping,
						a = o && Math.max(5, r.display.scroller.clientWidth / tr(r.display) - 3);
					return function (e) {
						if ($e(r.doc, e)) return 0;
						var t = 0;
						if (e.widgets)
							for (var n = 0; n < e.widgets.length; n++) e.widgets[n].height && (t += e.widgets[n].height);
						return o ? t + (Math.ceil(e.text.length / a) || 1) * i : t + i
					}
				}

				function or(e) {
					var t = e.doc,
						n = ir(e);
					t.iter(function (e) {
						var t = n(e);
						t != e.height && he(e, t)
					})
				}

				function ar(e, t, n, r) {
					var i = e.display;
					if (!n && "true" == dt(t).getAttribute("cm-not-content")) return null;
					var o, a, l = i.lineSpace.getBoundingClientRect();
					try {
						o = t.clientX - l.left, a = t.clientY - l.top
					} catch (t) {
						return null
					}
					var s, u = Kn(e, o, a);
					if (r && 1 == u.xRel && (s = se(e.doc, u.line).text).length == u.ch) {
						var c = z(s, s.length, e.options.tabSize) - s.length;
						u = ge(u.line, Math.max(0, Math.round((o - Sn(e.display).left) / tr(e.display)) - c))
					}
					return u
				}

				function lr(e, t) {
					if (t >= e.display.viewTo) return null;
					if ((t -= e.display.viewFrom) < 0) return null;
					for (var n = e.display.view, r = 0; r < n.length; r++)
						if ((t -= n[r].size) < 0) return r
				}

				function sr(e) {
					e.display.input.showSelection(e.display.input.prepareSelection())
				}

				function ur(e, t) {
					void 0 === t && (t = !0);
					for (var n = e.doc, r = {}, i = r.cursors = document.createDocumentFragment(), o = r.selection = document.createDocumentFragment(),
							a = 0; a < n.sel.ranges.length; a++)
						if (t || a != n.sel.primIndex) {
							var l = n.sel.ranges[a];
							if (!(l.from().line >= e.display.viewTo || l.to().line < e.display.viewFrom)) {
								var s = l.empty();
								(s || e.options.showCursorWhenSelecting) && cr(e, l.head, i), s || fr(e, l, o)
							}
						}
					return r
				}

				function cr(e, t, n) {
					var r = Gn(e, t, "div", null, null, !e.options.singleCursorHeightPerLine),
						i = n.appendChild(N("div", " ", "CodeMirror-cursor"));
					if (i.style.left = r.left + "px", i.style.top = r.top + "px", i.style.height = Math.max(0, r.bottom - r.top) * e.options.cursorHeight +
						"px", r.other) {
						var o = n.appendChild(N("div", " ", "CodeMirror-cursor CodeMirror-secondarycursor"));
						o.style.display = "", o.style.left = r.other.left + "px", o.style.top = r.other.top + "px", o.style.height = .85 * (r.other.bottom -
							r.other.top) + "px"
					}
				}

				function hr(e, t) {
					return e.top - t.top || e.left - t.left
				}

				function fr(a, e, t) {
					var n = a.display,
						r = a.doc,
						i = document.createDocumentFragment(),
						o = Sn(a.display),
						T = o.left,
						M = Math.max(n.sizerWidth, Tn(a) - n.sizer.offsetLeft) - o.right,
						A = "ltr" == r.direction;

					function E(e, t, n, r) {
						t < 0 && (t = 0), t = Math.round(t), r = Math.round(r), i.appendChild(N("div", null, "CodeMirror-selected",
							"position: absolute; left: " + e + "px;\n                             top: " + t + "px; width: " + (null == n ? M - e : n) +
							"px;\n                             height: " + (r - t) + "px"))
					}

					function l(n, y, x) {
						var b, w, o = se(r, n),
							k = o.text.length;

						function C(e, t) {
							return $n(a, ge(n, e), "div", o, t)
						}

						function S(e, t, n) {
							var r = Yn(a, o, null, e),
								i = "ltr" == t == ("after" == n) ? "left" : "right";
							return C("after" == n ? r.begin : r.end - (/\s/.test(o.text.charAt(r.end - 1)) ? 2 : 1), i)[i]
						}
						var L = Qe(o, r.direction);
						return function (e, t, n, r) {
							if (!e) return r(t, n, "ltr", 0);
							for (var i = !1, o = 0; o < e.length; ++o) {
								var a = e[o];
								(a.from < n && a.to > t || t == n && a.to == t) && (r(Math.max(a.from, t), Math.min(a.to, n), 1 == a.level ? "rtl" : "ltr",
									o), i = !0)
							}
							i || r(t, n, "ltr")
						}(L, y || 0, null == x ? k : x, function (e, t, n, r) {
							var i = "ltr" == n,
								o = C(e, i ? "left" : "right"),
								a = C(t - 1, i ? "right" : "left"),
								l = null == y && 0 == e,
								s = null == x && t == k,
								u = 0 == r,
								c = !L || r == L.length - 1;
							if (a.top - o.top <= 3) {
								var h = (A ? s : l) && c,
									f = (A ? l : s) && u ? T : (i ? o : a).left,
									d = h ? M : (i ? a : o).right;
								E(f, o.top, d - f, o.bottom)
							} else {
								var p, m, g, v;
								v = i ? (p = A && l && u ? T : o.left, m = A ? M : S(e, n, "before"), g = A ? T : S(t, n, "after"), A && s && c ? M : a.right) :
									(p = A ? S(e, n, "before") : T, m = !A && l && u ? M : o.right, g = !A && s && c ? T : a.left, A ? S(t, n, "after") : M),
									E(p, o.top, m - p, o.bottom), o.bottom < a.top && E(T, o.bottom, null, a.top), E(g, a.top, v - g, a.bottom)
							}(!b || hr(o, b) < 0) && (b = o), hr(a, b) < 0 && (b = a), (!w || hr(o, w) < 0) && (w = o), hr(a, w) < 0 && (w = a)
						}), {
							start: b,
							end: w
						}
					}
					var s = e.from(),
						u = e.to();
					if (s.line == u.line) l(s.line, s.ch, u.ch);
					else {
						var c = se(r, s.line),
							h = se(r, u.line),
							f = je(c) == je(h),
							d = l(s.line, s.ch, f ? c.text.length + 1 : null).end,
							p = l(u.line, f ? 0 : null, u.ch).start;
						f && (d.top < p.top - 2 ? (E(d.right, d.top, null, d.bottom), E(T, p.top, p.left, p.bottom)) : E(d.right, d.top, p.left - d.right,
							d.bottom)), d.bottom < p.top && E(T, d.bottom, null, p.top)
					}
					t.appendChild(i)
				}

				function dr(e) {
					if (e.state.focused) {
						var t = e.display;
						clearInterval(t.blinker);
						var n = !0;
						t.cursorDiv.style.visibility = "", 0 < e.options.cursorBlinkRate ? t.blinker = setInterval(function () {
							return t.cursorDiv.style.visibility = (n = !n) ? "" : "hidden"
						}, e.options.cursorBlinkRate) : e.options.cursorBlinkRate < 0 && (t.cursorDiv.style.visibility = "hidden")
					}
				}

				function pr(e) {
					e.state.focused || (e.display.input.focus(), gr(e))
				}

				function mr(e) {
					e.state.delayingBlurEvent = !0, setTimeout(function () {
						e.state.delayingBlurEvent && (e.state.delayingBlurEvent = !1, vr(e))
					}, 100)
				}

				function gr(e, t) {
					e.state.delayingBlurEvent && (e.state.delayingBlurEvent = !1), "nocursor" != e.options.readOnly && (e.state.focused || (it(e,
							"focus", e, t), e.state.focused = !0, O(e.display.wrapper, "CodeMirror-focused"), e.curOp || e.display.selForContextMenu ==
						e.doc.sel || (e.display.input.reset(), x && setTimeout(function () {
							return e.display.input.reset(!0)
						}, 20)), e.display.input.receivedFocus()), dr(e))
				}

				function vr(e, t) {
					e.state.delayingBlurEvent || (e.state.focused && (it(e, "blur", e, t), e.state.focused = !1, T(e.display.wrapper,
						"CodeMirror-focused")), clearInterval(e.display.blinker), setTimeout(function () {
						e.state.focused || (e.display.shift = !1)
					}, 150))
				}

				function yr(e) {
					for (var t = e.display, n = t.lineDiv.offsetTop, r = 0; r < t.view.length; r++) {
						var i = t.view[r],
							o = e.options.lineWrapping,
							a = void 0,
							l = 0;
						if (!i.hidden) {
							if (w && k < 8) {
								var s = i.node.offsetTop + i.node.offsetHeight;
								a = s - n, n = s
							} else {
								var u = i.node.getBoundingClientRect();
								a = u.bottom - u.top, !o && i.text.firstChild && (l = i.text.firstChild.getBoundingClientRect().right - u.left - 1)
							}
							var c = i.line.height - a;
							if ((.005 < c || c < -.005) && (he(i.line, a), xr(i.line), i.rest))
								for (var h = 0; h < i.rest.length; h++) xr(i.rest[h]);
							if (l > e.display.sizerWidth) {
								var f = Math.ceil(l / tr(e.display));
								f > e.display.maxLineLength && (e.display.maxLineLength = f, e.display.maxLine = i.line, e.display.maxLineChanged = !0)
							}
						}
					}
				}

				function xr(e) {
					if (e.widgets)
						for (var t = 0; t < e.widgets.length; ++t) {
							var n = e.widgets[t],
								r = n.node.parentNode;
							r && (n.height = r.offsetHeight)
						}
				}

				function br(e, t, n) {
					var r = n && null != n.top ? Math.max(0, n.top) : e.scroller.scrollTop;
					r = Math.floor(r - kn(e));
					var i = n && null != n.bottom ? n.bottom : r + e.wrapper.clientHeight,
						o = de(t, r),
						a = de(t, i);
					if (n && n.ensure) {
						var l = n.ensure.from.line,
							s = n.ensure.to.line;
						l < o ? a = de(t, Ve(se(t, o = l)) + e.wrapper.clientHeight) : Math.min(s, t.lastLine()) >= a && (o = de(t, Ve(se(t, s)) - e.wrapper
							.clientHeight), a = s)
					}
					return {
						from: o,
						to: Math.max(a, o + 1)
					}
				}

				function wr(e) {
					var t = e.display,
						n = t.view;
					if (t.alignWidgets || t.gutters.firstChild && e.options.fixedGutter) {
						for (var r = rr(t) - t.scroller.scrollLeft + e.doc.scrollLeft, i = t.gutters.offsetWidth, o = r + "px", a = 0; a < n.length; a++)
							if (!n[a].hidden) {
								e.options.fixedGutter && (n[a].gutter && (n[a].gutter.style.left = o), n[a].gutterBackground && (n[a].gutterBackground.style.left =
									o));
								var l = n[a].alignable;
								if (l)
									for (var s = 0; s < l.length; s++) l[s].style.left = o
							}
						e.options.fixedGutter && (t.gutters.style.left = r + i + "px")
					}
				}

				function kr(e) {
					if (!e.options.lineNumbers) return !1;
					var t = e.doc,
						n = me(e.options, t.first + t.size - 1),
						r = e.display;
					if (n.length == r.lineNumChars) return !1;
					var i = r.measure.appendChild(N("div", [N("div", n)], "CodeMirror-linenumber CodeMirror-gutter-elt")),
						o = i.firstChild.offsetWidth,
						a = i.offsetWidth - o;
					return r.lineGutter.style.width = "", r.lineNumInnerWidth = Math.max(o, r.lineGutter.offsetWidth - a) + 1, r.lineNumWidth = r.lineNumInnerWidth +
						a, r.lineNumChars = r.lineNumInnerWidth ? n.length : -1, r.lineGutter.style.width = r.lineNumWidth + "px", li(e), !0
				}

				function Cr(e, t) {
					var n = e.display,
						r = er(e.display);
					t.top < 0 && (t.top = 0);
					var i = e.curOp && null != e.curOp.scrollTop ? e.curOp.scrollTop : n.scroller.scrollTop,
						o = Mn(e),
						a = {};
					t.bottom - t.top > o && (t.bottom = t.top + o);
					var l = e.doc.height + Cn(n),
						s = t.top < r,
						u = t.bottom > l - r;
					if (t.top < i) a.scrollTop = s ? 0 : t.top;
					else if (t.bottom > i + o) {
						var c = Math.min(t.top, (u ? l : t.bottom) - o);
						c != i && (a.scrollTop = c)
					}
					var h = e.curOp && null != e.curOp.scrollLeft ? e.curOp.scrollLeft : n.scroller.scrollLeft,
						f = Tn(e) - (e.options.fixedGutter ? n.gutters.offsetWidth : 0),
						d = t.right - t.left > f;
					return d && (t.right = t.left + f), t.left < 10 ? a.scrollLeft = 0 : t.left < h ? a.scrollLeft = Math.max(0, t.left - (d ? 0 :
						10)) : t.right > f + h - 3 && (a.scrollLeft = t.right + (d ? 0 : 10) - f), a
				}

				function Sr(e, t) {
					null != t && (Mr(e), e.curOp.scrollTop = (null == e.curOp.scrollTop ? e.doc.scrollTop : e.curOp.scrollTop) + t)
				}

				function Lr(e) {
					Mr(e);
					var t = e.getCursor();
					e.curOp.scrollToPos = {
						from: t,
						to: t,
						margin: e.options.cursorScrollMargin
					}
				}

				function Tr(e, t, n) {
					null == t && null == n || Mr(e), null != t && (e.curOp.scrollLeft = t), null != n && (e.curOp.scrollTop = n)
				}

				function Mr(e) {
					var t = e.curOp.scrollToPos;
					t && (e.curOp.scrollToPos = null, Ar(e, Vn(e, t.from), Vn(e, t.to), t.margin))
				}

				function Ar(e, t, n, r) {
					var i = Cr(e, {
						left: Math.min(t.left, n.left),
						top: Math.min(t.top, n.top) - r,
						right: Math.max(t.right, n.right),
						bottom: Math.max(t.bottom, n.bottom) + r
					});
					Tr(e, i.scrollLeft, i.scrollTop)
				}

				function Er(e, t) {
					Math.abs(e.doc.scrollTop - t) < 2 || (m || ai(e, {
						top: t
					}), Nr(e, t, !0), m && ai(e), ti(e, 100))
				}

				function Nr(e, t, n) {
					t = Math.min(e.display.scroller.scrollHeight - e.display.scroller.clientHeight, t), (e.display.scroller.scrollTop != t || n) &&
						(e.doc.scrollTop = t, e.display.scrollbars.setScrollTop(t), e.display.scroller.scrollTop != t && (e.display.scroller.scrollTop =
							t))
				}

				function Dr(e, t, n, r) {
					t = Math.min(t, e.display.scroller.scrollWidth - e.display.scroller.clientWidth), (n ? t == e.doc.scrollLeft : Math.abs(e.doc.scrollLeft -
						t) < 2) && !r || (e.doc.scrollLeft = t, wr(e), e.display.scroller.scrollLeft != t && (e.display.scroller.scrollLeft = t), e.display
						.scrollbars.setScrollLeft(t))
				}

				function Fr(e) {
					var t = e.display,
						n = t.gutters.offsetWidth,
						r = Math.round(e.doc.height + Cn(e.display));
					return {
						clientHeight: t.scroller.clientHeight,
						viewHeight: t.wrapper.clientHeight,
						scrollWidth: t.scroller.scrollWidth,
						clientWidth: t.scroller.clientWidth,
						viewWidth: t.wrapper.clientWidth,
						barLeft: e.options.fixedGutter ? n : 0,
						docHeight: r,
						scrollHeight: r + Ln(e) + t.barHeight,
						nativeBarWidth: t.nativeBarWidth,
						gutterWidth: n
					}
				}
				var Or = function (e, t, n) {
					this.cm = n;
					var r = this.vert = N("div", [N("div", null, null, "min-width: 1px")], "CodeMirror-vscrollbar"),
						i = this.horiz = N("div", [N("div", null, null, "height: 100%; min-height: 1px")], "CodeMirror-hscrollbar");
					r.tabIndex = i.tabIndex = -1, e(r), e(i), tt(r, "scroll", function () {
						r.clientHeight && t(r.scrollTop, "vertical")
					}), tt(i, "scroll", function () {
						i.clientWidth && t(i.scrollLeft, "horizontal")
					}), this.checkedZeroWidth = !1, w && k < 8 && (this.horiz.style.minHeight = this.vert.style.minWidth = "18px")
				};
				Or.prototype.update = function (e) {
					var t = e.scrollWidth > e.clientWidth + 1,
						n = e.scrollHeight > e.clientHeight + 1,
						r = e.nativeBarWidth;
					if (n) {
						this.vert.style.display = "block", this.vert.style.bottom = t ? r + "px" : "0";
						var i = e.viewHeight - (t ? r : 0);
						this.vert.firstChild.style.height = Math.max(0, e.scrollHeight - e.clientHeight + i) + "px"
					} else this.vert.style.display = "", this.vert.firstChild.style.height = "0";
					if (t) {
						this.horiz.style.display = "block", this.horiz.style.right = n ? r + "px" : "0", this.horiz.style.left = e.barLeft + "px";
						var o = e.viewWidth - e.barLeft - (n ? r : 0);
						this.horiz.firstChild.style.width = Math.max(0, e.scrollWidth - e.clientWidth + o) + "px"
					} else this.horiz.style.display = "", this.horiz.firstChild.style.width = "0";
					return !this.checkedZeroWidth && 0 < e.clientHeight && (0 == r && this.zeroWidthHack(), this.checkedZeroWidth = !0), {
						right: n ? r : 0,
						bottom: t ? r : 0
					}
				}, Or.prototype.setScrollLeft = function (e) {
					this.horiz.scrollLeft != e && (this.horiz.scrollLeft = e), this.disableHoriz && this.enableZeroWidthBar(this.horiz, this.disableHoriz,
						"horiz")
				}, Or.prototype.setScrollTop = function (e) {
					this.vert.scrollTop != e && (this.vert.scrollTop = e), this.disableVert && this.enableZeroWidthBar(this.vert, this.disableVert,
						"vert")
				}, Or.prototype.zeroWidthHack = function () {
					var e = b && !l ? "12px" : "18px";
					this.horiz.style.height = this.vert.style.width = e, this.horiz.style.pointerEvents = this.vert.style.pointerEvents = "none",
						this.disableHoriz = new P, this.disableVert = new P
				}, Or.prototype.enableZeroWidthBar = function (n, r, i) {
					n.style.pointerEvents = "auto", r.set(1e3, function e() {
						var t = n.getBoundingClientRect();
						("vert" == i ? document.elementFromPoint(t.right - 1, (t.top + t.bottom) / 2) : document.elementFromPoint((t.right + t.left) /
							2, t.bottom - 1)) != n ? n.style.pointerEvents = "none" : r.set(1e3, e)
					})
				}, Or.prototype.clear = function () {
					var e = this.horiz.parentNode;
					e.removeChild(this.horiz), e.removeChild(this.vert)
				};
				var Ir = function () {};

				function Br(e, t) {
					t || (t = Fr(e));
					var n = e.display.barWidth,
						r = e.display.barHeight;
					Rr(e, t);
					for (var i = 0; i < 4 && n != e.display.barWidth || r != e.display.barHeight; i++) n != e.display.barWidth && e.options.lineWrapping &&
						yr(e), Rr(e, Fr(e)), n = e.display.barWidth, r = e.display.barHeight
				}

				function Rr(e, t) {
					var n = e.display,
						r = n.scrollbars.update(t);
					n.sizer.style.paddingRight = (n.barWidth = r.right) + "px", n.sizer.style.paddingBottom = (n.barHeight = r.bottom) + "px", n.heightForcer
						.style.borderBottom = r.bottom + "px solid transparent", r.right && r.bottom ? (n.scrollbarFiller.style.display = "block", n.scrollbarFiller
							.style.height = r.bottom + "px", n.scrollbarFiller.style.width = r.right + "px") : n.scrollbarFiller.style.display = "", r.bottom &&
						e.options.coverGutterNextToScrollbar && e.options.fixedGutter ? (n.gutterFiller.style.display = "block", n.gutterFiller.style.height =
							r.bottom + "px", n.gutterFiller.style.width = t.gutterWidth + "px") : n.gutterFiller.style.display = ""
				}
				Ir.prototype.update = function () {
					return {
						bottom: 0,
						right: 0
					}
				}, Ir.prototype.setScrollLeft = function () {}, Ir.prototype.setScrollTop = function () {}, Ir.prototype.clear = function () {};
				var Hr = {
					native: Or,
					null: Ir
				};

				function zr(n) {
					n.display.scrollbars && (n.display.scrollbars.clear(), n.display.scrollbars.addClass && T(n.display.wrapper, n.display.scrollbars
						.addClass)), n.display.scrollbars = new Hr[n.options.scrollbarStyle](function (e) {
						n.display.wrapper.insertBefore(e, n.display.scrollbarFiller), tt(e, "mousedown", function () {
							n.state.focused && setTimeout(function () {
								return n.display.input.focus()
							}, 0)
						}), e.setAttribute("cm-not-content", "true")
					}, function (e, t) {
						"horizontal" == t ? Dr(n, e) : Er(n, e)
					}, n), n.display.scrollbars.addClass && O(n.display.wrapper, n.display.scrollbars.addClass)
				}
				var Pr = 0;

				function _r(e) {
					var t;
					e.curOp = {
						cm: e,
						viewChanged: !1,
						startHeight: e.doc.height,
						forceUpdate: !1,
						updateInput: 0,
						typing: !1,
						changeObjs: null,
						cursorActivityHandlers: null,
						cursorActivityCalled: 0,
						selectionChanged: !1,
						updateMaxLine: !1,
						scrollLeft: null,
						scrollTop: null,
						scrollToPos: null,
						focus: !1,
						id: ++Pr
					}, t = e.curOp, an ? an.ops.push(t) : t.ownsGroup = an = {
						ops: [t],
						delayedCallbacks: []
					}
				}

				function Wr(e) {
					var t = e.curOp;
					t && function (e, t) {
						var n = e.ownsGroup;
						if (n) try {
							! function (e) {
								var t = e.delayedCallbacks,
									n = 0;
								do {
									for (; n < t.length; n++) t[n].call(null);
									for (var r = 0; r < e.ops.length; r++) {
										var i = e.ops[r];
										if (i.cursorActivityHandlers)
											for (; i.cursorActivityCalled < i.cursorActivityHandlers.length;) i.cursorActivityHandlers[i.cursorActivityCalled++].call(
												null, i.cm)
									}
								} while (n < t.length)
							}(n)
						} finally {
							an = null, t(n)
						}
					}(t, function (e) {
						for (var t = 0; t < e.ops.length; t++) e.ops[t].cm.curOp = null;
						! function (e) {
							for (var t = e.ops, n = 0; n < t.length; n++) jr(t[n]);
							for (var r = 0; r < t.length; r++)(i = t[r]).updatedDisplay = i.mustUpdate && ii(i.cm, i.update);
							var i;
							for (var o = 0; o < t.length; o++) Ur(t[o]);
							for (var a = 0; a < t.length; a++) qr(t[a]);
							for (var l = 0; l < t.length; l++) $r(t[l])
						}(e)
					})
				}

				function jr(e) {
					var t, n, r = e.cm,
						i = r.display;
					!(n = (t = r).display).scrollbarsClipped && n.scroller.offsetWidth && (n.nativeBarWidth = n.scroller.offsetWidth - n.scroller.clientWidth,
							n.heightForcer.style.height = Ln(t) + "px", n.sizer.style.marginBottom = -n.nativeBarWidth + "px", n.sizer.style.borderRightWidth =
							Ln(t) + "px", n.scrollbarsClipped = !0), e.updateMaxLine && Ke(r), e.mustUpdate = e.viewChanged || e.forceUpdate || null != e.scrollTop ||
						e.scrollToPos && (e.scrollToPos.from.line < i.viewFrom || e.scrollToPos.to.line >= i.viewTo) || i.maxLineChanged && r.options.lineWrapping,
						e.update = e.mustUpdate && new ri(r, e.mustUpdate && {
							top: e.scrollTop,
							ensure: e.scrollToPos
						}, e.forceUpdate)
				}

				function Ur(e) {
					var t = e.cm,
						n = t.display;
					e.updatedDisplay && yr(t), e.barMeasure = Fr(t), n.maxLineChanged && !t.options.lineWrapping && (e.adjustWidthTo = En(t, n.maxLine,
						n.maxLine.text.length).left + 3, t.display.sizerWidth = e.adjustWidthTo, e.barMeasure.scrollWidth = Math.max(n.scroller.clientWidth,
						n.sizer.offsetLeft + e.adjustWidthTo + Ln(t) + t.display.barWidth), e.maxScrollLeft = Math.max(0, n.sizer.offsetLeft + e.adjustWidthTo -
						Tn(t))), (e.updatedDisplay || e.selectionChanged) && (e.preparedSelection = n.input.prepareSelection())
				}

				function qr(e) {
					var t = e.cm;
					null != e.adjustWidthTo && (t.display.sizer.style.minWidth = e.adjustWidthTo + "px", e.maxScrollLeft < t.doc.scrollLeft && Dr(t,
						Math.min(t.display.scroller.scrollLeft, e.maxScrollLeft), !0), t.display.maxLineChanged = !1);
					var n = e.focus && e.focus == F();
					e.preparedSelection && t.display.input.showSelection(e.preparedSelection, n), (e.updatedDisplay || e.startHeight != t.doc.height) &&
						Br(t, e.barMeasure), e.updatedDisplay && si(t, e.barMeasure), e.selectionChanged && dr(t), t.state.focused && e.updateInput &&
						t.display.input.reset(e.typing), n && pr(e.cm)
				}

				function $r(e) {
					var t = e.cm,
						n = t.display,
						r = t.doc;
					(e.updatedDisplay && oi(t, e.update), null == n.wheelStartX || null == e.scrollTop && null == e.scrollLeft && !e.scrollToPos ||
						(n.wheelStartX = n.wheelStartY = null), null != e.scrollTop && Nr(t, e.scrollTop, e.forceScroll), null != e.scrollLeft && Dr(t,
							e.scrollLeft, !0, !0), e.scrollToPos) && function (e, t) {
						if (!ot(e, "scrollCursorIntoView")) {
							var n = e.display,
								r = n.sizer.getBoundingClientRect(),
								i = null;
							if (t.top + r.top < 0 ? i = !0 : t.bottom + r.top > (window.innerHeight || document.documentElement.clientHeight) && (i = !1),
								null != i && !u) {
								var o = N("div", "​", null, "position: absolute;\n                         top: " + (t.top - n.viewOffset - kn(e.display)) +
									"px;\n                         height: " + (t.bottom - t.top + Ln(e) + n.barHeight) +
									"px;\n                         left: " + t.left + "px; width: " + Math.max(2, t.right - t.left) + "px;");
								e.display.lineSpace.appendChild(o), o.scrollIntoView(i), e.display.lineSpace.removeChild(o)
							}
						}
					}(t, function (e, t, n, r) {
						var i;
						null == r && (r = 0), e.options.lineWrapping || t != n || (n = "before" == (t = t.ch ? ge(t.line, "before" == t.sticky ? t.ch -
							1 : t.ch, "after") : t).sticky ? ge(t.line, t.ch + 1, "before") : t);
						for (var o = 0; o < 5; o++) {
							var a = !1,
								l = Gn(e, t),
								s = n && n != t ? Gn(e, n) : l,
								u = Cr(e, i = {
									left: Math.min(l.left, s.left),
									top: Math.min(l.top, s.top) - r,
									right: Math.max(l.left, s.left),
									bottom: Math.max(l.bottom, s.bottom) + r
								}),
								c = e.doc.scrollTop,
								h = e.doc.scrollLeft;
							if (null != u.scrollTop && (Er(e, u.scrollTop), 1 < Math.abs(e.doc.scrollTop - c) && (a = !0)), null != u.scrollLeft && (Dr(e,
									u.scrollLeft), 1 < Math.abs(e.doc.scrollLeft - h) && (a = !0)), !a) break
						}
						return i
					}(t, Ce(r, e.scrollToPos.from), Ce(r, e.scrollToPos.to), e.scrollToPos.margin));
					var i = e.maybeHiddenMarkers,
						o = e.maybeUnhiddenMarkers;
					if (i)
						for (var a = 0; a < i.length; ++a) i[a].lines.length || it(i[a], "hide");
					if (o)
						for (var l = 0; l < o.length; ++l) o[l].lines.length && it(o[l], "unhide");
					n.wrapper.offsetHeight && (r.scrollTop = t.display.scroller.scrollTop), e.changeObjs && it(t, "changes", t, e.changeObjs), e.update &&
						e.update.finish()
				}

				function Gr(e, t) {
					if (e.curOp) return t();
					_r(e);
					try {
						return t()
					} finally {
						Wr(e)
					}
				}

				function Vr(e, t) {
					return function () {
						if (e.curOp) return t.apply(e, arguments);
						_r(e);
						try {
							return t.apply(e, arguments)
						} finally {
							Wr(e)
						}
					}
				}

				function Xr(e) {
					return function () {
						if (this.curOp) return e.apply(this, arguments);
						_r(this);
						try {
							return e.apply(this, arguments)
						} finally {
							Wr(this)
						}
					}
				}

				function Kr(t) {
					return function () {
						var e = this.cm;
						if (!e || e.curOp) return t.apply(this, arguments);
						_r(e);
						try {
							return t.apply(this, arguments)
						} finally {
							Wr(e)
						}
					}
				}

				function Zr(e, t, n, r) {
					null == t && (t = e.doc.first), null == n && (n = e.doc.first + e.doc.size), r || (r = 0);
					var i = e.display;
					if (r && n < i.viewTo && (null == i.updateLineNumbers || i.updateLineNumbers > t) && (i.updateLineNumbers = t), e.curOp.viewChanged = !
						0, t >= i.viewTo) Te && Ue(e.doc, t) < i.viewTo && Jr(e);
					else if (n <= i.viewFrom) Te && qe(e.doc, n + r) > i.viewFrom ? Jr(e) : (i.viewFrom += r, i.viewTo += r);
					else if (t <= i.viewFrom && n >= i.viewTo) Jr(e);
					else if (t <= i.viewFrom) {
						var o = Qr(e, n, n + r, 1);
						o ? (i.view = i.view.slice(o.index), i.viewFrom = o.lineN, i.viewTo += r) : Jr(e)
					} else if (n >= i.viewTo) {
						var a = Qr(e, t, t, -1);
						a ? (i.view = i.view.slice(0, a.index), i.viewTo = a.lineN) : Jr(e)
					} else {
						var l = Qr(e, t, t, -1),
							s = Qr(e, n, n + r, 1);
						l && s ? (i.view = i.view.slice(0, l.index).concat(on(e, l.lineN, s.lineN)).concat(i.view.slice(s.index)), i.viewTo += r) : Jr(
							e)
					}
					var u = i.externalMeasured;
					u && (n < u.lineN ? u.lineN += r : t < u.lineN + u.size && (i.externalMeasured = null))
				}

				function Yr(e, t, n) {
					e.curOp.viewChanged = !0;
					var r = e.display,
						i = e.display.externalMeasured;
					if (i && t >= i.lineN && t < i.lineN + i.size && (r.externalMeasured = null), !(t < r.viewFrom || t >= r.viewTo)) {
						var o = r.view[lr(e, t)];
						if (null != o.node) {
							var a = o.changes || (o.changes = []); - 1 == _(a, n) && a.push(n)
						}
					}
				}

				function Jr(e) {
					e.display.viewFrom = e.display.viewTo = e.doc.first, e.display.view = [], e.display.viewOffset = 0
				}

				function Qr(e, t, n, r) {
					var i, o = lr(e, t),
						a = e.display.view;
					if (!Te || n == e.doc.first + e.doc.size) return {
						index: o,
						lineN: n
					};
					for (var l = e.display.viewFrom, s = 0; s < o; s++) l += a[s].size;
					if (l != t) {
						if (0 < r) {
							if (o == a.length - 1) return null;
							i = l + a[o].size - t, o++
						} else i = l - t;
						t += i, n += i
					}
					for (; Ue(e.doc, n) != n;) {
						if (o == (r < 0 ? 0 : a.length - 1)) return null;
						n += r * a[o - (r < 0 ? 1 : 0)].size, o += r
					}
					return {
						index: o,
						lineN: n
					}
				}

				function ei(e) {
					for (var t = e.display.view, n = 0, r = 0; r < t.length; r++) {
						var i = t[r];
						i.hidden || i.node && !i.changes || ++n
					}
					return n
				}

				function ti(e, t) {
					e.doc.highlightFrontier < e.display.viewTo && e.state.highlight.set(t, R(ni, e))
				}

				function ni(s) {
					var u = s.doc;
					if (!(u.highlightFrontier >= s.display.viewTo)) {
						var c = +new Date + s.options.workTime,
							h = Pt(s, u.highlightFrontier),
							f = [];
						u.iter(h.line, Math.min(u.first + u.size, s.display.viewTo + 500), function (e) {
							if (h.line >= s.display.viewFrom) {
								var t = e.styles,
									n = e.text.length > s.options.maxHighlightLength ? Dt(u.mode, h.state) : null,
									r = Ht(s, e, h, !0);
								n && (h.state = n), e.styles = r.styles;
								var i = e.styleClasses,
									o = r.classes;
								o ? e.styleClasses = o : i && (e.styleClasses = null);
								for (var a = !t || t.length != e.styles.length || i != o && (!i || !o || i.bgClass != o.bgClass || i.textClass != o.textClass),
										l = 0; !a && l < t.length; ++l) a = t[l] != e.styles[l];
								a && f.push(h.line), e.stateAfter = h.save(), h.nextLine()
							} else e.text.length <= s.options.maxHighlightLength && _t(s, e.text, h), e.stateAfter = h.line % 5 == 0 ? h.save() : null,
								h.nextLine();
							if (+new Date > c) return ti(s, s.options.workDelay), !0
						}), u.highlightFrontier = h.line, u.modeFrontier = Math.max(u.modeFrontier, h.line), f.length && Gr(s, function () {
							for (var e = 0; e < f.length; e++) Yr(s, f[e], "text")
						})
					}
				}
				var ri = function (e, t, n) {
					var r = e.display;
					this.viewport = t, this.visible = br(r, e.doc, t), this.editorIsHidden = !r.wrapper.offsetWidth, this.wrapperHeight = r.wrapper
						.clientHeight, this.wrapperWidth = r.wrapper.clientWidth, this.oldDisplayWidth = Tn(e), this.force = n, this.dims = nr(e),
						this.events = []
				};

				function ii(e, t) {
					var n = e.display,
						r = e.doc;
					if (t.editorIsHidden) return Jr(e), !1;
					if (!t.force && t.visible.from >= n.viewFrom && t.visible.to <= n.viewTo && (null == n.updateLineNumbers || n.updateLineNumbers >=
							n.viewTo) && n.renderedView == n.view && 0 == ei(e)) return !1;
					kr(e) && (Jr(e), t.dims = nr(e));
					var i = r.first + r.size,
						o = Math.max(t.visible.from - e.options.viewportMargin, r.first),
						a = Math.min(i, t.visible.to + e.options.viewportMargin);
					n.viewFrom < o && o - n.viewFrom < 20 && (o = Math.max(r.first, n.viewFrom)), n.viewTo > a && n.viewTo - a < 20 && (a = Math.min(
						i, n.viewTo)), Te && (o = Ue(e.doc, o), a = qe(e.doc, a));
					var l, s, u, c, h = o != n.viewFrom || a != n.viewTo || n.lastWrapHeight != t.wrapperHeight || n.lastWrapWidth != t.wrapperWidth;
					s = o, u = a, 0 == (c = (l = e).display).view.length || s >= c.viewTo || u <= c.viewFrom ? (c.view = on(l, s, u), c.viewFrom = s) :
						(c.viewFrom > s ? c.view = on(l, s, c.viewFrom).concat(c.view) : c.viewFrom < s && (c.view = c.view.slice(lr(l, s))), c.viewFrom =
							s, c.viewTo < u ? c.view = c.view.concat(on(l, c.viewTo, u)) : c.viewTo > u && (c.view = c.view.slice(0, lr(l, u)))), c.viewTo =
						u, n.viewOffset = Ve(se(e.doc, n.viewFrom)), e.display.mover.style.top = n.viewOffset + "px";
					var f = ei(e);
					if (!h && 0 == f && !t.force && n.renderedView == n.view && (null == n.updateLineNumbers || n.updateLineNumbers >= n.viewTo))
						return !1;
					var d = function (e) {
						if (e.hasFocus()) return null;
						var t = F();
						if (!t || !D(e.display.lineDiv, t)) return null;
						var n = {
							activeElt: t
						};
						if (window.getSelection) {
							var r = window.getSelection();
							r.anchorNode && r.extend && D(e.display.lineDiv, r.anchorNode) && (n.anchorNode = r.anchorNode, n.anchorOffset = r.anchorOffset,
								n.focusNode = r.focusNode, n.focusOffset = r.focusOffset)
						}
						return n
					}(e);
					return 4 < f && (n.lineDiv.style.display = "none"),
						function (n, e, t) {
							var r = n.display,
								i = n.options.lineNumbers,
								o = r.lineDiv,
								a = o.firstChild;

							function l(e) {
								var t = e.nextSibling;
								return x && b && n.display.currentWheelTarget == e ? e.style.display = "none" : e.parentNode.removeChild(e), t
							}
							for (var s = r.view, u = r.viewFrom, c = 0; c < s.length; c++) {
								var h = s[c];
								if (h.hidden);
								else if (h.node && h.node.parentNode == o) {
									for (; a != h.node;) a = l(a);
									var f = i && null != e && e <= u && h.lineNumber;
									h.changes && (-1 < _(h.changes, "gutter") && (f = !1), cn(n, h, u, t)), f && (M(h.lineNumber), h.lineNumber.appendChild(
										document.createTextNode(me(n.options, u)))), a = h.node.nextSibling
								} else {
									var d = (g = u, v = t, void 0, y = fn(p = n, m = h), m.text = m.node = y.pre, y.bgClass && (m.bgClass = y.bgClass), y.textClass &&
										(m.textClass = y.textClass), pn(p, m), mn(p, m, g, v), vn(p, m, v), m.node);
									o.insertBefore(d, a)
								}
								u += h.size
							}
							var p, m, g, v, y;
							for (; a;) a = l(a)
						}(e, n.updateLineNumbers, t.dims), 4 < f && (n.lineDiv.style.display = ""), n.renderedView = n.view,
						function (e) {
							if (e && e.activeElt && e.activeElt != F() && (e.activeElt.focus(), e.anchorNode && D(document.body, e.anchorNode) && D(
									document.body, e.focusNode))) {
								var t = window.getSelection(),
									n = document.createRange();
								n.setEnd(e.anchorNode, e.anchorOffset), n.collapse(!1), t.removeAllRanges(), t.addRange(n), t.extend(e.focusNode, e.focusOffset)
							}
						}(d), M(n.cursorDiv), M(n.selectionDiv), n.gutters.style.height = n.sizer.style.minHeight = 0, h && (n.lastWrapHeight = t.wrapperHeight,
							n.lastWrapWidth = t.wrapperWidth, ti(e, 400)), !(n.updateLineNumbers = null)
				}

				function oi(e, t) {
					for (var n = t.viewport, r = !0;
						(r && e.options.lineWrapping && t.oldDisplayWidth != Tn(e) || (n && null != n.top && (n = {
							top: Math.min(e.doc.height + Cn(e.display) - Mn(e), n.top)
						}), t.visible = br(e.display, e.doc, n), !(t.visible.from >= e.display.viewFrom && t.visible.to <= e.display.viewTo))) && ii(e,
							t); r = !1) {
						yr(e);
						var i = Fr(e);
						sr(e), Br(e, i), si(e, i), t.force = !1
					}
					t.signal(e, "update", e), e.display.viewFrom == e.display.reportedViewFrom && e.display.viewTo == e.display.reportedViewTo || (t
						.signal(e, "viewportChange", e, e.display.viewFrom, e.display.viewTo), e.display.reportedViewFrom = e.display.viewFrom, e.display
						.reportedViewTo = e.display.viewTo)
				}

				function ai(e, t) {
					var n = new ri(e, t);
					if (ii(e, n)) {
						yr(e), oi(e, n);
						var r = Fr(e);
						sr(e), Br(e, r), si(e, r), n.finish()
					}
				}

				function li(e) {
					var t = e.display.gutters.offsetWidth;
					e.display.sizer.style.marginLeft = t + "px"
				}

				function si(e, t) {
					e.display.sizer.style.minHeight = t.docHeight + "px", e.display.heightForcer.style.top = t.docHeight + "px", e.display.gutters.style
						.height = t.docHeight + e.display.barHeight + Ln(e) + "px"
				}

				function ui(e) {
					var t = e.display.gutters,
						n = e.options.gutters;
					M(t);
					for (var r = 0; r < n.length; ++r) {
						var i = n[r],
							o = t.appendChild(N("div", null, "CodeMirror-gutter " + i));
						"CodeMirror-linenumbers" == i && ((e.display.lineGutter = o).style.width = (e.display.lineNumWidth || 1) + "px")
					}
					t.style.display = r ? "" : "none", li(e)
				}

				function ci(e) {
					var t = _(e.gutters, "CodeMirror-linenumbers"); - 1 == t && e.lineNumbers ? e.gutters = e.gutters.concat([
						"CodeMirror-linenumbers"
					]) : -1 < t && !e.lineNumbers && (e.gutters = e.gutters.slice(0), e.gutters.splice(t, 1))
				}
				ri.prototype.signal = function (e, t) {
					lt(e, t) && this.events.push(arguments)
				}, ri.prototype.finish = function () {
					for (var e = 0; e < this.events.length; e++) it.apply(null, this.events[e])
				};
				var hi = 0,
					fi = null;

				function di(e) {
					var t = e.wheelDeltaX,
						n = e.wheelDeltaY;
					return null == t && e.detail && e.axis == e.HORIZONTAL_AXIS && (t = e.detail), null == n && e.detail && e.axis == e.VERTICAL_AXIS ?
						n = e.detail : null == n && (n = e.wheelDelta), {
							x: t,
							y: n
						}
				}

				function pi(e) {
					var t = di(e);
					return t.x *= fi, t.y *= fi, t
				}

				function mi(e, t) {
					var n = di(t),
						r = n.x,
						i = n.y,
						o = e.display,
						a = o.scroller,
						l = a.scrollWidth > a.clientWidth,
						s = a.scrollHeight > a.clientHeight;
					if (r && l || i && s) {
						if (i && b && x) e: for (var u = t.target, c = o.view; u != a; u = u.parentNode)
							for (var h = 0; h < c.length; h++)
								if (c[h].node == u) {
									e.display.currentWheelTarget = u;
									break e
								}
						if (r && !m && !g && null != fi) return i && s && Er(e, Math.max(0, a.scrollTop + i * fi)), Dr(e, Math.max(0, a.scrollLeft + r *
							fi)), (!i || i && s) && ut(t), void(o.wheelStartX = null);
						if (i && null != fi) {
							var f = i * fi,
								d = e.doc.scrollTop,
								p = d + o.wrapper.clientHeight;
							f < 0 ? d = Math.max(0, d + f - 50) : p = Math.min(e.doc.height, p + f + 50), ai(e, {
								top: d,
								bottom: p
							})
						}
						hi < 20 && (null == o.wheelStartX ? (o.wheelStartX = a.scrollLeft, o.wheelStartY = a.scrollTop, o.wheelDX = r, o.wheelDY = i,
							setTimeout(function () {
								if (null != o.wheelStartX) {
									var e = a.scrollLeft - o.wheelStartX,
										t = a.scrollTop - o.wheelStartY,
										n = t && o.wheelDY && t / o.wheelDY || e && o.wheelDX && e / o.wheelDX;
									o.wheelStartX = o.wheelStartY = null, n && (fi = (fi * hi + n) / (hi + 1), ++hi)
								}
							}, 200)) : (o.wheelDX += r, o.wheelDY += i))
					}
				}
				w ? fi = -.53 : m ? fi = 15 : a ? fi = -.7 : s && (fi = -1 / 3);
				var gi = function (e, t) {
					this.ranges = e, this.primIndex = t
				};
				gi.prototype.primary = function () {
					return this.ranges[this.primIndex]
				}, gi.prototype.equals = function (e) {
					if (e == this) return !0;
					if (e.primIndex != this.primIndex || e.ranges.length != this.ranges.length) return !1;
					for (var t = 0; t < this.ranges.length; t++) {
						var n = this.ranges[t],
							r = e.ranges[t];
						if (!ye(n.anchor, r.anchor) || !ye(n.head, r.head)) return !1
					}
					return !0
				}, gi.prototype.deepCopy = function () {
					for (var e = [], t = 0; t < this.ranges.length; t++) e[t] = new vi(xe(this.ranges[t].anchor), xe(this.ranges[t].head));
					return new gi(e, this.primIndex)
				}, gi.prototype.somethingSelected = function () {
					for (var e = 0; e < this.ranges.length; e++)
						if (!this.ranges[e].empty()) return !0;
					return !1
				}, gi.prototype.contains = function (e, t) {
					t || (t = e);
					for (var n = 0; n < this.ranges.length; n++) {
						var r = this.ranges[n];
						if (0 <= ve(t, r.from()) && ve(e, r.to()) <= 0) return n
					}
					return -1
				};
				var vi = function (e, t) {
					this.anchor = e, this.head = t
				};

				function yi(e, t, n) {
					var r = e && e.options.selectionsMayTouch,
						i = t[n];
					t.sort(function (e, t) {
						return ve(e.from(), t.from())
					}), n = _(t, i);
					for (var o = 1; o < t.length; o++) {
						var a = t[o],
							l = t[o - 1],
							s = ve(l.to(), a.from());
						if (r && !a.empty() ? 0 < s : 0 <= s) {
							var u = we(l.from(), a.from()),
								c = be(l.to(), a.to()),
								h = l.empty() ? a.from() == a.head : l.from() == l.head;
							o <= n && --n, t.splice(--o, 2, new vi(h ? c : u, h ? u : c))
						}
					}
					return new gi(t, n)
				}

				function xi(e, t) {
					return new gi([new vi(e, t || e)], 0)
				}

				function bi(e) {
					return e.text ? ge(e.from.line + e.text.length - 1, K(e.text).length + (1 == e.text.length ? e.from.ch : 0)) : e.to
				}

				function wi(e, t) {
					if (ve(e, t.from) < 0) return e;
					if (ve(e, t.to) <= 0) return bi(t);
					var n = e.line + t.text.length - (t.to.line - t.from.line) - 1,
						r = e.ch;
					return e.line == t.to.line && (r += bi(t).ch - t.to.ch), ge(n, r)
				}

				function ki(e, t) {
					for (var n = [], r = 0; r < e.sel.ranges.length; r++) {
						var i = e.sel.ranges[r];
						n.push(new vi(wi(i.anchor, t), wi(i.head, t)))
					}
					return yi(e.cm, n, e.sel.primIndex)
				}

				function Ci(e, t, n) {
					return e.line == t.line ? ge(n.line, e.ch - t.ch + n.ch) : ge(n.line + (e.line - t.line), e.ch)
				}

				function Si(e) {
					e.doc.mode = At(e.options, e.doc.modeOption), Li(e)
				}

				function Li(e) {
					e.doc.iter(function (e) {
						e.stateAfter && (e.stateAfter = null), e.styles && (e.styles = null)
					}), e.doc.modeFrontier = e.doc.highlightFrontier = e.doc.first, ti(e, 100), e.state.modeGen++, e.curOp && Zr(e)
				}

				function Ti(e, t) {
					return 0 == t.from.ch && 0 == t.to.ch && "" == K(t.text) && (!e.cm || e.cm.options.wholeLineUpdateBefore)
				}

				function Mi(e, r, t, i) {
					function o(e) {
						return t ? t[e] : null
					}

					function n(e, t, n) {
						! function (e, t, n, r) {
							e.text = t, e.stateAfter && (e.stateAfter = null), e.styles && (e.styles = null), null != e.order && (e.order = null), Fe(e),
								Oe(e, n);
							var i = r ? r(e) : 1;
							i != e.height && he(e, i)
						}(e, t, n, i), sn(e, "change", e, r)
					}

					function a(e, t) {
						for (var n = [], r = e; r < t; ++r) n.push(new Vt(u[r], o(r), i));
						return n
					}
					var l = r.from,
						s = r.to,
						u = r.text,
						c = se(e, l.line),
						h = se(e, s.line),
						f = K(u),
						d = o(u.length - 1),
						p = s.line - l.line;
					if (r.full) e.insert(0, a(0, u.length)), e.remove(u.length, e.size - u.length);
					else if (Ti(e, r)) {
						var m = a(0, u.length - 1);
						n(h, h.text, d), p && e.remove(l.line, p), m.length && e.insert(l.line, m)
					} else if (c == h)
						if (1 == u.length) n(c, c.text.slice(0, l.ch) + f + c.text.slice(s.ch), d);
						else {
							var g = a(1, u.length - 1);
							g.push(new Vt(f + c.text.slice(s.ch), d, i)), n(c, c.text.slice(0, l.ch) + u[0], o(0)), e.insert(l.line + 1, g)
						}
					else if (1 == u.length) n(c, c.text.slice(0, l.ch) + u[0] + h.text.slice(s.ch), o(0)), e.remove(l.line + 1, p);
					else {
						n(c, c.text.slice(0, l.ch) + u[0], o(0)), n(h, f + h.text.slice(s.ch), d);
						var v = a(1, u.length - 1);
						1 < p && e.remove(l.line + 1, p - 1), e.insert(l.line + 1, v)
					}
					sn(e, "change", e, r)
				}

				function Ai(e, l, s) {
					! function e(t, n, r) {
						if (t.linked)
							for (var i = 0; i < t.linked.length; ++i) {
								var o = t.linked[i];
								if (o.doc != n) {
									var a = r && o.sharedHist;
									s && !a || (l(o.doc, a), e(o.doc, t, a))
								}
							}
					}(e, null, !0)
				}

				function Ei(e, t) {
					if (t.cm) throw new Error("This document is already in use.");
					or((e.doc = t).cm = e), Si(e), Ni(e), e.options.lineWrapping || Ke(e), e.options.mode = t.modeOption, Zr(e)
				}

				function Ni(e) {
					("rtl" == e.doc.direction ? O : T)(e.display.lineDiv, "CodeMirror-rtl")
				}

				function Di(e) {
					this.done = [], this.undone = [], this.undoDepth = 1 / 0, this.lastModTime = this.lastSelTime = 0, this.lastOp = this.lastSelOp =
						null, this.lastOrigin = this.lastSelOrigin = null, this.generation = this.maxGeneration = e || 1
				}

				function Fi(e, t) {
					var n = {
						from: xe(t.from),
						to: bi(t),
						text: ue(e, t.from, t.to)
					};
					return Hi(e, n, t.from.line, t.to.line + 1), Ai(e, function (e) {
						return Hi(e, n, t.from.line, t.to.line + 1)
					}, !0), n
				}

				function Oi(e) {
					for (; e.length;) {
						if (!K(e).ranges) break;
						e.pop()
					}
				}

				function Ii(e, t, n, r) {
					var i = e.history;
					i.undone.length = 0;
					var o, a, l, s = +new Date;
					if ((i.lastOp == r || i.lastOrigin == t.origin && t.origin && ("+" == t.origin.charAt(0) && i.lastModTime > s - (e.cm ? e.cm.options
							.historyEventDelay : 500) || "*" == t.origin.charAt(0))) && (o = (l = i).lastOp == r ? (Oi(l.done), K(l.done)) : l.done.length &&
							!K(l.done).ranges ? K(l.done) : 1 < l.done.length && !l.done[l.done.length - 2].ranges ? (l.done.pop(), K(l.done)) : void 0)) a =
						K(o.changes), 0 == ve(t.from, t.to) && 0 == ve(t.from, a.to) ? a.to = bi(t) : o.changes.push(Fi(e, t));
					else {
						var u = K(i.done);
						for (u && u.ranges || Ri(e.sel, i.done), o = {
								changes: [Fi(e, t)],
								generation: i.generation
							}, i.done.push(o); i.done.length > i.undoDepth;) i.done.shift(), i.done[0].ranges || i.done.shift()
					}
					i.done.push(n), i.generation = ++i.maxGeneration, i.lastModTime = i.lastSelTime = s, i.lastOp = i.lastSelOp = r, i.lastOrigin =
						i.lastSelOrigin = t.origin, a || it(e, "historyAdded")
				}

				function Bi(e, t, n, r) {
					var i, o, a, l, s, u = e.history,
						c = r && r.origin;
					n == u.lastSelOp || c && u.lastSelOrigin == c && (u.lastModTime == u.lastSelTime && u.lastOrigin == c || (i = e, o = c, a = K(u.done),
							l = t, "*" == (s = o.charAt(0)) || "+" == s && a.ranges.length == l.ranges.length && a.somethingSelected() == l.somethingSelected() &&
							new Date - i.history.lastSelTime <= (i.cm ? i.cm.options.historyEventDelay : 500))) ? u.done[u.done.length - 1] = t : Ri(t, u.done),
						u.lastSelTime = +new Date, u.lastSelOrigin = c, u.lastSelOp = n, r && !1 !== r.clearRedo && Oi(u.undone)
				}

				function Ri(e, t) {
					var n = K(t);
					n && n.ranges && n.equals(e) || t.push(e)
				}

				function Hi(t, n, e, r) {
					var i = n["spans_" + t.id],
						o = 0;
					t.iter(Math.max(t.first, e), Math.min(t.first + t.size, r), function (e) {
						e.markedSpans && ((i || (i = n["spans_" + t.id] = {}))[o] = e.markedSpans), ++o
					})
				}

				function zi(e) {
					if (!e) return null;
					for (var t, n = 0; n < e.length; ++n) e[n].marker.explicitlyCleared ? t || (t = e.slice(0, n)) : t && t.push(e[n]);
					return t ? t.length ? t : null : e
				}

				function Pi(e, t) {
					var n = function (e, t) {
							var n = t["spans_" + e.id];
							if (!n) return null;
							for (var r = [], i = 0; i < t.text.length; ++i) r.push(zi(n[i]));
							return r
						}(e, t),
						r = Ne(e, t);
					if (!n) return r;
					if (!r) return n;
					for (var i = 0; i < n.length; ++i) {
						var o = n[i],
							a = r[i];
						if (o && a) e: for (var l = 0; l < a.length; ++l) {
							for (var s = a[l], u = 0; u < o.length; ++u)
								if (o[u].marker == s.marker) continue e;
							o.push(s)
						} else a && (n[i] = a)
					}
					return n
				}

				function _i(e, t, n) {
					for (var r = [], i = 0; i < e.length; ++i) {
						var o = e[i];
						if (o.ranges) r.push(n ? gi.prototype.deepCopy.call(o) : o);
						else {
							var a = o.changes,
								l = [];
							r.push({
								changes: l
							});
							for (var s = 0; s < a.length; ++s) {
								var u = a[s],
									c = void 0;
								if (l.push({
										from: u.from,
										to: u.to,
										text: u.text
									}), t)
									for (var h in u)(c = h.match(/^spans_(\d+)$/)) && -1 < _(t, Number(c[1])) && (K(l)[h] = u[h], delete u[h])
							}
						}
					}
					return r
				}

				function Wi(e, t, n, r) {
					if (r) {
						var i = e.anchor;
						if (n) {
							var o = ve(t, i) < 0;
							o != ve(n, i) < 0 ? (i = t, t = n) : o != ve(t, n) < 0 && (t = n)
						}
						return new vi(i, t)
					}
					return new vi(n || t, t)
				}

				function ji(e, t, n, r, i) {
					null == i && (i = e.cm && (e.cm.display.shift || e.extend)), Vi(e, new gi([Wi(e.sel.primary(), t, n, i)], 0), r)
				}

				function Ui(e, t, n) {
					for (var r = [], i = e.cm && (e.cm.display.shift || e.extend), o = 0; o < e.sel.ranges.length; o++) r[o] = Wi(e.sel.ranges[o], t[
						o], null, i);
					Vi(e, yi(e.cm, r, e.sel.primIndex), n)
				}

				function qi(e, t, n, r) {
					var i = e.sel.ranges.slice(0);
					i[t] = n, Vi(e, yi(e.cm, i, e.sel.primIndex), r)
				}

				function $i(e, t, n, r) {
					Vi(e, xi(t, n), r)
				}

				function Gi(e, t, n) {
					var r = e.history.done,
						i = K(r);
					i && i.ranges ? Xi(e, r[r.length - 1] = t, n) : Vi(e, t, n)
				}

				function Vi(e, t, n) {
					Xi(e, t, n), Bi(e, e.sel, e.cm ? e.cm.curOp.id : NaN, n)
				}

				function Xi(e, t, n) {
					var r, i, o, a;
					(lt(e, "beforeSelectionChange") || e.cm && lt(e.cm, "beforeSelectionChange")) && (r = e, o = n, a = {
						ranges: (i = t).ranges,
						update: function (e) {
							this.ranges = [];
							for (var t = 0; t < e.length; t++) this.ranges[t] = new vi(Ce(r, e[t].anchor), Ce(r, e[t].head))
						},
						origin: o && o.origin
					}, it(r, "beforeSelectionChange", r, a), r.cm && it(r.cm, "beforeSelectionChange", r.cm, a), t = a.ranges != i.ranges ? yi(r.cm,
						a.ranges, a.ranges.length - 1) : i), Ki(e, Yi(e, t, n && n.bias || (ve(t.primary().head, e.sel.primary().head) < 0 ? -1 : 1), !
						0)), n && !1 === n.scroll || !e.cm || Lr(e.cm)
				}

				function Ki(e, t) {
					t.equals(e.sel) || (e.sel = t, e.cm && (e.cm.curOp.updateInput = 1, e.cm.curOp.selectionChanged = !0, at(e.cm)), sn(e,
						"cursorActivity", e))
				}

				function Zi(e) {
					Ki(e, Yi(e, e.sel, null, !1))
				}

				function Yi(e, t, n, r) {
					for (var i, o = 0; o < t.ranges.length; o++) {
						var a = t.ranges[o],
							l = t.ranges.length == e.sel.ranges.length && e.sel.ranges[o],
							s = Qi(e, a.anchor, l && l.anchor, n, r),
							u = Qi(e, a.head, l && l.head, n, r);
						(i || s != a.anchor || u != a.head) && (i || (i = t.ranges.slice(0, o)), i[o] = new vi(s, u))
					}
					return i ? yi(e.cm, i, t.primIndex) : t
				}

				function Ji(e, t, n, r, i) {
					var o = se(e, t.line);
					if (o.markedSpans)
						for (var a = 0; a < o.markedSpans.length; ++a) {
							var l = o.markedSpans[a],
								s = l.marker;
							if ((null == l.from || (s.inclusiveLeft ? l.from <= t.ch : l.from < t.ch)) && (null == l.to || (s.inclusiveRight ? l.to >= t.ch :
									l.to > t.ch))) {
								if (i && (it(s, "beforeCursorEnter"), s.explicitlyCleared)) {
									if (o.markedSpans) {
										--a;
										continue
									}
									break
								}
								if (!s.atomic) continue;
								if (n) {
									var u = s.find(r < 0 ? 1 : -1),
										c = void 0;
									if ((r < 0 ? s.inclusiveRight : s.inclusiveLeft) && (u = eo(e, u, -r, u && u.line == t.line ? o : null)), u && u.line == t.line &&
										(c = ve(u, n)) && (r < 0 ? c < 0 : 0 < c)) return Ji(e, u, t, r, i)
								}
								var h = s.find(r < 0 ? -1 : 1);
								return (r < 0 ? s.inclusiveLeft : s.inclusiveRight) && (h = eo(e, h, r, h.line == t.line ? o : null)), h ? Ji(e, h, t, r, i) :
									null
							}
						}
					return t
				}

				function Qi(e, t, n, r, i) {
					var o = r || 1,
						a = Ji(e, t, n, o, i) || !i && Ji(e, t, n, o, !0) || Ji(e, t, n, -o, i) || !i && Ji(e, t, n, -o, !0);
					return a || (e.cantEdit = !0, ge(e.first, 0))
				}

				function eo(e, t, n, r) {
					return n < 0 && 0 == t.ch ? t.line > e.first ? Ce(e, ge(t.line - 1)) : null : 0 < n && t.ch == (r || se(e, t.line)).text.length ?
						t.line < e.first + e.size - 1 ? ge(t.line + 1, 0) : null : new ge(t.line, t.ch + n)
				}

				function to(e) {
					e.setSelection(ge(e.firstLine(), 0), ge(e.lastLine()), U)
				}

				function no(i, e, t) {
					var o = {
						canceled: !1,
						from: e.from,
						to: e.to,
						text: e.text,
						origin: e.origin,
						cancel: function () {
							return o.canceled = !0
						}
					};
					return t && (o.update = function (e, t, n, r) {
						e && (o.from = Ce(i, e)), t && (o.to = Ce(i, t)), n && (o.text = n), void 0 !== r && (o.origin = r)
					}), it(i, "beforeChange", i, o), i.cm && it(i.cm, "beforeChange", i.cm, o), o.canceled ? (i.cm && (i.cm.curOp.updateInput = 2),
						null) : {
						from: o.from,
						to: o.to,
						text: o.text,
						origin: o.origin
					}
				}

				function ro(e, t, n) {
					if (e.cm) {
						if (!e.cm.curOp) return Vr(e.cm, ro)(e, t, n);
						if (e.cm.state.suppressEdits) return
					}
					if (!(lt(e, "beforeChange") || e.cm && lt(e.cm, "beforeChange")) || (t = no(e, t, !0))) {
						var r = Le && !n && function (e, t, n) {
							var r = null;
							if (e.iter(t.line, n.line + 1, function (e) {
									if (e.markedSpans)
										for (var t = 0; t < e.markedSpans.length; ++t) {
											var n = e.markedSpans[t].marker;
											!n.readOnly || r && -1 != _(r, n) || (r || (r = [])).push(n)
										}
								}), !r) return null;
							for (var i = [{
									from: t,
									to: n
								}], o = 0; o < r.length; ++o)
								for (var a = r[o], l = a.find(0), s = 0; s < i.length; ++s) {
									var u = i[s];
									if (!(ve(u.to, l.from) < 0 || 0 < ve(u.from, l.to))) {
										var c = [s, 1],
											h = ve(u.from, l.from),
											f = ve(u.to, l.to);
										(h < 0 || !a.inclusiveLeft && !h) && c.push({
											from: u.from,
											to: l.from
										}), (0 < f || !a.inclusiveRight && !f) && c.push({
											from: l.to,
											to: u.to
										}), i.splice.apply(i, c), s += c.length - 3
									}
								}
							return i
						}(e, t.from, t.to);
						if (r)
							for (var i = r.length - 1; 0 <= i; --i) io(e, {
								from: r[i].from,
								to: r[i].to,
								text: i ? [""] : t.text,
								origin: t.origin
							});
						else io(e, t)
					}
				}

				function io(e, n) {
					if (1 != n.text.length || "" != n.text[0] || 0 != ve(n.from, n.to)) {
						var t = ki(e, n);
						Ii(e, n, t, e.cm ? e.cm.curOp.id : NaN), lo(e, n, t, Ne(e, n));
						var r = [];
						Ai(e, function (e, t) {
							t || -1 != _(r, e.history) || (ho(e.history, n), r.push(e.history)), lo(e, n, null, Ne(e, n))
						})
					}
				}

				function oo(i, o, e) {
					var t = i.cm && i.cm.state.suppressEdits;
					if (!t || e) {
						for (var a, n = i.history, r = i.sel, l = "undo" == o ? n.done : n.undone, s = "undo" == o ? n.undone : n.done, u = 0; u < l.length &&
							(a = l[u], e ? !a.ranges || a.equals(i.sel) : a.ranges); u++);
						if (u != l.length) {
							for (n.lastOrigin = n.lastSelOrigin = null;;) {
								if (!(a = l.pop()).ranges) {
									if (t) return void l.push(a);
									break
								}
								if (Ri(a, s), e && !a.equals(i.sel)) return void Vi(i, a, {
									clearRedo: !1
								});
								r = a
							}
							var c = [];
							Ri(r, s), s.push({
								changes: c,
								generation: n.generation
							}), n.generation = a.generation || ++n.maxGeneration;
							for (var h = lt(i, "beforeChange") || i.cm && lt(i.cm, "beforeChange"), f = function (e) {
									var n = a.changes[e];
									if (n.origin = o, h && !no(i, n, !1)) return l.length = 0, {};
									c.push(Fi(i, n));
									var t = e ? ki(i, n) : K(l);
									lo(i, n, t, Pi(i, n)), !e && i.cm && i.cm.scrollIntoView({
										from: n.from,
										to: bi(n)
									});
									var r = [];
									Ai(i, function (e, t) {
										t || -1 != _(r, e.history) || (ho(e.history, n), r.push(e.history)), lo(e, n, null, Pi(e, n))
									})
								}, d = a.changes.length - 1; 0 <= d; --d) {
								var p = f(d);
								if (p) return p.v
							}
						}
					}
				}

				function ao(e, t) {
					if (0 != t && (e.first += t, e.sel = new gi(Z(e.sel.ranges, function (e) {
							return new vi(ge(e.anchor.line + t, e.anchor.ch), ge(e.head.line + t, e.head.ch))
						}), e.sel.primIndex), e.cm)) {
						Zr(e.cm, e.first, e.first - t, t);
						for (var n = e.cm.display, r = n.viewFrom; r < n.viewTo; r++) Yr(e.cm, r, "gutter")
					}
				}

				function lo(e, t, n, r) {
					if (e.cm && !e.cm.curOp) return Vr(e.cm, lo)(e, t, n, r);
					if (t.to.line < e.first) ao(e, t.text.length - 1 - (t.to.line - t.from.line));
					else if (!(t.from.line > e.lastLine())) {
						if (t.from.line < e.first) {
							var i = t.text.length - 1 - (e.first - t.from.line);
							ao(e, i), t = {
								from: ge(e.first, 0),
								to: ge(t.to.line + i, t.to.ch),
								text: [K(t.text)],
								origin: t.origin
							}
						}
						var o = e.lastLine();
						t.to.line > o && (t = {
							from: t.from,
							to: ge(o, se(e, o).text.length),
							text: [t.text[0]],
							origin: t.origin
						}), t.removed = ue(e, t.from, t.to), n || (n = ki(e, t)), e.cm ? function (e, t, n) {
							var r = e.doc,
								i = e.display,
								o = t.from,
								a = t.to,
								l = !1,
								s = o.line;
							e.options.lineWrapping || (s = fe(je(se(r, o.line))), r.iter(s, a.line + 1, function (e) {
								if (e == i.maxLine) return l = !0
							})); - 1 < r.sel.contains(t.from, t.to) && at(e);
							Mi(r, t, n, ir(e)), e.options.lineWrapping || (r.iter(s, o.line + t.text.length, function (e) {
								var t = Xe(e);
								t > i.maxLineLength && (i.maxLine = e, i.maxLineLength = t, i.maxLineChanged = !0, l = !1)
							}), l && (e.curOp.updateMaxLine = !0));
							(function (e, t) {
								if (e.modeFrontier = Math.min(e.modeFrontier, t), !(e.highlightFrontier < t - 10)) {
									for (var n = e.first, r = t - 1; n < r; r--) {
										var i = se(e, r).stateAfter;
										if (i && (!(i instanceof Bt) || r + i.lookAhead < t)) {
											n = r + 1;
											break
										}
									}
									e.highlightFrontier = Math.min(e.highlightFrontier, n)
								}
							})(r, o.line), ti(e, 400);
							var u = t.text.length - (a.line - o.line) - 1;
							t.full ? Zr(e) : o.line != a.line || 1 != t.text.length || Ti(e.doc, t) ? Zr(e, o.line, a.line + 1, u) : Yr(e, o.line, "text");
							var c = lt(e, "changes"),
								h = lt(e, "change");
							if (h || c) {
								var f = {
									from: o,
									to: a,
									text: t.text,
									removed: t.removed,
									origin: t.origin
								};
								h && sn(e, "change", e, f), c && (e.curOp.changeObjs || (e.curOp.changeObjs = [])).push(f)
							}
							e.display.selForContextMenu = null
						}(e.cm, t, r) : Mi(e, t, r), Xi(e, n, U)
					}
				}

				function so(e, t, n, r, i) {
					var o;
					r || (r = n), ve(r, n) < 0 && (n = (o = [r, n])[0], r = o[1]), "string" == typeof t && (t = e.splitLines(t)), ro(e, {
						from: n,
						to: r,
						text: t,
						origin: i
					})
				}

				function uo(e, t, n, r) {
					n < e.line ? e.line += r : t < e.line && (e.line = t, e.ch = 0)
				}

				function co(e, t, n, r) {
					for (var i = 0; i < e.length; ++i) {
						var o = e[i],
							a = !0;
						if (o.ranges) {
							o.copied || ((o = e[i] = o.deepCopy()).copied = !0);
							for (var l = 0; l < o.ranges.length; l++) uo(o.ranges[l].anchor, t, n, r), uo(o.ranges[l].head, t, n, r)
						} else {
							for (var s = 0; s < o.changes.length; ++s) {
								var u = o.changes[s];
								if (n < u.from.line) u.from = ge(u.from.line + r, u.from.ch), u.to = ge(u.to.line + r, u.to.ch);
								else if (t <= u.to.line) {
									a = !1;
									break
								}
							}
							a || (e.splice(0, i + 1), i = 0)
						}
					}
				}

				function ho(e, t) {
					var n = t.from.line,
						r = t.to.line,
						i = t.text.length - (r - n) - 1;
					co(e.done, n, r, i), co(e.undone, n, r, i)
				}

				function fo(e, t, n, r) {
					var i = t,
						o = t;
					return "number" == typeof t ? o = se(e, ke(e, t)) : i = fe(t), null == i ? null : (r(o, i) && e.cm && Yr(e.cm, i, n), o)
				}

				function po(e) {
					this.lines = e, this.parent = null;
					for (var t = 0, n = 0; n < e.length; ++n) e[n].parent = this, t += e[n].height;
					this.height = t
				}

				function mo(e) {
					this.children = e;
					for (var t = 0, n = 0, r = 0; r < e.length; ++r) {
						var i = e[r];
						t += i.chunkSize(), n += i.height, i.parent = this
					}
					this.size = t, this.height = n, this.parent = null
				}
				vi.prototype.from = function () {
					return we(this.anchor, this.head)
				}, vi.prototype.to = function () {
					return be(this.anchor, this.head)
				}, vi.prototype.empty = function () {
					return this.head.line == this.anchor.line && this.head.ch == this.anchor.ch
				}, po.prototype = {
					chunkSize: function () {
						return this.lines.length
					},
					removeInner: function (e, t) {
						for (var n, r = e, i = e + t; r < i; ++r) {
							var o = this.lines[r];
							this.height -= o.height, (n = o).parent = null, Fe(n), sn(o, "delete")
						}
						this.lines.splice(e, t)
					},
					collapse: function (e) {
						e.push.apply(e, this.lines)
					},
					insertInner: function (e, t, n) {
						this.height += n, this.lines = this.lines.slice(0, e).concat(t).concat(this.lines.slice(e));
						for (var r = 0; r < t.length; ++r) t[r].parent = this
					},
					iterN: function (e, t, n) {
						for (var r = e + t; e < r; ++e)
							if (n(this.lines[e])) return !0
					}
				}, mo.prototype = {
					chunkSize: function () {
						return this.size
					},
					removeInner: function (e, t) {
						this.size -= t;
						for (var n = 0; n < this.children.length; ++n) {
							var r = this.children[n],
								i = r.chunkSize();
							if (e < i) {
								var o = Math.min(t, i - e),
									a = r.height;
								if (r.removeInner(e, o), this.height -= a - r.height, i == o && (this.children.splice(n--, 1), r.parent = null), 0 == (t -=
										o)) break;
								e = 0
							} else e -= i
						}
						if (this.size - t < 25 && (1 < this.children.length || !(this.children[0] instanceof po))) {
							var l = [];
							this.collapse(l), this.children = [new po(l)], this.children[0].parent = this
						}
					},
					collapse: function (e) {
						for (var t = 0; t < this.children.length; ++t) this.children[t].collapse(e)
					},
					insertInner: function (e, t, n) {
						this.size += t.length, this.height += n;
						for (var r = 0; r < this.children.length; ++r) {
							var i = this.children[r],
								o = i.chunkSize();
							if (e <= o) {
								if (i.insertInner(e, t, n), i.lines && 50 < i.lines.length) {
									for (var a = i.lines.length % 25 + 25, l = a; l < i.lines.length;) {
										var s = new po(i.lines.slice(l, l += 25));
										i.height -= s.height, this.children.splice(++r, 0, s), s.parent = this
									}
									i.lines = i.lines.slice(0, a), this.maybeSpill()
								}
								break
							}
							e -= o
						}
					},
					maybeSpill: function () {
						if (!(this.children.length <= 10)) {
							var e = this;
							do {
								var t = new mo(e.children.splice(e.children.length - 5, 5));
								if (e.parent) {
									e.size -= t.size, e.height -= t.height;
									var n = _(e.parent.children, e);
									e.parent.children.splice(n + 1, 0, t)
								} else {
									var r = new mo(e.children);
									(r.parent = e).children = [r, t], e = r
								}
								t.parent = e.parent
							} while (10 < e.children.length);
							e.parent.maybeSpill()
						}
					},
					iterN: function (e, t, n) {
						for (var r = 0; r < this.children.length; ++r) {
							var i = this.children[r],
								o = i.chunkSize();
							if (e < o) {
								var a = Math.min(t, o - e);
								if (i.iterN(e, a, n)) return !0;
								if (0 == (t -= a)) break;
								e = 0
							} else e -= o
						}
					}
				};
				var go = function (e, t, n) {
					if (n)
						for (var r in n) n.hasOwnProperty(r) && (this[r] = n[r]);
					this.doc = e, this.node = t
				};

				function vo(e, t, n) {
					Ve(t) < (e.curOp && e.curOp.scrollTop || e.doc.scrollTop) && Sr(e, n)
				}
				go.prototype.clear = function () {
					var e = this.doc.cm,
						t = this.line.widgets,
						n = this.line,
						r = fe(n);
					if (null != r && t) {
						for (var i = 0; i < t.length; ++i) t[i] == this && t.splice(i--, 1);
						t.length || (n.widgets = null);
						var o = bn(this);
						he(n, Math.max(0, n.height - o)), e && (Gr(e, function () {
							vo(e, n, -o), Yr(e, r, "widget")
						}), sn(e, "lineWidgetCleared", e, this, r))
					}
				}, go.prototype.changed = function () {
					var e = this,
						t = this.height,
						n = this.doc.cm,
						r = this.line;
					this.height = null;
					var i = bn(this) - t;
					i && ($e(this.doc, r) || he(r, r.height + i), n && Gr(n, function () {
						n.curOp.forceUpdate = !0, vo(n, r, i), sn(n, "lineWidgetChanged", n, e, fe(r))
					}))
				}, st(go);
				var yo = 0,
					xo = function (e, t) {
						this.lines = [], this.type = t, this.doc = e, this.id = ++yo
					};

				function bo(t, r, i, e, n) {
					if (e && e.shared) return function (e, n, r, i, o) {
						(i = H(i)).shared = !1;
						var a = [bo(e, n, r, i, o)],
							l = a[0],
							s = i.widgetNode;
						return Ai(e, function (e) {
							s && (i.widgetNode = s.cloneNode(!0)), a.push(bo(e, Ce(e, n), Ce(e, r), i, o));
							for (var t = 0; t < e.linked.length; ++t)
								if (e.linked[t].isParent) return;
							l = K(a)
						}), new wo(a, l)
					}(t, r, i, e, n);
					if (t.cm && !t.cm.curOp) return Vr(t.cm, bo)(t, r, i, e, n);
					var o = new xo(t, n),
						a = ve(r, i);
					if (e && H(e, o, !1), 0 < a || 0 == a && !1 !== o.clearWhenEmpty) return o;
					if (o.replacedWith && (o.collapsed = !0, o.widgetNode = E("span", [o.replacedWith], "CodeMirror-widget"), e.handleMouseEvents ||
							o.widgetNode.setAttribute("cm-ignore-events", "true"), e.insertLeft && (o.widgetNode.insertLeft = !0)), o.collapsed) {
						if (We(t, r.line, r, i, o) || r.line != i.line && We(t, i.line, r, i, o)) throw new Error(
							"Inserting collapsed marker partially overlapping an existing one");
						Te = !0
					}
					o.addToHistory && Ii(t, {
						from: r,
						to: i,
						origin: "markText"
					}, t.sel, NaN);
					var l, s = r.line,
						u = t.cm;
					if (t.iter(s, i.line + 1, function (e) {
							var t, n;
							u && o.collapsed && !u.options.lineWrapping && je(e) == u.display.maxLine && (l = !0), o.collapsed && s != r.line && he(e, 0),
								t = e, n = new Me(o, s == r.line ? r.ch : null, s == i.line ? i.ch : null), t.markedSpans = t.markedSpans ? t.markedSpans.concat(
									[n]) : [n], n.marker.attachLine(t), ++s
						}), o.collapsed && t.iter(r.line, i.line + 1, function (e) {
							$e(t, e) && he(e, 0)
						}), o.clearOnEnter && tt(o, "beforeCursorEnter", function () {
							return o.clear()
						}), o.readOnly && (Le = !0, (t.history.done.length || t.history.undone.length) && t.clearHistory()), o.collapsed && (o.id = ++
							yo, o.atomic = !0), u) {
						if (l && (u.curOp.updateMaxLine = !0), o.collapsed) Zr(u, r.line, i.line + 1);
						else if (o.className || o.startStyle || o.endStyle || o.css || o.attributes || o.title)
							for (var c = r.line; c <= i.line; c++) Yr(u, c, "text");
						o.atomic && Zi(u.doc), sn(u, "markerAdded", u, o)
					}
					return o
				}
				xo.prototype.clear = function () {
					var e = this;
					if (!this.explicitlyCleared) {
						var t = this.doc.cm,
							n = t && !t.curOp;
						if (n && _r(t), lt(this, "clear")) {
							var r = this.find();
							r && sn(this, "clear", r.from, r.to)
						}
						for (var i = null, o = null, a = 0; a < this.lines.length; ++a) {
							var l = e.lines[a],
								s = Ae(l.markedSpans, e);
							t && !e.collapsed ? Yr(t, fe(l), "text") : t && (null != s.to && (o = fe(l)), null != s.from && (i = fe(l))), l.markedSpans =
								Ee(l.markedSpans, s), null == s.from && e.collapsed && !$e(e.doc, l) && t && he(l, er(t.display))
						}
						if (t && this.collapsed && !t.options.lineWrapping)
							for (var u = 0; u < this.lines.length; ++u) {
								var c = je(e.lines[u]),
									h = Xe(c);
								h > t.display.maxLineLength && (t.display.maxLine = c, t.display.maxLineLength = h, t.display.maxLineChanged = !0)
							}
						null != i && t && this.collapsed && Zr(t, i, o + 1), this.lines.length = 0, this.explicitlyCleared = !0, this.atomic && this.doc
							.cantEdit && (this.doc.cantEdit = !1, t && Zi(t.doc)), t && sn(t, "markerCleared", t, this, i, o), n && Wr(t), this.parent &&
							this.parent.clear()
					}
				}, xo.prototype.find = function (e, t) {
					var n, r;
					null == e && "bookmark" == this.type && (e = 1);
					for (var i = 0; i < this.lines.length; ++i) {
						var o = this.lines[i],
							a = Ae(o.markedSpans, this);
						if (null != a.from && (n = ge(t ? o : fe(o), a.from), -1 == e)) return n;
						if (null != a.to && (r = ge(t ? o : fe(o), a.to), 1 == e)) return r
					}
					return n && {
						from: n,
						to: r
					}
				}, xo.prototype.changed = function () {
					var o = this,
						a = this.find(-1, !0),
						l = this,
						s = this.doc.cm;
					a && s && Gr(s, function () {
						var e = a.line,
							t = fe(a.line),
							n = Nn(s, t);
						if (n && (Hn(n), s.curOp.selectionChanged = s.curOp.forceUpdate = !0), s.curOp.updateMaxLine = !0, !$e(l.doc, e) && null !=
							l.height) {
							var r = l.height;
							l.height = null;
							var i = bn(l) - r;
							i && he(e, e.height + i)
						}
						sn(s, "markerChanged", s, o)
					})
				}, xo.prototype.attachLine = function (e) {
					if (!this.lines.length && this.doc.cm) {
						var t = this.doc.cm.curOp;
						t.maybeHiddenMarkers && -1 != _(t.maybeHiddenMarkers, this) || (t.maybeUnhiddenMarkers || (t.maybeUnhiddenMarkers = [])).push(
							this)
					}
					this.lines.push(e)
				}, xo.prototype.detachLine = function (e) {
					if (this.lines.splice(_(this.lines, e), 1), !this.lines.length && this.doc.cm) {
						var t = this.doc.cm.curOp;
						(t.maybeHiddenMarkers || (t.maybeHiddenMarkers = [])).push(this)
					}
				}, st(xo);
				var wo = function (e, t) {
					this.markers = e, this.primary = t;
					for (var n = 0; n < e.length; ++n) e[n].parent = this
				};

				function ko(e) {
					return e.findMarks(ge(e.first, 0), e.clipPos(ge(e.lastLine())), function (e) {
						return e.parent
					})
				}

				function Co(o) {
					for (var e = function (e) {
							var t = o[e],
								n = [t.primary.doc];
							Ai(t.primary.doc, function (e) {
								return n.push(e)
							});
							for (var r = 0; r < t.markers.length; r++) {
								var i = t.markers[r]; - 1 == _(n, i.doc) && (i.parent = null, t.markers.splice(r--, 1))
							}
						}, t = 0; t < o.length; t++) e(t)
				}
				wo.prototype.clear = function () {
					if (!this.explicitlyCleared) {
						this.explicitlyCleared = !0;
						for (var e = 0; e < this.markers.length; ++e) this.markers[e].clear();
						sn(this, "clear")
					}
				}, wo.prototype.find = function (e, t) {
					return this.primary.find(e, t)
				}, st(wo);
				var So = 0,
					Lo = function (e, t, n, r, i) {
						if (!(this instanceof Lo)) return new Lo(e, t, n, r, i);
						null == n && (n = 0), mo.call(this, [new po([new Vt("", null)])]), this.first = n, this.scrollTop = this.scrollLeft = 0, this.cantEdit = !
							1, this.cleanGeneration = 1, this.modeFrontier = this.highlightFrontier = n;
						var o = ge(n, 0);
						this.sel = xi(o), this.history = new Di(null), this.id = ++So, this.modeOption = t, this.lineSep = r, this.direction = "rtl" ==
							i ? "rtl" : "ltr", this.extend = !1, "string" == typeof e && (e = this.splitLines(e)), Mi(this, {
								from: o,
								to: o,
								text: e
							}), Vi(this, xi(o), U)
					};
				Lo.prototype = J(mo.prototype, {
					constructor: Lo,
					iter: function (e, t, n) {
						n ? this.iterN(e - this.first, t - e, n) : this.iterN(this.first, this.first + this.size, e)
					},
					insert: function (e, t) {
						for (var n = 0, r = 0; r < t.length; ++r) n += t[r].height;
						this.insertInner(e - this.first, t, n)
					},
					remove: function (e, t) {
						this.removeInner(e - this.first, t)
					},
					getValue: function (e) {
						var t = ce(this, this.first, this.first + this.size);
						return !1 === e ? t : t.join(e || this.lineSeparator())
					},
					setValue: Kr(function (e) {
						var t = ge(this.first, 0),
							n = this.first + this.size - 1;
						ro(this, {
							from: t,
							to: ge(n, se(this, n).text.length),
							text: this.splitLines(e),
							origin: "setValue",
							full: !0
						}, !0), this.cm && Tr(this.cm, 0, 0), Vi(this, xi(t), U)
					}),
					replaceRange: function (e, t, n, r) {
						so(this, e, t = Ce(this, t), n = n ? Ce(this, n) : t, r)
					},
					getRange: function (e, t, n) {
						var r = ue(this, Ce(this, e), Ce(this, t));
						return !1 === n ? r : r.join(n || this.lineSeparator())
					},
					getLine: function (e) {
						var t = this.getLineHandle(e);
						return t && t.text
					},
					getLineHandle: function (e) {
						if (pe(this, e)) return se(this, e)
					},
					getLineNumber: function (e) {
						return fe(e)
					},
					getLineHandleVisualStart: function (e) {
						return "number" == typeof e && (e = se(this, e)), je(e)
					},
					lineCount: function () {
						return this.size
					},
					firstLine: function () {
						return this.first
					},
					lastLine: function () {
						return this.first + this.size - 1
					},
					clipPos: function (e) {
						return Ce(this, e)
					},
					getCursor: function (e) {
						var t = this.sel.primary();
						return null == e || "head" == e ? t.head : "anchor" == e ? t.anchor : "end" == e || "to" == e || !1 === e ? t.to() : t.from()
					},
					listSelections: function () {
						return this.sel.ranges
					},
					somethingSelected: function () {
						return this.sel.somethingSelected()
					},
					setCursor: Kr(function (e, t, n) {
						$i(this, Ce(this, "number" == typeof e ? ge(e, t || 0) : e), null, n)
					}),
					setSelection: Kr(function (e, t, n) {
						$i(this, Ce(this, e), Ce(this, t || e), n)
					}),
					extendSelection: Kr(function (e, t, n) {
						ji(this, Ce(this, e), t && Ce(this, t), n)
					}),
					extendSelections: Kr(function (e, t) {
						Ui(this, Se(this, e), t)
					}),
					extendSelectionsBy: Kr(function (e, t) {
						Ui(this, Se(this, Z(this.sel.ranges, e)), t)
					}),
					setSelections: Kr(function (e, t, n) {
						if (e.length) {
							for (var r = [], i = 0; i < e.length; i++) r[i] = new vi(Ce(this, e[i].anchor), Ce(this, e[i].head));
							null == t && (t = Math.min(e.length - 1, this.sel.primIndex)), Vi(this, yi(this.cm, r, t), n)
						}
					}),
					addSelection: Kr(function (e, t, n) {
						var r = this.sel.ranges.slice(0);
						r.push(new vi(Ce(this, e), Ce(this, t || e))), Vi(this, yi(this.cm, r, r.length - 1), n)
					}),
					getSelection: function (e) {
						for (var t, n = this.sel.ranges, r = 0; r < n.length; r++) {
							var i = ue(this, n[r].from(), n[r].to());
							t = t ? t.concat(i) : i
						}
						return !1 === e ? t : t.join(e || this.lineSeparator())
					},
					getSelections: function (e) {
						for (var t = [], n = this.sel.ranges, r = 0; r < n.length; r++) {
							var i = ue(this, n[r].from(), n[r].to());
							!1 !== e && (i = i.join(e || this.lineSeparator())), t[r] = i
						}
						return t
					},
					replaceSelection: function (e, t, n) {
						for (var r = [], i = 0; i < this.sel.ranges.length; i++) r[i] = e;
						this.replaceSelections(r, t, n || "+input")
					},
					replaceSelections: Kr(function (e, t, n) {
						for (var r = [], i = this.sel, o = 0; o < i.ranges.length; o++) {
							var a = i.ranges[o];
							r[o] = {
								from: a.from(),
								to: a.to(),
								text: this.splitLines(e[o]),
								origin: n
							}
						}
						for (var l = t && "end" != t && function (e, t, n) {
								for (var r = [], i = ge(e.first, 0), o = i, a = 0; a < t.length; a++) {
									var l = t[a],
										s = Ci(l.from, i, o),
										u = Ci(bi(l), i, o);
									if (i = l.to, o = u, "around" == n) {
										var c = e.sel.ranges[a],
											h = ve(c.head, c.anchor) < 0;
										r[a] = new vi(h ? u : s, h ? s : u)
									} else r[a] = new vi(s, s)
								}
								return new gi(r, e.sel.primIndex)
							}(this, r, t), s = r.length - 1; 0 <= s; s--) ro(this, r[s]);
						l ? Gi(this, l) : this.cm && Lr(this.cm)
					}),
					undo: Kr(function () {
						oo(this, "undo")
					}),
					redo: Kr(function () {
						oo(this, "redo")
					}),
					undoSelection: Kr(function () {
						oo(this, "undo", !0)
					}),
					redoSelection: Kr(function () {
						oo(this, "redo", !0)
					}),
					setExtending: function (e) {
						this.extend = e
					},
					getExtending: function () {
						return this.extend
					},
					historySize: function () {
						for (var e = this.history, t = 0, n = 0, r = 0; r < e.done.length; r++) e.done[r].ranges || ++t;
						for (var i = 0; i < e.undone.length; i++) e.undone[i].ranges || ++n;
						return {
							undo: t,
							redo: n
						}
					},
					clearHistory: function () {
						this.history = new Di(this.history.maxGeneration)
					},
					markClean: function () {
						this.cleanGeneration = this.changeGeneration(!0)
					},
					changeGeneration: function (e) {
						return e && (this.history.lastOp = this.history.lastSelOp = this.history.lastOrigin = null), this.history.generation
					},
					isClean: function (e) {
						return this.history.generation == (e || this.cleanGeneration)
					},
					getHistory: function () {
						return {
							done: _i(this.history.done),
							undone: _i(this.history.undone)
						}
					},
					setHistory: function (e) {
						var t = this.history = new Di(this.history.maxGeneration);
						t.done = _i(e.done.slice(0), null, !0), t.undone = _i(e.undone.slice(0), null, !0)
					},
					setGutterMarker: Kr(function (e, n, r) {
						return fo(this, e, "gutter", function (e) {
							var t = e.gutterMarkers || (e.gutterMarkers = {});
							return !(t[n] = r) && ne(t) && (e.gutterMarkers = null), !0
						})
					}),
					clearGutter: Kr(function (t) {
						var n = this;
						this.iter(function (e) {
							e.gutterMarkers && e.gutterMarkers[t] && fo(n, e, "gutter", function () {
								return e.gutterMarkers[t] = null, ne(e.gutterMarkers) && (e.gutterMarkers = null), !0
							})
						})
					}),
					lineInfo: function (e) {
						var t;
						if ("number" == typeof e) {
							if (!pe(this, e)) return null;
							if (!(e = se(this, t = e))) return null
						} else if (null == (t = fe(e))) return null;
						return {
							line: t,
							handle: e,
							text: e.text,
							gutterMarkers: e.gutterMarkers,
							textClass: e.textClass,
							bgClass: e.bgClass,
							wrapClass: e.wrapClass,
							widgets: e.widgets
						}
					},
					addLineClass: Kr(function (e, n, r) {
						return fo(this, e, "gutter" == n ? "gutter" : "class", function (e) {
							var t = "text" == n ? "textClass" : "background" == n ? "bgClass" : "gutter" == n ? "gutterClass" : "wrapClass";
							if (e[t]) {
								if (S(r).test(e[t])) return !1;
								e[t] += " " + r
							} else e[t] = r;
							return !0
						})
					}),
					removeLineClass: Kr(function (e, o, a) {
						return fo(this, e, "gutter" == o ? "gutter" : "class", function (e) {
							var t = "text" == o ? "textClass" : "background" == o ? "bgClass" : "gutter" == o ? "gutterClass" : "wrapClass",
								n = e[t];
							if (!n) return !1;
							if (null == a) e[t] = null;
							else {
								var r = n.match(S(a));
								if (!r) return !1;
								var i = r.index + r[0].length;
								e[t] = n.slice(0, r.index) + (r.index && i != n.length ? " " : "") + n.slice(i) || null
							}
							return !0
						})
					}),
					addLineWidget: Kr(function (e, t, n) {
						return i = e, o = new go(r = this, t, n), (a = r.cm) && o.noHScroll && (a.display.alignWidgets = !0), fo(r, i, "widget",
							function (e) {
								var t = e.widgets || (e.widgets = []);
								if (null == o.insertAt ? t.push(o) : t.splice(Math.min(t.length - 1, Math.max(0, o.insertAt)), 0, o), o.line = e, a && !
									$e(r, e)) {
									var n = Ve(e) < r.scrollTop;
									he(e, e.height + bn(o)), n && Sr(a, o.height), a.curOp.forceUpdate = !0
								}
								return !0
							}), a && sn(a, "lineWidgetAdded", a, o, "number" == typeof i ? i : fe(i)), o;
						var r, i, o, a
					}),
					removeLineWidget: function (e) {
						e.clear()
					},
					markText: function (e, t, n) {
						return bo(this, Ce(this, e), Ce(this, t), n, n && n.type || "range")
					},
					setBookmark: function (e, t) {
						var n = {
							replacedWith: t && (null == t.nodeType ? t.widget : t),
							insertLeft: t && t.insertLeft,
							clearWhenEmpty: !1,
							shared: t && t.shared,
							handleMouseEvents: t && t.handleMouseEvents
						};
						return bo(this, e = Ce(this, e), e, n, "bookmark")
					},
					findMarksAt: function (e) {
						var t = [],
							n = se(this, (e = Ce(this, e)).line).markedSpans;
						if (n)
							for (var r = 0; r < n.length; ++r) {
								var i = n[r];
								(null == i.from || i.from <= e.ch) && (null == i.to || i.to >= e.ch) && t.push(i.marker.parent || i.marker)
							}
						return t
					},
					findMarks: function (i, o, a) {
						i = Ce(this, i), o = Ce(this, o);
						var l = [],
							s = i.line;
						return this.iter(i.line, o.line + 1, function (e) {
							var t = e.markedSpans;
							if (t)
								for (var n = 0; n < t.length; n++) {
									var r = t[n];
									null != r.to && s == i.line && i.ch >= r.to || null == r.from && s != i.line || null != r.from && s == o.line && r.from >=
										o.ch || a && !a(r.marker) || l.push(r.marker.parent || r.marker)
								}++s
						}), l
					},
					getAllMarks: function () {
						var r = [];
						return this.iter(function (e) {
							var t = e.markedSpans;
							if (t)
								for (var n = 0; n < t.length; ++n) null != t[n].from && r.push(t[n].marker)
						}), r
					},
					posFromIndex: function (n) {
						var r, i = this.first,
							o = this.lineSeparator().length;
						return this.iter(function (e) {
							var t = e.text.length + o;
							if (n < t) return r = n, !0;
							n -= t, ++i
						}), Ce(this, ge(i, r))
					},
					indexFromPos: function (e) {
						var t = (e = Ce(this, e)).ch;
						if (e.line < this.first || e.ch < 0) return 0;
						var n = this.lineSeparator().length;
						return this.iter(this.first, e.line, function (e) {
							t += e.text.length + n
						}), t
					},
					copy: function (e) {
						var t = new Lo(ce(this, this.first, this.first + this.size), this.modeOption, this.first, this.lineSep, this.direction);
						return t.scrollTop = this.scrollTop, t.scrollLeft = this.scrollLeft, t.sel = this.sel, t.extend = !1, e && (t.history.undoDepth =
							this.history.undoDepth, t.setHistory(this.getHistory())), t
					},
					linkedDoc: function (e) {
						e || (e = {});
						var t = this.first,
							n = this.first + this.size;
						null != e.from && e.from > t && (t = e.from), null != e.to && e.to < n && (n = e.to);
						var r = new Lo(ce(this, t, n), e.mode || this.modeOption, t, this.lineSep, this.direction);
						return e.sharedHist && (r.history = this.history), (this.linked || (this.linked = [])).push({
								doc: r,
								sharedHist: e.sharedHist
							}), r.linked = [{
								doc: this,
								isParent: !0,
								sharedHist: e.sharedHist
							}],
							function (e, t) {
								for (var n = 0; n < t.length; n++) {
									var r = t[n],
										i = r.find(),
										o = e.clipPos(i.from),
										a = e.clipPos(i.to);
									if (ve(o, a)) {
										var l = bo(e, o, a, r.primary, r.primary.type);
										r.markers.push(l), l.parent = r
									}
								}
							}(r, ko(this)), r
					},
					unlinkDoc: function (e) {
						if (e instanceof ka && (e = e.doc), this.linked)
							for (var t = 0; t < this.linked.length; ++t) {
								if (this.linked[t].doc == e) {
									this.linked.splice(t, 1), e.unlinkDoc(this), Co(ko(this));
									break
								}
							}
						if (e.history == this.history) {
							var n = [e.id];
							Ai(e, function (e) {
								return n.push(e.id)
							}, !0), e.history = new Di(null), e.history.done = _i(this.history.done, n), e.history.undone = _i(this.history.undone, n)
						}
					},
					iterLinkedDocs: function (e) {
						Ai(this, e)
					},
					getMode: function () {
						return this.mode
					},
					getEditor: function () {
						return this.cm
					},
					splitLines: function (e) {
						return this.lineSep ? e.split(this.lineSep) : wt(e)
					},
					lineSeparator: function () {
						return this.lineSep || "\n"
					},
					setDirection: Kr(function (e) {
						var t;
						("rtl" != e && (e = "ltr"), e != this.direction) && (this.direction = e, this.iter(function (e) {
							return e.order = null
						}), this.cm && Gr(t = this.cm, function () {
							Ni(t), Zr(t)
						}))
					})
				}), Lo.prototype.eachLine = Lo.prototype.iter;
				var To = 0;

				function Mo(e) {
					var i = this;
					if (Ao(i), !ot(i, e) && !wn(i.display, e)) {
						ut(e), w && (To = +new Date);
						var o = ar(i, e, !0),
							t = e.dataTransfer.files;
						if (o && !i.isReadOnly())
							if (t && t.length && window.FileReader && window.File)
								for (var a = t.length, l = Array(a), s = 0, n = function (e, n) {
										if (!i.options.allowDropFileTypes || -1 != _(i.options.allowDropFileTypes, e.type)) {
											var r = new FileReader;
											r.onload = Vr(i, function () {
												var e = r.result;
												if (/[\x00-\x08\x0e-\x1f]{2}/.test(e) && (e = ""), l[n] = e, ++s == a) {
													var t = {
														from: o = Ce(i.doc, o),
														to: o,
														text: i.doc.splitLines(l.join(i.doc.lineSeparator())),
														origin: "paste"
													};
													ro(i.doc, t), Gi(i.doc, xi(o, bi(t)))
												}
											}), r.readAsText(e)
										}
									}, r = 0; r < a; ++r) n(t[r], r);
							else {
								if (i.state.draggingText && -1 < i.doc.sel.contains(o)) return i.state.draggingText(e), void setTimeout(function () {
									return i.display.input.focus()
								}, 20);
								try {
									var u = e.dataTransfer.getData("Text");
									if (u) {
										var c;
										if (i.state.draggingText && !i.state.draggingText.copy && (c = i.listSelections()), Xi(i.doc, xi(o, o)), c)
											for (var h = 0; h < c.length; ++h) so(i.doc, "", c[h].anchor, c[h].head, "drag");
										i.replaceSelection(u, "around", "paste"), i.display.input.focus()
									}
								} catch (e) {}
							}
					}
				}

				function Ao(e) {
					e.display.dragCursor && (e.display.lineSpace.removeChild(e.display.dragCursor), e.display.dragCursor = null)
				}

				function Eo(t) {
					if (document.getElementsByClassName) {
						for (var e = document.getElementsByClassName("CodeMirror"), n = [], r = 0; r < e.length; r++) {
							var i = e[r].CodeMirror;
							i && n.push(i)
						}
						n.length && n[0].operation(function () {
							for (var e = 0; e < n.length; e++) t(n[e])
						})
					}
				}
				var No = !1;

				function Do() {
					var e;
					No || (tt(window, "resize", function () {
						null == e && (e = setTimeout(function () {
							e = null, Eo(Fo)
						}, 100))
					}), tt(window, "blur", function () {
						return Eo(vr)
					}), No = !0)
				}

				function Fo(e) {
					var t = e.display;
					t.cachedCharWidth = t.cachedTextHeight = t.cachedPaddingH = null, t.scrollbarsClipped = !1, e.setSize()
				}
				for (var Oo = {
						3: "Pause",
						8: "Backspace",
						9: "Tab",
						13: "Enter",
						16: "Shift",
						17: "Ctrl",
						18: "Alt",
						19: "Pause",
						20: "CapsLock",
						27: "Esc",
						32: "Space",
						33: "PageUp",
						34: "PageDown",
						35: "End",
						36: "Home",
						37: "Left",
						38: "Up",
						39: "Right",
						40: "Down",
						44: "PrintScrn",
						45: "Insert",
						46: "Delete",
						59: ";",
						61: "=",
						91: "Mod",
						92: "Mod",
						93: "Mod",
						106: "*",
						107: "=",
						109: "-",
						110: ".",
						111: "/",
						127: "Delete",
						145: "ScrollLock",
						173: "-",
						186: ";",
						187: "=",
						188: ",",
						189: "-",
						190: ".",
						191: "/",
						192: "`",
						219: "[",
						220: "\\",
						221: "]",
						222: "'",
						63232: "Up",
						63233: "Down",
						63234: "Left",
						63235: "Right",
						63272: "Delete",
						63273: "Home",
						63275: "End",
						63276: "PageUp",
						63277: "PageDown",
						63302: "Insert"
					}, Io = 0; Io < 10; Io++) Oo[Io + 48] = Oo[Io + 96] = String(Io);
				for (var Bo = 65; Bo <= 90; Bo++) Oo[Bo] = String.fromCharCode(Bo);
				for (var Ro = 1; Ro <= 12; Ro++) Oo[Ro + 111] = Oo[Ro + 63235] = "F" + Ro;
				var Ho = {};

				function zo(e) {
					var t, n, r, i, o = e.split(/-(?!$)/);
					e = o[o.length - 1];
					for (var a = 0; a < o.length - 1; a++) {
						var l = o[a];
						if (/^(cmd|meta|m)$/i.test(l)) i = !0;
						else if (/^a(lt)?$/i.test(l)) t = !0;
						else if (/^(c|ctrl|control)$/i.test(l)) n = !0;
						else {
							if (!/^s(hift)?$/i.test(l)) throw new Error("Unrecognized modifier name: " + l);
							r = !0
						}
					}
					return t && (e = "Alt-" + e), n && (e = "Ctrl-" + e), i && (e = "Cmd-" + e), r && (e = "Shift-" + e), e
				}

				function Po(e) {
					var t = {};
					for (var n in e)
						if (e.hasOwnProperty(n)) {
							var r = e[n];
							if (/^(name|fallthrough|(de|at)tach)$/.test(n)) continue;
							if ("..." == r) {
								delete e[n];
								continue
							}
							for (var i = Z(n.split(" "), zo), o = 0; o < i.length; o++) {
								var a = void 0,
									l = void 0;
								a = o == i.length - 1 ? (l = i.join(" "), r) : (l = i.slice(0, o + 1).join(" "), "...");
								var s = t[l];
								if (s) {
									if (s != a) throw new Error("Inconsistent bindings for " + l)
								} else t[l] = a
							}
							delete e[n]
						}
					for (var u in t) e[u] = t[u];
					return e
				}

				function _o(e, t, n, r) {
					var i = (t = qo(t)).call ? t.call(e, r) : t[e];
					if (!1 === i) return "nothing";
					if ("..." === i) return "multi";
					if (null != i && n(i)) return "handled";
					if (t.fallthrough) {
						if ("[object Array]" != Object.prototype.toString.call(t.fallthrough)) return _o(e, t.fallthrough, n, r);
						for (var o = 0; o < t.fallthrough.length; o++) {
							var a = _o(e, t.fallthrough[o], n, r);
							if (a) return a
						}
					}
				}

				function Wo(e) {
					var t = "string" == typeof e ? e : Oo[e.keyCode];
					return "Ctrl" == t || "Alt" == t || "Shift" == t || "Mod" == t
				}

				function jo(e, t, n) {
					var r = e;
					return t.altKey && "Alt" != r && (e = "Alt-" + e), (y ? t.metaKey : t.ctrlKey) && "Ctrl" != r && (e = "Ctrl-" + e), (y ? t.ctrlKey :
						t.metaKey) && "Cmd" != r && (e = "Cmd-" + e), !n && t.shiftKey && "Shift" != r && (e = "Shift-" + e), e
				}

				function Uo(e, t) {
					if (g && 34 == e.keyCode && e.char) return !1;
					var n = Oo[e.keyCode];
					return null != n && !e.altGraphKey && (3 == e.keyCode && e.code && (n = e.code), jo(n, e, t))
				}

				function qo(e) {
					return "string" == typeof e ? Ho[e] : e
				}

				function $o(t, e) {
					for (var n = t.doc.sel.ranges, r = [], i = 0; i < n.length; i++) {
						for (var o = e(n[i]); r.length && ve(o.from, K(r).to) <= 0;) {
							var a = r.pop();
							if (ve(a.from, o.from) < 0) {
								o.from = a.from;
								break
							}
						}
						r.push(o)
					}
					Gr(t, function () {
						for (var e = r.length - 1; 0 <= e; e--) so(t.doc, "", r[e].from, r[e].to, "+delete");
						Lr(t)
					})
				}

				function Go(e, t, n) {
					var r = oe(e.text, t + n, n);
					return r < 0 || r > e.text.length ? null : r
				}

				function Vo(e, t, n) {
					var r = Go(e, t.ch, n);
					return null == r ? null : new ge(t.line, r, n < 0 ? "after" : "before")
				}

				function Xo(e, t, n, r, i) {
					if (e) {
						var o = Qe(n, t.doc.direction);
						if (o) {
							var a, l = i < 0 ? K(o) : o[0],
								s = i < 0 == (1 == l.level) ? "after" : "before";
							if (0 < l.level || "rtl" == t.doc.direction) {
								var u = Dn(t, n);
								a = i < 0 ? n.text.length - 1 : 0;
								var c = Fn(t, u, a).top;
								a = ae(function (e) {
									return Fn(t, u, e).top == c
								}, i < 0 == (1 == l.level) ? l.from : l.to - 1, a), "before" == s && (a = Go(n, a, 1))
							} else a = i < 0 ? l.to : l.from;
							return new ge(r, a, s)
						}
					}
					return new ge(r, i < 0 ? n.text.length : 0, i < 0 ? "before" : "after")
				}
				Ho.basic = {
					Left: "goCharLeft",
					Right: "goCharRight",
					Up: "goLineUp",
					Down: "goLineDown",
					End: "goLineEnd",
					Home: "goLineStartSmart",
					PageUp: "goPageUp",
					PageDown: "goPageDown",
					Delete: "delCharAfter",
					Backspace: "delCharBefore",
					"Shift-Backspace": "delCharBefore",
					Tab: "defaultTab",
					"Shift-Tab": "indentAuto",
					Enter: "newlineAndIndent",
					Insert: "toggleOverwrite",
					Esc: "singleSelection"
				}, Ho.pcDefault = {
					"Ctrl-A": "selectAll",
					"Ctrl-D": "deleteLine",
					"Ctrl-Z": "undo",
					"Shift-Ctrl-Z": "redo",
					"Ctrl-Y": "redo",
					"Ctrl-Home": "goDocStart",
					"Ctrl-End": "goDocEnd",
					"Ctrl-Up": "goLineUp",
					"Ctrl-Down": "goLineDown",
					"Ctrl-Left": "goGroupLeft",
					"Ctrl-Right": "goGroupRight",
					"Alt-Left": "goLineStart",
					"Alt-Right": "goLineEnd",
					"Ctrl-Backspace": "delGroupBefore",
					"Ctrl-Delete": "delGroupAfter",
					"Ctrl-S": "save",
					"Ctrl-F": "find",
					"Ctrl-G": "findNext",
					"Shift-Ctrl-G": "findPrev",
					"Shift-Ctrl-F": "replace",
					"Shift-Ctrl-R": "replaceAll",
					"Ctrl-[": "indentLess",
					"Ctrl-]": "indentMore",
					"Ctrl-U": "undoSelection",
					"Shift-Ctrl-U": "redoSelection",
					"Alt-U": "redoSelection",
					fallthrough: "basic"
				}, Ho.emacsy = {
					"Ctrl-F": "goCharRight",
					"Ctrl-B": "goCharLeft",
					"Ctrl-P": "goLineUp",
					"Ctrl-N": "goLineDown",
					"Alt-F": "goWordRight",
					"Alt-B": "goWordLeft",
					"Ctrl-A": "goLineStart",
					"Ctrl-E": "goLineEnd",
					"Ctrl-V": "goPageDown",
					"Shift-Ctrl-V": "goPageUp",
					"Ctrl-D": "delCharAfter",
					"Ctrl-H": "delCharBefore",
					"Alt-D": "delWordAfter",
					"Alt-Backspace": "delWordBefore",
					"Ctrl-K": "killLine",
					"Ctrl-T": "transposeChars",
					"Ctrl-O": "openLine"
				}, Ho.macDefault = {
					"Cmd-A": "selectAll",
					"Cmd-D": "deleteLine",
					"Cmd-Z": "undo",
					"Shift-Cmd-Z": "redo",
					"Cmd-Y": "redo",
					"Cmd-Home": "goDocStart",
					"Cmd-Up": "goDocStart",
					"Cmd-End": "goDocEnd",
					"Cmd-Down": "goDocEnd",
					"Alt-Left": "goGroupLeft",
					"Alt-Right": "goGroupRight",
					"Cmd-Left": "goLineLeft",
					"Cmd-Right": "goLineRight",
					"Alt-Backspace": "delGroupBefore",
					"Ctrl-Alt-Backspace": "delGroupAfter",
					"Alt-Delete": "delGroupAfter",
					"Cmd-S": "save",
					"Cmd-F": "find",
					"Cmd-G": "findNext",
					"Shift-Cmd-G": "findPrev",
					"Cmd-Alt-F": "replace",
					"Shift-Cmd-Alt-F": "replaceAll",
					"Cmd-[": "indentLess",
					"Cmd-]": "indentMore",
					"Cmd-Backspace": "delWrappedLineLeft",
					"Cmd-Delete": "delWrappedLineRight",
					"Cmd-U": "undoSelection",
					"Shift-Cmd-U": "redoSelection",
					"Ctrl-Up": "goDocStart",
					"Ctrl-Down": "goDocEnd",
					fallthrough: ["basic", "emacsy"]
				}, Ho.default = b ? Ho.macDefault : Ho.pcDefault;
				var Ko = {
					selectAll: to,
					singleSelection: function (e) {
						return e.setSelection(e.getCursor("anchor"), e.getCursor("head"), U)
					},
					killLine: function (n) {
						return $o(n, function (e) {
							if (e.empty()) {
								var t = se(n.doc, e.head.line).text.length;
								return e.head.ch == t && e.head.line < n.lastLine() ? {
									from: e.head,
									to: ge(e.head.line + 1, 0)
								} : {
									from: e.head,
									to: ge(e.head.line, t)
								}
							}
							return {
								from: e.from(),
								to: e.to()
							}
						})
					},
					deleteLine: function (t) {
						return $o(t, function (e) {
							return {
								from: ge(e.from().line, 0),
								to: Ce(t.doc, ge(e.to().line + 1, 0))
							}
						})
					},
					delLineLeft: function (e) {
						return $o(e, function (e) {
							return {
								from: ge(e.from().line, 0),
								to: e.from()
							}
						})
					},
					delWrappedLineLeft: function (n) {
						return $o(n, function (e) {
							var t = n.charCoords(e.head, "div").top + 5;
							return {
								from: n.coordsChar({
									left: 0,
									top: t
								}, "div"),
								to: e.from()
							}
						})
					},
					delWrappedLineRight: function (r) {
						return $o(r, function (e) {
							var t = r.charCoords(e.head, "div").top + 5,
								n = r.coordsChar({
									left: r.display.lineDiv.offsetWidth + 100,
									top: t
								}, "div");
							return {
								from: e.from(),
								to: n
							}
						})
					},
					undo: function (e) {
						return e.undo()
					},
					redo: function (e) {
						return e.redo()
					},
					undoSelection: function (e) {
						return e.undoSelection()
					},
					redoSelection: function (e) {
						return e.redoSelection()
					},
					goDocStart: function (e) {
						return e.extendSelection(ge(e.firstLine(), 0))
					},
					goDocEnd: function (e) {
						return e.extendSelection(ge(e.lastLine()))
					},
					goLineStart: function (t) {
						return t.extendSelectionsBy(function (e) {
							return Zo(t, e.head.line)
						}, {
							origin: "+move",
							bias: 1
						})
					},
					goLineStartSmart: function (t) {
						return t.extendSelectionsBy(function (e) {
							return Yo(t, e.head)
						}, {
							origin: "+move",
							bias: 1
						})
					},
					goLineEnd: function (t) {
						return t.extendSelectionsBy(function (e) {
							return function (e, t) {
								var n = se(e.doc, t),
									r = function (e) {
										for (var t; t = Pe(e);) e = t.find(1, !0).line;
										return e
									}(n);
								r != n && (t = fe(r));
								return Xo(!0, e, n, t, -1)
							}(t, e.head.line)
						}, {
							origin: "+move",
							bias: -1
						})
					},
					goLineRight: function (n) {
						return n.extendSelectionsBy(function (e) {
							var t = n.cursorCoords(e.head, "div").top + 5;
							return n.coordsChar({
								left: n.display.lineDiv.offsetWidth + 100,
								top: t
							}, "div")
						}, $)
					},
					goLineLeft: function (n) {
						return n.extendSelectionsBy(function (e) {
							var t = n.cursorCoords(e.head, "div").top + 5;
							return n.coordsChar({
								left: 0,
								top: t
							}, "div")
						}, $)
					},
					goLineLeftSmart: function (r) {
						return r.extendSelectionsBy(function (e) {
							var t = r.cursorCoords(e.head, "div").top + 5,
								n = r.coordsChar({
									left: 0,
									top: t
								}, "div");
							return n.ch < r.getLine(n.line).search(/\S/) ? Yo(r, e.head) : n
						}, $)
					},
					goLineUp: function (e) {
						return e.moveV(-1, "line")
					},
					goLineDown: function (e) {
						return e.moveV(1, "line")
					},
					goPageUp: function (e) {
						return e.moveV(-1, "page")
					},
					goPageDown: function (e) {
						return e.moveV(1, "page")
					},
					goCharLeft: function (e) {
						return e.moveH(-1, "char")
					},
					goCharRight: function (e) {
						return e.moveH(1, "char")
					},
					goColumnLeft: function (e) {
						return e.moveH(-1, "column")
					},
					goColumnRight: function (e) {
						return e.moveH(1, "column")
					},
					goWordLeft: function (e) {
						return e.moveH(-1, "word")
					},
					goGroupRight: function (e) {
						return e.moveH(1, "group")
					},
					goGroupLeft: function (e) {
						return e.moveH(-1, "group")
					},
					goWordRight: function (e) {
						return e.moveH(1, "word")
					},
					delCharBefore: function (e) {
						return e.deleteH(-1, "char")
					},
					delCharAfter: function (e) {
						return e.deleteH(1, "char")
					},
					delWordBefore: function (e) {
						return e.deleteH(-1, "word")
					},
					delWordAfter: function (e) {
						return e.deleteH(1, "word")
					},
					delGroupBefore: function (e) {
						return e.deleteH(-1, "group")
					},
					delGroupAfter: function (e) {
						return e.deleteH(1, "group")
					},
					indentAuto: function (e) {
						return e.indentSelection("smart")
					},
					indentMore: function (e) {
						return e.indentSelection("add")
					},
					indentLess: function (e) {
						return e.indentSelection("subtract")
					},
					insertTab: function (e) {
						return e.replaceSelection("\t")
					},
					insertSoftTab: function (e) {
						for (var t = [], n = e.listSelections(), r = e.options.tabSize, i = 0; i < n.length; i++) {
							var o = n[i].from(),
								a = z(e.getLine(o.line), o.ch, r);
							t.push(X(r - a % r))
						}
						e.replaceSelections(t)
					},
					defaultTab: function (e) {
						e.somethingSelected() ? e.indentSelection("add") : e.execCommand("insertTab")
					},
					transposeChars: function (a) {
						return Gr(a, function () {
							for (var e = a.listSelections(), t = [], n = 0; n < e.length; n++)
								if (e[n].empty()) {
									var r = e[n].head,
										i = se(a.doc, r.line).text;
									if (i)
										if (r.ch == i.length && (r = new ge(r.line, r.ch - 1)), 0 < r.ch) r = new ge(r.line, r.ch + 1), a.replaceRange(i.charAt(
											r.ch - 1) + i.charAt(r.ch - 2), ge(r.line, r.ch - 2), r, "+transpose");
										else if (r.line > a.doc.first) {
										var o = se(a.doc, r.line - 1).text;
										o && (r = new ge(r.line, 1), a.replaceRange(i.charAt(0) + a.doc.lineSeparator() + o.charAt(o.length - 1), ge(r.line - 1,
											o.length - 1), r, "+transpose"))
									}
									t.push(new vi(r, r))
								}
							a.setSelections(t)
						})
					},
					newlineAndIndent: function (r) {
						return Gr(r, function () {
							for (var e = r.listSelections(), t = e.length - 1; 0 <= t; t--) r.replaceRange(r.doc.lineSeparator(), e[t].anchor, e[t].head,
								"+input");
							e = r.listSelections();
							for (var n = 0; n < e.length; n++) r.indentLine(e[n].from().line, null, !0);
							Lr(r)
						})
					},
					openLine: function (e) {
						return e.replaceSelection("\n", "start")
					},
					toggleOverwrite: function (e) {
						return e.toggleOverwrite()
					}
				};

				function Zo(e, t) {
					var n = se(e.doc, t),
						r = je(n);
					return r != n && (t = fe(r)), Xo(!0, e, r, t, 1)
				}

				function Yo(e, t) {
					var n = Zo(e, t.line),
						r = se(e.doc, n.line),
						i = Qe(r, e.doc.direction);
					if (i && 0 != i[0].level) return n;
					var o = Math.max(0, r.text.search(/\S/)),
						a = t.line == n.line && t.ch <= o && t.ch;
					return ge(n.line, a ? 0 : o, n.sticky)
				}

				function Jo(e, t, n) {
					if ("string" == typeof t && !(t = Ko[t])) return !1;
					e.display.input.ensurePolled();
					var r = e.display.shift,
						i = !1;
					try {
						e.isReadOnly() && (e.state.suppressEdits = !0), n && (e.display.shift = !1), i = t(e) != j
					} finally {
						e.display.shift = r, e.state.suppressEdits = !1
					}
					return i
				}
				var Qo = new P;

				function ea(e, t, n, r) {
					var i = e.state.keySeq;
					if (i) {
						if (Wo(t)) return "handled";
						if (/\'$/.test(t) ? e.state.keySeq = null : Qo.set(50, function () {
								e.state.keySeq == i && (e.state.keySeq = null, e.display.input.reset())
							}), ta(e, i + " " + t, n, r)) return !0
					}
					return ta(e, t, n, r)
				}

				function ta(e, t, n, r) {
					var i = function (e, t, n) {
						for (var r = 0; r < e.state.keyMaps.length; r++) {
							var i = _o(t, e.state.keyMaps[r], n, e);
							if (i) return i
						}
						return e.options.extraKeys && _o(t, e.options.extraKeys, n, e) || _o(t, e.options.keyMap, n, e)
					}(e, t, r);
					return "multi" == i && (e.state.keySeq = t), "handled" == i && sn(e, "keyHandled", e, t, n), "handled" != i && "multi" != i || (
						ut(n), dr(e)), !!i
				}

				function na(t, e) {
					var n = Uo(e, !0);
					return !!n && (e.shiftKey && !t.state.keySeq ? ea(t, "Shift-" + n, e, function (e) {
						return Jo(t, e, !0)
					}) || ea(t, n, e, function (e) {
						if ("string" == typeof e ? /^go[A-Z]/.test(e) : e.motion) return Jo(t, e)
					}) : ea(t, n, e, function (e) {
						return Jo(t, e)
					}))
				}
				var ra = null;

				function ia(e) {
					if (this.curOp.focus = F(), !ot(this, e)) {
						w && k < 11 && 27 == e.keyCode && (e.returnValue = !1);
						var t = e.keyCode;
						this.display.shift = 16 == t || e.shiftKey;
						var n = na(this, e);
						g && (ra = n ? t : null, !n && 88 == t && !Ct && (b ? e.metaKey : e.ctrlKey) && this.replaceSelection("", null, "cut")), 18 !=
							t || /\bCodeMirror-crosshair\b/.test(this.display.lineDiv.className) || function (e) {
								var t = e.display.lineDiv;

								function n(e) {
									18 != e.keyCode && e.altKey || (T(t, "CodeMirror-crosshair"), rt(document, "keyup", n), rt(document, "mouseover", n))
								}
								O(t, "CodeMirror-crosshair"), tt(document, "keyup", n), tt(document, "mouseover", n)
							}(this)
					}
				}

				function oa(e) {
					16 == e.keyCode && (this.doc.sel.shift = !1), ot(this, e)
				}

				function aa(e) {
					if (!(wn(this.display, e) || ot(this, e) || e.ctrlKey && !e.altKey || b && e.metaKey)) {
						var t = e.keyCode,
							n = e.charCode;
						if (g && t == ra) return ra = null, void ut(e);
						if (!g || e.which && !(e.which < 10) || !na(this, e)) {
							var r, i = String.fromCharCode(null == n ? t : n);
							if ("\b" != i)
								if (!ea(r = this, "'" + i + "'", e, function (e) {
										return Jo(r, e, !0)
									})) this.display.input.onKeyPress(e)
						}
					}
				}
				var la, sa, ua = function (e, t, n) {
					this.time = e, this.pos = t, this.button = n
				};

				function ca(e) {
					var t = this,
						n = t.display;
					if (!(ot(t, e) || n.activeTouch && n.input.supportsTouch()))
						if (n.input.ensurePolled(), n.shift = e.shiftKey, wn(n, e)) x || (n.scroller.draggable = !1, setTimeout(function () {
							return n.scroller.draggable = !0
						}, 100));
						else if (!da(t, e)) {
						var r, i, o, a = ar(t, e),
							l = pt(e),
							s = a ? (r = a, i = l, o = +new Date, sa && sa.compare(o, r, i) ? (la = sa = null, "triple") : la && la.compare(o, r, i) ? (sa =
								new ua(o, r, i), la = null, "double") : (la = new ua(o, r, i), sa = null, "single")) : "single";
						window.focus(), 1 == l && t.state.selectingText && t.state.selectingText(e), a && function (n, e, r, t, i) {
							var o = "Click";
							"double" == t ? o = "Double" + o : "triple" == t && (o = "Triple" + o);
							return ea(n, jo(o = (1 == e ? "Left" : 2 == e ? "Middle" : "Right") + o, i), i, function (e) {
								if ("string" == typeof e && (e = Ko[e]), !e) return !1;
								var t = !1;
								try {
									n.isReadOnly() && (n.state.suppressEdits = !0), t = e(n, r) != j
								} finally {
									n.state.suppressEdits = !1
								}
								return t
							})
						}(t, l, a, s, e) || (1 == l ? a ? function (e, t, n, r) {
							w ? setTimeout(R(pr, e), 0) : e.curOp.focus = F();
							var i, o = function (e, t, n) {
									var r = e.getOption("configureMouse"),
										i = r ? r(e, t, n) : {};
									if (null == i.unit) {
										var o = d ? n.shiftKey && n.metaKey : n.altKey;
										i.unit = o ? "rectangle" : "single" == t ? "char" : "double" == t ? "word" : "line"
									}(null == i.extend || e.doc.extend) && (i.extend = e.doc.extend || n.shiftKey);
									null == i.addNew && (i.addNew = b ? n.metaKey : n.ctrlKey);
									null == i.moveOnDrag && (i.moveOnDrag = !(b ? n.altKey : n.ctrlKey));
									return i
								}(e, n, r),
								a = e.doc.sel;
							e.options.dragDrop && vt && !e.isReadOnly() && "single" == n && -1 < (i = a.contains(t)) && (ve((i = a.ranges[i]).from(), t) <
								0 || 0 < t.xRel) && (0 < ve(i.to(), t) || t.xRel < 0) ? function (t, n, r, i) {
								var o = t.display,
									a = !1,
									l = Vr(t, function (e) {
										x && (o.scroller.draggable = !1), t.state.draggingText = !1, rt(o.wrapper.ownerDocument, "mouseup", l), rt(o.wrapper.ownerDocument,
											"mousemove", s), rt(o.scroller, "dragstart", u), rt(o.scroller, "drop", l), a || (ut(e), i.addNew || ji(t.doc, r,
											null, null, i.extend), x || w && 9 == k ? setTimeout(function () {
											o.wrapper.ownerDocument.body.focus(), o.input.focus()
										}, 20) : o.input.focus())
									}),
									s = function (e) {
										a = a || 10 <= Math.abs(n.clientX - e.clientX) + Math.abs(n.clientY - e.clientY)
									},
									u = function () {
										return a = !0
									};
								x && (o.scroller.draggable = !0);
								(t.state.draggingText = l).copy = !i.moveOnDrag, o.scroller.dragDrop && o.scroller.dragDrop();
								tt(o.wrapper.ownerDocument, "mouseup", l), tt(o.wrapper.ownerDocument, "mousemove", s), tt(o.scroller, "dragstart", u), tt(
									o.scroller, "drop", l), mr(t), setTimeout(function () {
									return o.input.focus()
								}, 20)
							}(e, r, t, o) : function (g, e, v, y) {
								var a = g.display,
									x = g.doc;
								ut(e);
								var b, w, k = x.sel,
									t = k.ranges;
								y.addNew && !y.extend ? (w = x.sel.contains(v), b = -1 < w ? t[w] : new vi(v, v)) : (b = x.sel.primary(), w = x.sel.primIndex);
								if ("rectangle" == y.unit) y.addNew || (b = new vi(v, v)), v = ar(g, e, !0, !0), w = -1;
								else {
									var n = ha(g, v, y.unit);
									b = y.extend ? Wi(b, n.anchor, n.head, y.extend) : n
								}
								y.addNew ? -1 == w ? (w = t.length, Vi(x, yi(g, t.concat([b]), w), {
									scroll: !1,
									origin: "*mouse"
								})) : 1 < t.length && t[w].empty() && "char" == y.unit && !y.extend ? (Vi(x, yi(g, t.slice(0, w).concat(t.slice(w + 1)),
									0), {
									scroll: !1,
									origin: "*mouse"
								}), k = x.sel) : qi(x, w, b, q) : (Vi(x, new gi([b], w = 0), q), k = x.sel);
								var C = v;

								function l(e) {
									if (0 != ve(C, e))
										if (C = e, "rectangle" == y.unit) {
											for (var t = [], n = g.options.tabSize, r = z(se(x, v.line).text, v.ch, n), i = z(se(x, e.line).text, e.ch, n), o =
													Math.min(r, i), a = Math.max(r, i), l = Math.min(v.line, e.line), s = Math.min(g.lastLine(), Math.max(v.line, e.line)); l <=
												s; l++) {
												var u = se(x, l).text,
													c = G(u, o, n);
												o == a ? t.push(new vi(ge(l, c), ge(l, c))) : u.length > c && t.push(new vi(ge(l, c), ge(l, G(u, a, n))))
											}
											t.length || t.push(new vi(v, v)), Vi(x, yi(g, k.ranges.slice(0, w).concat(t), w), {
												origin: "*mouse",
												scroll: !1
											}), g.scrollIntoView(e)
										} else {
											var h, f = b,
												d = ha(g, e, y.unit),
												p = f.anchor;
											p = 0 < ve(d.anchor, p) ? (h = d.head, we(f.from(), d.anchor)) : (h = d.anchor, be(f.to(), d.head));
											var m = k.ranges.slice(0);
											m[w] = function (e, t) {
												var n = t.anchor,
													r = t.head,
													i = se(e.doc, n.line);
												if (0 == ve(n, r) && n.sticky == r.sticky) return t;
												var o = Qe(i);
												if (!o) return t;
												var a = Ye(o, n.ch, n.sticky),
													l = o[a];
												if (l.from != n.ch && l.to != n.ch) return t;
												var s, u = a + (l.from == n.ch == (1 != l.level) ? 0 : 1);
												if (0 == u || u == o.length) return t;
												if (r.line != n.line) s = 0 < (r.line - n.line) * ("ltr" == e.doc.direction ? 1 : -1);
												else {
													var c = Ye(o, r.ch, r.sticky),
														h = c - a || (r.ch - n.ch) * (1 == l.level ? -1 : 1);
													s = c == u - 1 || c == u ? h < 0 : 0 < h
												}
												var f = o[u + (s ? -1 : 0)],
													d = s == (1 == f.level),
													p = d ? f.from : f.to,
													m = d ? "after" : "before";
												return n.ch == p && n.sticky == m ? t : new vi(new ge(n.line, p, m), r)
											}(g, new vi(Ce(x, p), h)), Vi(x, yi(g, m, w), q)
										}
								}
								var s = a.wrapper.getBoundingClientRect(),
									u = 0;

								function r(e) {
									g.state.selectingText = !1, u = 1 / 0, ut(e), a.input.focus(), rt(a.wrapper.ownerDocument, "mousemove", i), rt(a.wrapper.ownerDocument,
										"mouseup", o), x.history.lastSelOrigin = null
								}
								var i = Vr(g, function (e) {
										0 !== e.buttons && pt(e) ? function e(t) {
											var n = ++u;
											var r = ar(g, t, !0, "rectangle" == y.unit);
											if (!r) return;
											if (0 != ve(r, C)) {
												g.curOp.focus = F(), l(r);
												var i = br(a, x);
												(r.line >= i.to || r.line < i.from) && setTimeout(Vr(g, function () {
													u == n && e(t)
												}), 150)
											} else {
												var o = t.clientY < s.top ? -20 : t.clientY > s.bottom ? 20 : 0;
												o && setTimeout(Vr(g, function () {
													u == n && (a.scroller.scrollTop += o, e(t))
												}), 50)
											}
										}(e) : r(e)
									}),
									o = Vr(g, r);
								g.state.selectingText = o, tt(a.wrapper.ownerDocument, "mousemove", i), tt(a.wrapper.ownerDocument, "mouseup", o)
							}(e, r, t, o)
						}(t, a, s, e) : dt(e) == n.scroller && ut(e) : 2 == l ? (a && ji(t.doc, a), setTimeout(function () {
							return n.input.focus()
						}, 20)) : 3 == l && (C ? t.display.input.onContextMenu(e) : mr(t)))
					}
				}

				function ha(e, t, n) {
					if ("char" == n) return new vi(t, t);
					if ("word" == n) return e.findWordAt(t);
					if ("line" == n) return new vi(ge(t.line, 0), Ce(e.doc, ge(t.line + 1, 0)));
					var r = n(e, t);
					return new vi(r.from, r.to)
				}

				function fa(e, t, n, r) {
					var i, o;
					if (t.touches) i = t.touches[0].clientX, o = t.touches[0].clientY;
					else try {
						i = t.clientX, o = t.clientY
					} catch (t) {
						return !1
					}
					if (i >= Math.floor(e.display.gutters.getBoundingClientRect().right)) return !1;
					r && ut(t);
					var a = e.display,
						l = a.lineDiv.getBoundingClientRect();
					if (o > l.bottom || !lt(e, n)) return ht(t);
					o -= l.top - a.viewOffset;
					for (var s = 0; s < e.options.gutters.length; ++s) {
						var u = a.gutters.childNodes[s];
						if (u && u.getBoundingClientRect().right >= i) return it(e, n, e, de(e.doc, o), e.options.gutters[s], t), ht(t)
					}
				}

				function da(e, t) {
					return fa(e, t, "gutterClick", !0)
				}

				function pa(e, t) {
					var n, r;
					wn(e.display, t) || (r = t, lt(n = e, "gutterContextMenu") && fa(n, r, "gutterContextMenu", !1)) || (ot(e, t, "contextmenu") ||
						C || e.display.input.onContextMenu(t))
				}

				function ma(e) {
					e.display.wrapper.className = e.display.wrapper.className.replace(/\s*cm-s-\S+/g, "") + e.options.theme.replace(/(^|\s)\s*/g,
						" cm-s-"), Pn(e)
				}
				ua.prototype.compare = function (e, t, n) {
					return this.time + 400 > e && 0 == ve(t, this.pos) && n == this.button
				};
				var ga = {
						toString: function () {
							return "CodeMirror.Init"
						}
					},
					va = {},
					ya = {};

				function xa(e) {
					ui(e), Zr(e), wr(e)
				}

				function ba(e, t, n) {
					if (!t != !(n && n != ga)) {
						var r = e.display.dragFunctions,
							i = t ? tt : rt;
						i(e.display.scroller, "dragstart", r.start), i(e.display.scroller, "dragenter", r.enter), i(e.display.scroller, "dragover", r.over),
							i(e.display.scroller, "dragleave", r.leave), i(e.display.scroller, "drop", r.drop)
					}
				}

				function wa(e) {
					e.options.lineWrapping ? (O(e.display.wrapper, "CodeMirror-wrap"), e.display.sizer.style.minWidth = "", e.display.sizerWidth =
						null) : (T(e.display.wrapper, "CodeMirror-wrap"), Ke(e)), or(e), Zr(e), Pn(e), setTimeout(function () {
						return Br(e)
					}, 100)
				}

				function ka(e, t) {
					var n = this;
					if (!(this instanceof ka)) return new ka(e, t);
					this.options = t = t ? H(t) : {}, H(va, t, !1), ci(t);
					var r = t.value;
					"string" == typeof r ? r = new Lo(r, t.mode, null, t.lineSeparator, t.direction) : t.mode && (r.modeOption = t.mode), this.doc =
						r;
					var i = new ka.inputStyles[t.inputStyle](this),
						o = this.display = new le(e, r, i);
					for (var a in ui(o.wrapper.CodeMirror = this), ma(this), t.lineWrapping && (this.display.wrapper.className += " CodeMirror-wrap"),
							zr(this), this.state = {
								keyMaps: [],
								overlays: [],
								modeGen: 0,
								overwrite: !1,
								delayingBlurEvent: !1,
								focused: !1,
								suppressEdits: !1,
								pasteIncoming: -1,
								cutIncoming: -1,
								selectingText: !1,
								draggingText: !1,
								highlight: new P,
								keySeq: null,
								specialChars: null
							}, t.autofocus && !f && o.input.focus(), w && k < 11 && setTimeout(function () {
								return n.display.input.reset(!0)
							}, 20),
							function (i) {
								var o = i.display;
								tt(o.scroller, "mousedown", Vr(i, ca)), tt(o.scroller, "dblclick", w && k < 11 ? Vr(i, function (e) {
									if (!ot(i, e)) {
										var t = ar(i, e);
										if (t && !da(i, e) && !wn(i.display, e)) {
											ut(e);
											var n = i.findWordAt(t);
											ji(i.doc, n.anchor, n.head)
										}
									}
								}) : function (e) {
									return ot(i, e) || ut(e)
								});
								tt(o.scroller, "contextmenu", function (e) {
									return pa(i, e)
								});
								var n, r = {
									end: 0
								};

								function a() {
									o.activeTouch && (n = setTimeout(function () {
										return o.activeTouch = null
									}, 1e3), (r = o.activeTouch).end = +new Date)
								}

								function l(e, t) {
									if (null == t.left) return !0;
									var n = t.left - e.left,
										r = t.top - e.top;
									return 400 < n * n + r * r
								}
								tt(o.scroller, "touchstart", function (e) {
									if (!ot(i, e) && ! function (e) {
											if (1 != e.touches.length) return !1;
											var t = e.touches[0];
											return t.radiusX <= 1 && t.radiusY <= 1
										}(e) && !da(i, e)) {
										o.input.ensurePolled(), clearTimeout(n);
										var t = +new Date;
										o.activeTouch = {
											start: t,
											moved: !1,
											prev: t - r.end <= 300 ? r : null
										}, 1 == e.touches.length && (o.activeTouch.left = e.touches[0].pageX, o.activeTouch.top = e.touches[0].pageY)
									}
								}), tt(o.scroller, "touchmove", function () {
									o.activeTouch && (o.activeTouch.moved = !0)
								}), tt(o.scroller, "touchend", function (e) {
									var t = o.activeTouch;
									if (t && !wn(o, e) && null != t.left && !t.moved && new Date - t.start < 300) {
										var n, r = i.coordsChar(o.activeTouch, "page");
										n = !t.prev || l(t, t.prev) ? new vi(r, r) : !t.prev.prev || l(t, t.prev.prev) ? i.findWordAt(r) : new vi(ge(r.line, 0),
											Ce(i.doc, ge(r.line + 1, 0))), i.setSelection(n.anchor, n.head), i.focus(), ut(e)
									}
									a()
								}), tt(o.scroller, "touchcancel", a), tt(o.scroller, "scroll", function () {
									o.scroller.clientHeight && (Er(i, o.scroller.scrollTop), Dr(i, o.scroller.scrollLeft, !0), it(i, "scroll", i))
								}), tt(o.scroller, "mousewheel", function (e) {
									return mi(i, e)
								}), tt(o.scroller, "DOMMouseScroll", function (e) {
									return mi(i, e)
								}), tt(o.wrapper, "scroll", function () {
									return o.wrapper.scrollTop = o.wrapper.scrollLeft = 0
								}), o.dragFunctions = {
									enter: function (e) {
										ot(i, e) || ft(e)
									},
									over: function (e) {
										ot(i, e) || (! function (e, t) {
											var n = ar(e, t);
											if (n) {
												var r = document.createDocumentFragment();
												cr(e, n, r), e.display.dragCursor || (e.display.dragCursor = N("div", null,
														"CodeMirror-cursors CodeMirror-dragcursors"), e.display.lineSpace.insertBefore(e.display.dragCursor, e.display.cursorDiv)),
													A(e.display.dragCursor, r)
											}
										}(i, e), ft(e))
									},
									start: function (e) {
										return function (e, t) {
											if (w && (!e.state.draggingText || +new Date - To < 100)) ft(t);
											else if (!ot(e, t) && !wn(e.display, t) && (t.dataTransfer.setData("Text", e.getSelection()), t.dataTransfer.effectAllowed =
													"copyMove", t.dataTransfer.setDragImage && !s)) {
												var n = N("img", null, null, "position: fixed; left: 0; top: 0;");
												n.src = "data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==", g && (n.width = n.height = 1, e.display
													.wrapper.appendChild(n), n._top = n.offsetTop), t.dataTransfer.setDragImage(n, 0, 0), g && n.parentNode.removeChild(
													n)
											}
										}(i, e)
									},
									drop: Vr(i, Mo),
									leave: function (e) {
										ot(i, e) || Ao(i)
									}
								};
								var e = o.input.getField();
								tt(e, "keyup", function (e) {
									return oa.call(i, e)
								}), tt(e, "keydown", Vr(i, ia)), tt(e, "keypress", Vr(i, aa)), tt(e, "focus", function (e) {
									return gr(i, e)
								}), tt(e, "blur", function (e) {
									return vr(i, e)
								})
							}(this), Do(), _r(this), this.curOp.forceUpdate = !0, Ei(this, r), t.autofocus && !f || this.hasFocus() ? setTimeout(R(gr,
								this), 20) : vr(this), ya) ya.hasOwnProperty(a) && ya[a](n, t[a], ga);
					kr(this), t.finishInit && t.finishInit(this);
					for (var l = 0; l < Ca.length; ++l) Ca[l](n);
					Wr(this), x && t.lineWrapping && "optimizelegibility" == getComputedStyle(o.lineDiv).textRendering && (o.lineDiv.style.textRendering =
						"auto")
				}
				ka.defaults = va, ka.optionHandlers = ya;
				var Ca = [];

				function Sa(e, t, n, r) {
					var i, o = e.doc;
					null == n && (n = "add"), "smart" == n && (o.mode.indent ? i = Pt(e, t).state : n = "prev");
					var a = e.options.tabSize,
						l = se(o, t),
						s = z(l.text, null, a);
					l.stateAfter && (l.stateAfter = null);
					var u, c = l.text.match(/^\s*/)[0];
					if (r || /\S/.test(l.text)) {
						if ("smart" == n && ((u = o.mode.indent(i, l.text.slice(c.length), l.text)) == j || 150 < u)) {
							if (!r) return;
							n = "prev"
						}
					} else u = 0, n = "not";
					"prev" == n ? u = t > o.first ? z(se(o, t - 1).text, null, a) : 0 : "add" == n ? u = s + e.options.indentUnit : "subtract" == n ?
						u = s - e.options.indentUnit : "number" == typeof n && (u = s + n), u = Math.max(0, u);
					var h = "",
						f = 0;
					if (e.options.indentWithTabs)
						for (var d = Math.floor(u / a); d; --d) f += a, h += "\t";
					if (f < u && (h += X(u - f)), h != c) return so(o, h, ge(t, 0), ge(t, c.length), "+input"), !(l.stateAfter = null);
					for (var p = 0; p < o.sel.ranges.length; p++) {
						var m = o.sel.ranges[p];
						if (m.head.line == t && m.head.ch < c.length) {
							var g = ge(t, c.length);
							qi(o, p, new vi(g, g));
							break
						}
					}
				}
				ka.defineInitHook = function (e) {
					return Ca.push(e)
				};
				var La = null;

				function Ta(e) {
					La = e
				}

				function Ma(e, t, n, r, i) {
					var o = e.doc;
					e.display.shift = !1, r || (r = o.sel);
					var a = +new Date - 200,
						l = "paste" == i || e.state.pasteIncoming > a,
						s = wt(t),
						u = null;
					if (l && 1 < r.ranges.length)
						if (La && La.text.join("\n") == t) {
							if (r.ranges.length % La.text.length == 0) {
								u = [];
								for (var c = 0; c < La.text.length; c++) u.push(o.splitLines(La.text[c]))
							}
						} else s.length == r.ranges.length && e.options.pasteLinesPerSelection && (u = Z(s, function (e) {
							return [e]
						}));
					for (var h = e.curOp.updateInput, f = r.ranges.length - 1; 0 <= f; f--) {
						var d = r.ranges[f],
							p = d.from(),
							m = d.to();
						d.empty() && (n && 0 < n ? p = ge(p.line, p.ch - n) : e.state.overwrite && !l ? m = ge(m.line, Math.min(se(o, m.line).text.length,
							m.ch + K(s).length)) : l && La && La.lineWise && La.text.join("\n") == t && (p = m = ge(p.line, 0)));
						var g = {
							from: p,
							to: m,
							text: u ? u[f % u.length] : s,
							origin: i || (l ? "paste" : e.state.cutIncoming > a ? "cut" : "+input")
						};
						ro(e.doc, g), sn(e, "inputRead", e, g)
					}
					t && !l && Ea(e, t), Lr(e), e.curOp.updateInput < 2 && (e.curOp.updateInput = h), e.curOp.typing = !0, e.state.pasteIncoming = e
						.state.cutIncoming = -1
				}

				function Aa(e, t) {
					var n = e.clipboardData && e.clipboardData.getData("Text");
					if (n) return e.preventDefault(), t.isReadOnly() || t.options.disableInput || Gr(t, function () {
						return Ma(t, n, 0, null, "paste")
					}), !0
				}

				function Ea(e, t) {
					if (e.options.electricChars && e.options.smartIndent)
						for (var n = e.doc.sel, r = n.ranges.length - 1; 0 <= r; r--) {
							var i = n.ranges[r];
							if (!(100 < i.head.ch || r && n.ranges[r - 1].head.line == i.head.line)) {
								var o = e.getModeAt(i.head),
									a = !1;
								if (o.electricChars) {
									for (var l = 0; l < o.electricChars.length; l++)
										if (-1 < t.indexOf(o.electricChars.charAt(l))) {
											a = Sa(e, i.head.line, "smart");
											break
										}
								} else o.electricInput && o.electricInput.test(se(e.doc, i.head.line).text.slice(0, i.head.ch)) && (a = Sa(e, i.head.line,
									"smart"));
								a && sn(e, "electricInput", e, i.head.line)
							}
						}
				}

				function Na(e) {
					for (var t = [], n = [], r = 0; r < e.doc.sel.ranges.length; r++) {
						var i = e.doc.sel.ranges[r].head.line,
							o = {
								anchor: ge(i, 0),
								head: ge(i + 1, 0)
							};
						n.push(o), t.push(e.getRange(o.anchor, o.head))
					}
					return {
						text: t,
						ranges: n
					}
				}

				function Da(e, t, n, r) {
					e.setAttribute("autocorrect", !!n), e.setAttribute("autocapitalize", !!r), e.setAttribute("spellcheck", !!t)
				}

				function Fa() {
					var e = N("textarea", null, null, "position: absolute; bottom: -1em; padding: 0; width: 1px; height: 1em; outline: none"),
						t = N("div", [e], null, "overflow: hidden; position: relative; width: 3px; height: 0px;");
					return x ? e.style.width = "1000px" : e.setAttribute("wrap", "off"), c && (e.style.border = "1px solid black"), Da(e), t
				}

				function Oa(r, i, o, e, a) {
					var t = i,
						n = o,
						l = se(r, i.line);

					function s(e) {
						var t, n;
						if (null == (t = a ? function (t, n, l, e) {
								var s = Qe(n, t.doc.direction);
								if (!s) return Vo(n, l, e);
								l.ch >= n.text.length ? (l.ch = n.text.length, l.sticky = "before") : l.ch <= 0 && (l.ch = 0, l.sticky = "after");
								var r = Ye(s, l.ch, l.sticky),
									i = s[r];
								if ("ltr" == t.doc.direction && i.level % 2 == 0 && (0 < e ? i.to > l.ch : i.from < l.ch)) return Vo(n, l, e);
								var o, u = function (e, t) {
										return Go(n, e instanceof ge ? e.ch : e, t)
									},
									a = function (e) {
										return t.options.lineWrapping ? (o = o || Dn(t, n), Yn(t, n, o, e)) : {
											begin: 0,
											end: n.text.length
										}
									},
									c = a("before" == l.sticky ? u(l, -1) : l.ch);
								if ("rtl" == t.doc.direction || 1 == i.level) {
									var h = 1 == i.level == e < 0,
										f = u(l, h ? 1 : -1);
									if (null != f && (h ? f <= i.to && f <= c.end : f >= i.from && f >= c.begin)) {
										var d = h ? "before" : "after";
										return new ge(l.line, f, d)
									}
								}
								var p = function (e, t, n) {
										for (var r = function (e, t) {
												return t ? new ge(l.line, u(e, 1), "before") : new ge(l.line, e, "after")
											}; 0 <= e && e < s.length; e += t) {
											var i = s[e],
												o = 0 < t == (1 != i.level),
												a = o ? n.begin : u(n.end, -1);
											if (i.from <= a && a < i.to) return r(a, o);
											if (a = o ? i.from : u(i.to, -1), n.begin <= a && a < n.end) return r(a, o)
										}
									},
									m = p(r + e, e, c);
								if (m) return m;
								var g = 0 < e ? c.end : u(c.begin, -1);
								return null == g || 0 < e && g == n.text.length || !(m = p(0 < e ? 0 : s.length - 1, e, a(g))) ? null : m
							}(r.cm, l, i, o) : Vo(l, i, o))) {
							if (e || (n = i.line + o) < r.first || n >= r.first + r.size || (i = new ge(n, i.ch, i.sticky), !(l = se(r, n)))) return !1;
							i = Xo(a, r.cm, l, i.line, o)
						} else i = t;
						return !0
					}
					if ("char" == e) s();
					else if ("column" == e) s(!0);
					else if ("word" == e || "group" == e)
						for (var u = null, c = "group" == e, h = r.cm && r.cm.getHelper(i, "wordChars"), f = !0; !(o < 0) || s(!f); f = !1) {
							var d = l.text.charAt(i.ch) || "\n",
								p = te(d, h) ? "w" : c && "\n" == d ? "n" : !c || /\s/.test(d) ? null : "p";
							if (!c || f || p || (p = "s"), u && u != p) {
								o < 0 && (o = 1, s(), i.sticky = "after");
								break
							}
							if (p && (u = p), 0 < o && !s(!f)) break
						}
					var m = Qi(r, i, t, n, !0);
					return ye(t, m) && (m.hitSide = !0), m
				}

				function Ia(e, t, n, r) {
					var i, o, a = e.doc,
						l = t.left;
					if ("page" == r) {
						var s = Math.min(e.display.wrapper.clientHeight, window.innerHeight || document.documentElement.clientHeight),
							u = Math.max(s - .5 * er(e.display), 3);
						i = (0 < n ? t.bottom : t.top) + n * u
					} else "line" == r && (i = 0 < n ? t.bottom + 3 : t.top - 3);
					for (;
						(o = Kn(e, l, i)).outside;) {
						if (n < 0 ? i <= 0 : i >= a.height) {
							o.hitSide = !0;
							break
						}
						i += 5 * n
					}
					return o
				}
				var Ba = function (e) {
					this.cm = e, this.lastAnchorNode = this.lastAnchorOffset = this.lastFocusNode = this.lastFocusOffset = null, this.polling = new P,
						this.composing = null, this.gracePeriod = !1, this.readDOMTimeout = null
				};

				function Ra(e, t) {
					var n = Nn(e, t.line);
					if (!n || n.hidden) return null;
					var r = se(e.doc, t.line),
						i = An(n, r, t.line),
						o = Qe(r, e.doc.direction),
						a = "left";
					o && (a = Ye(o, t.ch) % 2 ? "right" : "left");
					var l = Bn(i.map, t.ch, a);
					return l.offset = "right" == l.collapse ? l.end : l.start, l
				}

				function Ha(e, t) {
					return t && (e.bad = !0), e
				}

				function za(e, t, n) {
					var r;
					if (t == e.display.lineDiv) {
						if (!(r = e.display.lineDiv.childNodes[n])) return Ha(e.clipPos(ge(e.display.viewTo - 1)), !0);
						t = null, n = 0
					} else
						for (r = t;; r = r.parentNode) {
							if (!r || r == e.display.lineDiv) return null;
							if (r.parentNode && r.parentNode == e.display.lineDiv) break
						}
					for (var i = 0; i < e.display.view.length; i++) {
						var o = e.display.view[i];
						if (o.node == r) return Pa(o, t, n)
					}
				}

				function Pa(u, e, t) {
					var n = u.text.firstChild,
						r = !1;
					if (!e || !D(n, e)) return Ha(ge(fe(u.line), 0), !0);
					if (e == n && (r = !0, e = n.childNodes[t], t = 0, !e)) {
						var i = u.rest ? K(u.rest) : u.line;
						return Ha(ge(fe(i), i.text.length), r)
					}
					var o = 3 == e.nodeType ? e : null,
						a = e;
					for (o || 1 != e.childNodes.length || 3 != e.firstChild.nodeType || (o = e.firstChild, t && (t = o.nodeValue.length)); a.parentNode !=
						n;) a = a.parentNode;
					var c = u.measure,
						h = c.maps;

					function l(e, t, n) {
						for (var r = -1; r < (h ? h.length : 0); r++)
							for (var i = r < 0 ? c.map : h[r], o = 0; o < i.length; o += 3) {
								var a = i[o + 2];
								if (a == e || a == t) {
									var l = fe(r < 0 ? u.line : u.rest[r]),
										s = i[o] + n;
									return (n < 0 || a != e) && (s = i[o + (n ? 1 : 0)]), ge(l, s)
								}
							}
					}
					var s = l(o, a, t);
					if (s) return Ha(s, r);
					for (var f = a.nextSibling, d = o ? o.nodeValue.length - t : 0; f; f = f.nextSibling) {
						if (s = l(f, f.firstChild, 0)) return Ha(ge(s.line, s.ch - d), r);
						d += f.textContent.length
					}
					for (var p = a.previousSibling, m = t; p; p = p.previousSibling) {
						if (s = l(p, p.firstChild, -1)) return Ha(ge(s.line, s.ch + m), r);
						m += p.textContent.length
					}
				}
				Ba.prototype.init = function (e) {
						var t = this,
							a = this,
							l = a.cm,
							s = a.div = e.lineDiv;

						function n(e) {
							if (!ot(l, e)) {
								if (l.somethingSelected()) Ta({
									lineWise: !1,
									text: l.getSelections()
								}), "cut" == e.type && l.replaceSelection("", null, "cut");
								else {
									if (!l.options.lineWiseCopyCut) return;
									var t = Na(l);
									Ta({
										lineWise: !0,
										text: t.text
									}), "cut" == e.type && l.operation(function () {
										l.setSelections(t.ranges, 0, U), l.replaceSelection("", null, "cut")
									})
								}
								if (e.clipboardData) {
									e.clipboardData.clearData();
									var n = La.text.join("\n");
									if (e.clipboardData.setData("Text", n), e.clipboardData.getData("Text") == n) return void e.preventDefault()
								}
								var r = Fa(),
									i = r.firstChild;
								l.display.lineSpace.insertBefore(r, l.display.lineSpace.firstChild), i.value = La.text.join("\n");
								var o = document.activeElement;
								B(i), setTimeout(function () {
									l.display.lineSpace.removeChild(r), o.focus(), o == s && a.showPrimarySelection()
								}, 50)
							}
						}
						Da(s, l.options.spellcheck, l.options.autocorrect, l.options.autocapitalize), tt(s, "paste", function (e) {
							ot(l, e) || Aa(e, l) || k <= 11 && setTimeout(Vr(l, function () {
								return t.updateFromDOM()
							}), 20)
						}), tt(s, "compositionstart", function (e) {
							t.composing = {
								data: e.data,
								done: !1
							}
						}), tt(s, "compositionupdate", function (e) {
							t.composing || (t.composing = {
								data: e.data,
								done: !1
							})
						}), tt(s, "compositionend", function (e) {
							t.composing && (e.data != t.composing.data && t.readFromDOMSoon(), t.composing.done = !0)
						}), tt(s, "touchstart", function () {
							return a.forceCompositionEnd()
						}), tt(s, "input", function () {
							t.composing || t.readFromDOMSoon()
						}), tt(s, "copy", n), tt(s, "cut", n)
					}, Ba.prototype.prepareSelection = function () {
						var e = ur(this.cm, !1);
						return e.focus = this.cm.state.focused, e
					}, Ba.prototype.showSelection = function (e, t) {
						e && this.cm.display.view.length && ((e.focus || t) && this.showPrimarySelection(), this.showMultipleSelections(e))
					}, Ba.prototype.getSelection = function () {
						return this.cm.display.wrapper.ownerDocument.getSelection()
					}, Ba.prototype.showPrimarySelection = function () {
						var e = this.getSelection(),
							t = this.cm,
							n = t.doc.sel.primary(),
							r = n.from(),
							i = n.to();
						if (t.display.viewTo == t.display.viewFrom || r.line >= t.display.viewTo || i.line < t.display.viewFrom) e.removeAllRanges();
						else {
							var o = za(t, e.anchorNode, e.anchorOffset),
								a = za(t, e.focusNode, e.focusOffset);
							if (!o || o.bad || !a || a.bad || 0 != ve(we(o, a), r) || 0 != ve(be(o, a), i)) {
								var l = t.display.view,
									s = r.line >= t.display.viewFrom && Ra(t, r) || {
										node: l[0].measure.map[2],
										offset: 0
									},
									u = i.line < t.display.viewTo && Ra(t, i);
								if (!u) {
									var c = l[l.length - 1].measure,
										h = c.maps ? c.maps[c.maps.length - 1] : c.map;
									u = {
										node: h[h.length - 1],
										offset: h[h.length - 2] - h[h.length - 3]
									}
								}
								if (s && u) {
									var f, d = e.rangeCount && e.getRangeAt(0);
									try {
										f = L(s.node, s.offset, u.offset, u.node)
									} catch (e) {}
									f && (!m && t.state.focused ? (e.collapse(s.node, s.offset), f.collapsed || (e.removeAllRanges(), e.addRange(f))) : (e.removeAllRanges(),
										e.addRange(f)), d && null == e.anchorNode ? e.addRange(d) : m && this.startGracePeriod()), this.rememberSelection()
								} else e.removeAllRanges()
							}
						}
					}, Ba.prototype.startGracePeriod = function () {
						var e = this;
						clearTimeout(this.gracePeriod), this.gracePeriod = setTimeout(function () {
							e.gracePeriod = !1, e.selectionChanged() && e.cm.operation(function () {
								return e.cm.curOp.selectionChanged = !0
							})
						}, 20)
					}, Ba.prototype.showMultipleSelections = function (e) {
						A(this.cm.display.cursorDiv, e.cursors), A(this.cm.display.selectionDiv, e.selection)
					}, Ba.prototype.rememberSelection = function () {
						var e = this.getSelection();
						this.lastAnchorNode = e.anchorNode, this.lastAnchorOffset = e.anchorOffset, this.lastFocusNode = e.focusNode, this.lastFocusOffset =
							e.focusOffset
					}, Ba.prototype.selectionInEditor = function () {
						var e = this.getSelection();
						if (!e.rangeCount) return !1;
						var t = e.getRangeAt(0).commonAncestorContainer;
						return D(this.div, t)
					}, Ba.prototype.focus = function () {
						"nocursor" != this.cm.options.readOnly && (this.selectionInEditor() || this.showSelection(this.prepareSelection(), !0), this.div
							.focus())
					}, Ba.prototype.blur = function () {
						this.div.blur()
					}, Ba.prototype.getField = function () {
						return this.div
					}, Ba.prototype.supportsTouch = function () {
						return !0
					}, Ba.prototype.receivedFocus = function () {
						var t = this;
						this.selectionInEditor() ? this.pollSelection() : Gr(this.cm, function () {
							return t.cm.curOp.selectionChanged = !0
						}), this.polling.set(this.cm.options.pollInterval, function e() {
							t.cm.state.focused && (t.pollSelection(), t.polling.set(t.cm.options.pollInterval, e))
						})
					}, Ba.prototype.selectionChanged = function () {
						var e = this.getSelection();
						return e.anchorNode != this.lastAnchorNode || e.anchorOffset != this.lastAnchorOffset || e.focusNode != this.lastFocusNode || e
							.focusOffset != this.lastFocusOffset
					}, Ba.prototype.pollSelection = function () {
						if (null == this.readDOMTimeout && !this.gracePeriod && this.selectionChanged()) {
							var e = this.getSelection(),
								t = this.cm;
							if (h && a && this.cm.options.gutters.length && function (e) {
									for (var t = e; t; t = t.parentNode)
										if (/CodeMirror-gutter-wrapper/.test(t.className)) return !0;
									return !1
								}(e.anchorNode)) return this.cm.triggerOnKeyDown({
								type: "keydown",
								keyCode: 8,
								preventDefault: Math.abs
							}), this.blur(), void this.focus();
							if (!this.composing) {
								this.rememberSelection();
								var n = za(t, e.anchorNode, e.anchorOffset),
									r = za(t, e.focusNode, e.focusOffset);
								n && r && Gr(t, function () {
									Vi(t.doc, xi(n, r), U), (n.bad || r.bad) && (t.curOp.selectionChanged = !0)
								})
							}
						}
					}, Ba.prototype.pollContent = function () {
						null != this.readDOMTimeout && (clearTimeout(this.readDOMTimeout), this.readDOMTimeout = null);
						var e, t, n, r = this.cm,
							i = r.display,
							o = r.doc.sel.primary(),
							a = o.from(),
							l = o.to();
						if (0 == a.ch && a.line > r.firstLine() && (a = ge(a.line - 1, se(r.doc, a.line - 1).length)), l.ch == se(r.doc, l.line).text.length &&
							l.line < r.lastLine() && (l = ge(l.line + 1, 0)), a.line < i.viewFrom || l.line > i.viewTo - 1) return !1;
						n = a.line == i.viewFrom || 0 == (e = lr(r, a.line)) ? (t = fe(i.view[0].line), i.view[0].node) : (t = fe(i.view[e].line), i.view[
							e - 1].node.nextSibling);
						var s, u, c = lr(r, l.line);
						if (u = c == i.view.length - 1 ? (s = i.viewTo - 1, i.lineDiv.lastChild) : (s = fe(i.view[c + 1].line) - 1, i.view[c + 1].node.previousSibling), !
							n) return !1;
						for (var h = r.doc.splitLines(function (s, e, t, u, c) {
								var n = "",
									h = !1,
									f = s.doc.lineSeparator(),
									d = !1;

								function p() {
									h && (n += f, d && (n += f), h = d = !1)
								}

								function m(e) {
									e && (p(), n += e)
								}

								function g(e) {
									if (1 == e.nodeType) {
										var t = e.getAttribute("cm-text");
										if (t) return void m(t);
										var n, r = e.getAttribute("cm-marker");
										if (r) {
											var i = s.findMarks(ge(u, 0), ge(c + 1, 0), (l = +r, function (e) {
												return e.id == l
											}));
											return void(i.length && (n = i[0].find(0)) && m(ue(s.doc, n.from, n.to).join(f)))
										}
										if ("false" == e.getAttribute("contenteditable")) return;
										var o = /^(pre|div|p|li|table|br)$/i.test(e.nodeName);
										if (!/^br$/i.test(e.nodeName) && 0 == e.textContent.length) return;
										o && p();
										for (var a = 0; a < e.childNodes.length; a++) g(e.childNodes[a]);
										/^(pre|p)$/i.test(e.nodeName) && (d = !0), o && (h = !0)
									} else 3 == e.nodeType && m(e.nodeValue.replace(/\u200b/g, "").replace(/\u00a0/g, " "));
									var l
								}
								for (; g(e), e != t;) e = e.nextSibling, d = !1;
								return n
							}(r, n, u, t, s)), f = ue(r.doc, ge(t, 0), ge(s, se(r.doc, s).text.length)); 1 < h.length && 1 < f.length;)
							if (K(h) == K(f)) h.pop(), f.pop(), s--;
							else {
								if (h[0] != f[0]) break;
								h.shift(), f.shift(), t++
							}
						for (var d = 0, p = 0, m = h[0], g = f[0], v = Math.min(m.length, g.length); d < v && m.charCodeAt(d) == g.charCodeAt(d);) ++d;
						for (var y = K(h), x = K(f), b = Math.min(y.length - (1 == h.length ? d : 0), x.length - (1 == f.length ? d : 0)); p < b && y.charCodeAt(
								y.length - p - 1) == x.charCodeAt(x.length - p - 1);) ++p;
						if (1 == h.length && 1 == f.length && t == a.line)
							for (; d && d > a.ch && y.charCodeAt(y.length - p - 1) == x.charCodeAt(x.length - p - 1);) d--, p++;
						h[h.length - 1] = y.slice(0, y.length - p).replace(/^\u200b+/, ""), h[0] = h[0].slice(d).replace(/\u200b+$/, "");
						var w = ge(t, d),
							k = ge(s, f.length ? K(f).length - p : 0);
						return 1 < h.length || h[0] || ve(w, k) ? (so(r.doc, h, w, k, "+input"), !0) : void 0
					}, Ba.prototype.ensurePolled = function () {
						this.forceCompositionEnd()
					}, Ba.prototype.reset = function () {
						this.forceCompositionEnd()
					}, Ba.prototype.forceCompositionEnd = function () {
						this.composing && (clearTimeout(this.readDOMTimeout), this.composing = null, this.updateFromDOM(), this.div.blur(), this.div.focus())
					}, Ba.prototype.readFromDOMSoon = function () {
						var e = this;
						null == this.readDOMTimeout && (this.readDOMTimeout = setTimeout(function () {
							if (e.readDOMTimeout = null, e.composing) {
								if (!e.composing.done) return;
								e.composing = null
							}
							e.updateFromDOM()
						}, 80))
					}, Ba.prototype.updateFromDOM = function () {
						var e = this;
						!this.cm.isReadOnly() && this.pollContent() || Gr(this.cm, function () {
							return Zr(e.cm)
						})
					}, Ba.prototype.setUneditable = function (e) {
						e.contentEditable = "false"
					}, Ba.prototype.onKeyPress = function (e) {
						0 == e.charCode || this.composing || (e.preventDefault(), this.cm.isReadOnly() || Vr(this.cm, Ma)(this.cm, String.fromCharCode(
							null == e.charCode ? e.keyCode : e.charCode), 0))
					}, Ba.prototype.readOnlyChanged = function (e) {
						this.div.contentEditable = String("nocursor" != e)
					}, Ba.prototype.onContextMenu = function () {}, Ba.prototype.resetPosition = function () {}, Ba.prototype.needsContentAttribute = !
					0;
				var _a, Wa, ja, Ua = function (e) {
					this.cm = e, this.prevInput = "", this.pollingFast = !1, this.polling = new P, this.hasSelection = !1, this.composing = null
				};
				Ua.prototype.init = function (n) {
						var e = this,
							r = this,
							i = this.cm;
						this.createField(n);
						var o = this.textarea;

						function t(e) {
							if (!ot(i, e)) {
								if (i.somethingSelected()) Ta({
									lineWise: !1,
									text: i.getSelections()
								});
								else {
									if (!i.options.lineWiseCopyCut) return;
									var t = Na(i);
									Ta({
										lineWise: !0,
										text: t.text
									}), "cut" == e.type ? i.setSelections(t.ranges, null, U) : (r.prevInput = "", o.value = t.text.join("\n"), B(o))
								}
								"cut" == e.type && (i.state.cutIncoming = +new Date)
							}
						}
						n.wrapper.insertBefore(this.wrapper, n.wrapper.firstChild), c && (o.style.width = "0px"), tt(o, "input", function () {
							w && 9 <= k && e.hasSelection && (e.hasSelection = null), r.poll()
						}), tt(o, "paste", function (e) {
							ot(i, e) || Aa(e, i) || (i.state.pasteIncoming = +new Date, r.fastPoll())
						}), tt(o, "cut", t), tt(o, "copy", t), tt(n.scroller, "paste", function (e) {
							if (!wn(n, e) && !ot(i, e)) {
								if (!o.dispatchEvent) return i.state.pasteIncoming = +new Date, void r.focus();
								var t = new Event("paste");
								t.clipboardData = e.clipboardData, o.dispatchEvent(t)
							}
						}), tt(n.lineSpace, "selectstart", function (e) {
							wn(n, e) || ut(e)
						}), tt(o, "compositionstart", function () {
							var e = i.getCursor("from");
							r.composing && r.composing.range.clear(), r.composing = {
								start: e,
								range: i.markText(e, i.getCursor("to"), {
									className: "CodeMirror-composing"
								})
							}
						}), tt(o, "compositionend", function () {
							r.composing && (r.poll(), r.composing.range.clear(), r.composing = null)
						})
					}, Ua.prototype.createField = function (e) {
						this.wrapper = Fa(), this.textarea = this.wrapper.firstChild
					}, Ua.prototype.prepareSelection = function () {
						var e = this.cm,
							t = e.display,
							n = e.doc,
							r = ur(e);
						if (e.options.moveInputWithCursor) {
							var i = Gn(e, n.sel.primary().head, "div"),
								o = t.wrapper.getBoundingClientRect(),
								a = t.lineDiv.getBoundingClientRect();
							r.teTop = Math.max(0, Math.min(t.wrapper.clientHeight - 10, i.top + a.top - o.top)), r.teLeft = Math.max(0, Math.min(t.wrapper
								.clientWidth - 10, i.left + a.left - o.left))
						}
						return r
					}, Ua.prototype.showSelection = function (e) {
						var t = this.cm.display;
						A(t.cursorDiv, e.cursors), A(t.selectionDiv, e.selection), null != e.teTop && (this.wrapper.style.top = e.teTop + "px", this.wrapper
							.style.left = e.teLeft + "px")
					}, Ua.prototype.reset = function (e) {
						if (!this.contextMenuPending && !this.composing) {
							var t = this.cm;
							if (t.somethingSelected()) {
								this.prevInput = "";
								var n = t.getSelection();
								this.textarea.value = n, t.state.focused && B(this.textarea), w && 9 <= k && (this.hasSelection = n)
							} else e || (this.prevInput = this.textarea.value = "", w && 9 <= k && (this.hasSelection = null))
						}
					}, Ua.prototype.getField = function () {
						return this.textarea
					}, Ua.prototype.supportsTouch = function () {
						return !1
					}, Ua.prototype.focus = function () {
						if ("nocursor" != this.cm.options.readOnly && (!f || F() != this.textarea)) try {
							this.textarea.focus()
						} catch (e) {}
					}, Ua.prototype.blur = function () {
						this.textarea.blur()
					}, Ua.prototype.resetPosition = function () {
						this.wrapper.style.top = this.wrapper.style.left = 0
					}, Ua.prototype.receivedFocus = function () {
						this.slowPoll()
					}, Ua.prototype.slowPoll = function () {
						var e = this;
						this.pollingFast || this.polling.set(this.cm.options.pollInterval, function () {
							e.poll(), e.cm.state.focused && e.slowPoll()
						})
					}, Ua.prototype.fastPoll = function () {
						var t = !1,
							n = this;
						n.pollingFast = !0, n.polling.set(20, function e() {
							n.poll() || t ? (n.pollingFast = !1, n.slowPoll()) : (t = !0, n.polling.set(60, e))
						})
					}, Ua.prototype.poll = function () {
						var e = this,
							t = this.cm,
							n = this.textarea,
							r = this.prevInput;
						if (this.contextMenuPending || !t.state.focused || kt(n) && !r && !this.composing || t.isReadOnly() || t.options.disableInput ||
							t.state.keySeq) return !1;
						var i = n.value;
						if (i == r && !t.somethingSelected()) return !1;
						if (w && 9 <= k && this.hasSelection === i || b && /[\uf700-\uf7ff]/.test(i)) return t.display.input.reset(), !1;
						if (t.doc.sel == t.display.selForContextMenu) {
							var o = i.charCodeAt(0);
							if (8203 != o || r || (r = "​"), 8666 == o) return this.reset(), this.cm.execCommand("undo")
						}
						for (var a = 0, l = Math.min(r.length, i.length); a < l && r.charCodeAt(a) == i.charCodeAt(a);) ++a;
						return Gr(t, function () {
							Ma(t, i.slice(a), r.length - a, null, e.composing ? "*compose" : null), 1e3 < i.length || -1 < i.indexOf("\n") ? n.value = e
								.prevInput = "" : e.prevInput = i, e.composing && (e.composing.range.clear(), e.composing.range = t.markText(e.composing.start,
									t.getCursor("to"), {
										className: "CodeMirror-composing"
									}))
						}), !0
					}, Ua.prototype.ensurePolled = function () {
						this.pollingFast && this.poll() && (this.pollingFast = !1)
					}, Ua.prototype.onKeyPress = function () {
						w && 9 <= k && (this.hasSelection = null), this.fastPoll()
					}, Ua.prototype.onContextMenu = function (e) {
						var n = this,
							r = n.cm,
							i = r.display,
							o = n.textarea;
						n.contextMenuPending && n.contextMenuPending();
						var t = ar(r, e),
							a = i.scroller.scrollTop;
						if (t && !g) {
							r.options.resetSelectionOnContextMenu && -1 == r.doc.sel.contains(t) && Vr(r, Vi)(r.doc, xi(t), U);
							var l, s = o.style.cssText,
								u = n.wrapper.style.cssText,
								c = n.wrapper.offsetParent.getBoundingClientRect();
							if (n.wrapper.style.cssText = "position: static", o.style.cssText =
								"position: absolute; width: 30px; height: 30px;\n      top: " + (e.clientY - c.top - 5) + "px; left: " + (e.clientX - c.left -
									5) + "px;\n      z-index: 1000; background: " + (w ? "rgba(255, 255, 255, .05)" : "transparent") +
								";\n      outline: none; border-width: 0; outline: none; overflow: hidden; opacity: .05; filter: alpha(opacity=5);", x && (l =
									window.scrollY), i.input.focus(), x && window.scrollTo(null, l), i.input.reset(), r.somethingSelected() || (o.value = n.prevInput =
									" "), n.contextMenuPending = d, i.selForContextMenu = r.doc.sel, clearTimeout(i.detectingSelectAll), w && 9 <= k && f(), C) {
								ft(e);
								var h = function () {
									rt(window, "mouseup", h), setTimeout(d, 20)
								};
								tt(window, "mouseup", h)
							} else setTimeout(d, 50)
						}

						function f() {
							if (null != o.selectionStart) {
								var e = r.somethingSelected(),
									t = "​" + (e ? o.value : "");
								o.value = "⇚", o.value = t, n.prevInput = e ? "" : "​", o.selectionStart = 1, o.selectionEnd = t.length, i.selForContextMenu =
									r.doc.sel
							}
						}

						function d() {
							if (n.contextMenuPending == d && (n.contextMenuPending = !1, n.wrapper.style.cssText = u, o.style.cssText = s, w && k < 9 && i
									.scrollbars.setScrollTop(i.scroller.scrollTop = a), null != o.selectionStart)) {
								(!w || w && k < 9) && f();
								var e = 0,
									t = function () {
										i.selForContextMenu == r.doc.sel && 0 == o.selectionStart && 0 < o.selectionEnd && "​" == n.prevInput ? Vr(r, to)(r) : e++ <
											10 ? i.detectingSelectAll = setTimeout(t, 500) : (i.selForContextMenu = null, i.input.reset())
									};
								i.detectingSelectAll = setTimeout(t, 200)
							}
						}
					}, Ua.prototype.readOnlyChanged = function (e) {
						e || this.reset(), this.textarea.disabled = "nocursor" == e
					}, Ua.prototype.setUneditable = function () {}, Ua.prototype.needsContentAttribute = !1,
					function (i) {
						var o = i.optionHandlers;

						function e(e, t, r, n) {
							i.defaults[e] = t, r && (o[e] = n ? function (e, t, n) {
								n != ga && r(e, t, n)
							} : r)
						}
						i.defineOption = e, i.Init = ga, e("value", "", function (e, t) {
							return e.setValue(t)
						}, !0), e("mode", null, function (e, t) {
							e.doc.modeOption = t, Si(e)
						}, !0), e("indentUnit", 2, Si, !0), e("indentWithTabs", !1), e("smartIndent", !0), e("tabSize", 4, function (e) {
							Li(e), Pn(e), Zr(e)
						}, !0), e("lineSeparator", null, function (e, r) {
							if (e.doc.lineSep = r) {
								var i = [],
									o = e.doc.first;
								e.doc.iter(function (e) {
									for (var t = 0;;) {
										var n = e.text.indexOf(r, t);
										if (-1 == n) break;
										t = n + r.length, i.push(ge(o, n))
									}
									o++
								});
								for (var t = i.length - 1; 0 <= t; t--) so(e.doc, r, i[t], ge(i[t].line, i[t].ch + r.length))
							}
						}), e("specialChars", /[\u0000-\u001f\u007f-\u009f\u00ad\u061c\u200b-\u200f\u2028\u2029\ufeff]/g, function (e, t, n) {
							e.state.specialChars = new RegExp(t.source + (t.test("\t") ? "" : "|\t"), "g"), n != ga && e.refresh()
						}), e("specialCharPlaceholder", Jt, function (e) {
							return e.refresh()
						}, !0), e("electricChars", !0), e("inputStyle", f ? "contenteditable" : "textarea", function () {
							throw new Error("inputStyle can not (yet) be changed in a running editor")
						}, !0), e("spellcheck", !1, function (e, t) {
							return e.getInputField().spellcheck = t
						}, !0), e("autocorrect", !1, function (e, t) {
							return e.getInputField().autocorrect = t
						}, !0), e("autocapitalize", !1, function (e, t) {
							return e.getInputField().autocapitalize = t
						}, !0), e("rtlMoveVisually", !p), e("wholeLineUpdateBefore", !0), e("theme", "default", function (e) {
							ma(e), xa(e)
						}, !0), e("keyMap", "default", function (e, t, n) {
							var r = qo(t),
								i = n != ga && qo(n);
							i && i.detach && i.detach(e, r), r.attach && r.attach(e, i || null)
						}), e("extraKeys", null), e("configureMouse", null), e("lineWrapping", !1, wa, !0), e("gutters", [], function (e) {
							ci(e.options), xa(e)
						}, !0), e("fixedGutter", !0, function (e, t) {
							e.display.gutters.style.left = t ? rr(e.display) + "px" : "0", e.refresh()
						}, !0), e("coverGutterNextToScrollbar", !1, function (e) {
							return Br(e)
						}, !0), e("scrollbarStyle", "native", function (e) {
							zr(e), Br(e), e.display.scrollbars.setScrollTop(e.doc.scrollTop), e.display.scrollbars.setScrollLeft(e.doc.scrollLeft)
						}, !0), e("lineNumbers", !1, function (e) {
							ci(e.options), xa(e)
						}, !0), e("firstLineNumber", 1, xa, !0), e("lineNumberFormatter", function (e) {
							return e
						}, xa, !0), e("showCursorWhenSelecting", !1, sr, !0), e("resetSelectionOnContextMenu", !0), e("lineWiseCopyCut", !0), e(
							"pasteLinesPerSelection", !0), e("selectionsMayTouch", !1), e("readOnly", !1, function (e, t) {
							"nocursor" == t && (vr(e), e.display.input.blur()), e.display.input.readOnlyChanged(t)
						}), e("disableInput", !1, function (e, t) {
							t || e.display.input.reset()
						}, !0), e("dragDrop", !0, ba), e("allowDropFileTypes", null), e("cursorBlinkRate", 530), e("cursorScrollMargin", 0), e(
							"cursorHeight", 1, sr, !0), e("singleCursorHeightPerLine", !0, sr, !0), e("workTime", 100), e("workDelay", 100), e(
							"flattenSpans", !0, Li, !0), e("addModeClass", !1, Li, !0), e("pollInterval", 100), e("undoDepth", 200, function (e, t) {
							return e.doc.history.undoDepth = t
						}), e("historyEventDelay", 1250), e("viewportMargin", 10, function (e) {
							return e.refresh()
						}, !0), e("maxHighlightLength", 1e4, Li, !0), e("moveInputWithCursor", !0, function (e, t) {
							t || e.display.input.resetPosition()
						}), e("tabindex", null, function (e, t) {
							return e.display.input.getField().tabIndex = t || ""
						}), e("autofocus", null), e("direction", "ltr", function (e, t) {
							return e.doc.setDirection(t)
						}, !0), e("phrases", null)
					}(ka), Wa = (_a = ka).optionHandlers, ja = _a.helpers = {}, _a.prototype = {
						constructor: _a,
						focus: function () {
							window.focus(), this.display.input.focus()
						},
						setOption: function (e, t) {
							var n = this.options,
								r = n[e];
							n[e] == t && "mode" != e || (n[e] = t, Wa.hasOwnProperty(e) && Vr(this, Wa[e])(this, t, r), it(this, "optionChange", this, e))
						},
						getOption: function (e) {
							return this.options[e]
						},
						getDoc: function () {
							return this.doc
						},
						addKeyMap: function (e, t) {
							this.state.keyMaps[t ? "push" : "unshift"](qo(e))
						},
						removeKeyMap: function (e) {
							for (var t = this.state.keyMaps, n = 0; n < t.length; ++n)
								if (t[n] == e || t[n].name == e) return t.splice(n, 1), !0
						},
						addOverlay: Xr(function (e, t) {
							var n = e.token ? e : _a.getMode(this.options, e);
							if (n.startState) throw new Error("Overlays may not be stateful.");
							! function (e, t, n) {
								for (var r = 0, i = n(t); r < e.length && n(e[r]) <= i;) r++;
								e.splice(r, 0, t)
							}(this.state.overlays, {
								mode: n,
								modeSpec: e,
								opaque: t && t.opaque,
								priority: t && t.priority || 0
							}, function (e) {
								return e.priority
							}), this.state.modeGen++, Zr(this)
						}),
						removeOverlay: Xr(function (e) {
							for (var t = this.state.overlays, n = 0; n < t.length; ++n) {
								var r = t[n].modeSpec;
								if (r == e || "string" == typeof e && r.name == e) return t.splice(n, 1), this.state.modeGen++, void Zr(this)
							}
						}),
						indentLine: Xr(function (e, t, n) {
							"string" != typeof t && "number" != typeof t && (t = null == t ? this.options.smartIndent ? "smart" : "prev" : t ? "add" :
								"subtract"), pe(this.doc, e) && Sa(this, e, t, n)
						}),
						indentSelection: Xr(function (e) {
							for (var t = this.doc.sel.ranges, n = -1, r = 0; r < t.length; r++) {
								var i = t[r];
								if (i.empty()) i.head.line > n && (Sa(this, i.head.line, e, !0), n = i.head.line, r == this.doc.sel.primIndex && Lr(this));
								else {
									var o = i.from(),
										a = i.to(),
										l = Math.max(n, o.line);
									n = Math.min(this.lastLine(), a.line - (a.ch ? 0 : 1)) + 1;
									for (var s = l; s < n; ++s) Sa(this, s, e);
									var u = this.doc.sel.ranges;
									0 == o.ch && t.length == u.length && 0 < u[r].from().ch && qi(this.doc, r, new vi(o, u[r].to()), U)
								}
							}
						}),
						getTokenAt: function (e, t) {
							return qt(this, e, t)
						},
						getLineTokens: function (e, t) {
							return qt(this, ge(e), t, !0)
						},
						getTokenTypeAt: function (e) {
							e = Ce(this.doc, e);
							var t, n = zt(this, se(this.doc, e.line)),
								r = 0,
								i = (n.length - 1) / 2,
								o = e.ch;
							if (0 == o) t = n[2];
							else
								for (;;) {
									var a = r + i >> 1;
									if ((a ? n[2 * a - 1] : 0) >= o) i = a;
									else {
										if (!(n[2 * a + 1] < o)) {
											t = n[2 * a + 2];
											break
										}
										r = a + 1
									}
								}
							var l = t ? t.indexOf("overlay ") : -1;
							return l < 0 ? t : 0 == l ? null : t.slice(0, l - 1)
						},
						getModeAt: function (e) {
							var t = this.doc.mode;
							return t.innerMode ? _a.innerMode(t, this.getTokenAt(e).state).mode : t
						},
						getHelper: function (e, t) {
							return this.getHelpers(e, t)[0]
						},
						getHelpers: function (e, t) {
							var n = [];
							if (!ja.hasOwnProperty(t)) return n;
							var r = ja[t],
								i = this.getModeAt(e);
							if ("string" == typeof i[t]) r[i[t]] && n.push(r[i[t]]);
							else if (i[t])
								for (var o = 0; o < i[t].length; o++) {
									var a = r[i[t][o]];
									a && n.push(a)
								} else i.helperType && r[i.helperType] ? n.push(r[i.helperType]) : r[i.name] && n.push(r[i.name]);
							for (var l = 0; l < r._global.length; l++) {
								var s = r._global[l];
								s.pred(i, this) && -1 == _(n, s.val) && n.push(s.val)
							}
							return n
						},
						getStateAfter: function (e, t) {
							var n = this.doc;
							return Pt(this, (e = ke(n, null == e ? n.first + n.size - 1 : e)) + 1, t).state
						},
						cursorCoords: function (e, t) {
							var n = this.doc.sel.primary();
							return Gn(this, null == e ? n.head : "object" == typeof e ? Ce(this.doc, e) : e ? n.from() : n.to(), t || "page")
						},
						charCoords: function (e, t) {
							return $n(this, Ce(this.doc, e), t || "page")
						},
						coordsChar: function (e, t) {
							return Kn(this, (e = qn(this, e, t || "page")).left, e.top)
						},
						lineAtHeight: function (e, t) {
							return e = qn(this, {
								top: e,
								left: 0
							}, t || "page").top, de(this.doc, e + this.display.viewOffset)
						},
						heightAtLine: function (e, t, n) {
							var r, i = !1;
							if ("number" == typeof e) {
								var o = this.doc.first + this.doc.size - 1;
								e < this.doc.first ? e = this.doc.first : o < e && (e = o, i = !0), r = se(this.doc, e)
							} else r = e;
							return Un(this, r, {
								top: 0,
								left: 0
							}, t || "page", n || i).top + (i ? this.doc.height - Ve(r) : 0)
						},
						defaultTextHeight: function () {
							return er(this.display)
						},
						defaultCharWidth: function () {
							return tr(this.display)
						},
						getViewport: function () {
							return {
								from: this.display.viewFrom,
								to: this.display.viewTo
							}
						},
						addWidget: function (e, t, n, r, i) {
							var o, a, l, s = this.display,
								u = (e = Gn(this, Ce(this.doc, e))).bottom,
								c = e.left;
							if (t.style.position = "absolute", t.setAttribute("cm-ignore-events", "true"), this.display.input.setUneditable(t), s.sizer.appendChild(
									t), "over" == r) u = e.top;
							else if ("above" == r || "near" == r) {
								var h = Math.max(s.wrapper.clientHeight, this.doc.height),
									f = Math.max(s.sizer.clientWidth, s.lineSpace.clientWidth);
								("above" == r || e.bottom + t.offsetHeight > h) && e.top > t.offsetHeight ? u = e.top - t.offsetHeight : e.bottom + t.offsetHeight <=
									h && (u = e.bottom), c + t.offsetWidth > f && (c = f - t.offsetWidth)
							}
							t.style.top = u + "px", t.style.left = t.style.right = "", "right" == i ? (c = s.sizer.clientWidth - t.offsetWidth, t.style.right =
									"0px") : ("left" == i ? c = 0 : "middle" == i && (c = (s.sizer.clientWidth - t.offsetWidth) / 2), t.style.left = c + "px"),
								n && (o = this, a = {
									left: c,
									top: u,
									right: c + t.offsetWidth,
									bottom: u + t.offsetHeight
								}, null != (l = Cr(o, a)).scrollTop && Er(o, l.scrollTop), null != l.scrollLeft && Dr(o, l.scrollLeft))
						},
						triggerOnKeyDown: Xr(ia),
						triggerOnKeyPress: Xr(aa),
						triggerOnKeyUp: oa,
						triggerOnMouseDown: Xr(ca),
						execCommand: function (e) {
							if (Ko.hasOwnProperty(e)) return Ko[e].call(null, this)
						},
						triggerElectric: Xr(function (e) {
							Ea(this, e)
						}),
						findPosH: function (e, t, n, r) {
							var i = 1;
							t < 0 && (i = -1, t = -t);
							for (var o = Ce(this.doc, e), a = 0; a < t && !(o = Oa(this.doc, o, i, n, r)).hitSide; ++a);
							return o
						},
						moveH: Xr(function (t, n) {
							var r = this;
							this.extendSelectionsBy(function (e) {
								return r.display.shift || r.doc.extend || e.empty() ? Oa(r.doc, e.head, t, n, r.options.rtlMoveVisually) : t < 0 ? e.from() :
									e.to()
							}, $)
						}),
						deleteH: Xr(function (n, r) {
							var e = this.doc.sel,
								i = this.doc;
							e.somethingSelected() ? i.replaceSelection("", null, "+delete") : $o(this, function (e) {
								var t = Oa(i, e.head, n, r, !1);
								return n < 0 ? {
									from: t,
									to: e.head
								} : {
									from: e.head,
									to: t
								}
							})
						}),
						findPosV: function (e, t, n, r) {
							var i = 1,
								o = r;
							t < 0 && (i = -1, t = -t);
							for (var a = Ce(this.doc, e), l = 0; l < t; ++l) {
								var s = Gn(this, a, "div");
								if (null == o ? o = s.left : s.left = o, (a = Ia(this, s, i, n)).hitSide) break
							}
							return a
						},
						moveV: Xr(function (r, i) {
							var o = this,
								a = this.doc,
								l = [],
								s = !this.display.shift && !a.extend && a.sel.somethingSelected();
							if (a.extendSelectionsBy(function (e) {
									if (s) return r < 0 ? e.from() : e.to();
									var t = Gn(o, e.head, "div");
									null != e.goalColumn && (t.left = e.goalColumn), l.push(t.left);
									var n = Ia(o, t, r, i);
									return "page" == i && e == a.sel.primary() && Sr(o, $n(o, n, "div").top - t.top), n
								}, $), l.length)
								for (var e = 0; e < a.sel.ranges.length; e++) a.sel.ranges[e].goalColumn = l[e]
						}),
						findWordAt: function (e) {
							var t = se(this.doc, e.line).text,
								n = e.ch,
								r = e.ch;
							if (t) {
								var i = this.getHelper(e, "wordChars");
								"before" != e.sticky && r != t.length || !n ? ++r : --n;
								for (var o = t.charAt(n), a = te(o, i) ? function (e) {
										return te(e, i)
									} : /\s/.test(o) ? function (e) {
										return /\s/.test(e)
									} : function (e) {
										return !/\s/.test(e) && !te(e)
									}; 0 < n && a(t.charAt(n - 1));) --n;
								for (; r < t.length && a(t.charAt(r));) ++r
							}
							return new vi(ge(e.line, n), ge(e.line, r))
						},
						toggleOverwrite: function (e) {
							null != e && e == this.state.overwrite || ((this.state.overwrite = !this.state.overwrite) ? O(this.display.cursorDiv,
								"CodeMirror-overwrite") : T(this.display.cursorDiv, "CodeMirror-overwrite"), it(this, "overwriteToggle", this, this.state.overwrite))
						},
						hasFocus: function () {
							return this.display.input.getField() == F()
						},
						isReadOnly: function () {
							return !(!this.options.readOnly && !this.doc.cantEdit)
						},
						scrollTo: Xr(function (e, t) {
							Tr(this, e, t)
						}),
						getScrollInfo: function () {
							var e = this.display.scroller;
							return {
								left: e.scrollLeft,
								top: e.scrollTop,
								height: e.scrollHeight - Ln(this) - this.display.barHeight,
								width: e.scrollWidth - Ln(this) - this.display.barWidth,
								clientHeight: Mn(this),
								clientWidth: Tn(this)
							}
						},
						scrollIntoView: Xr(function (e, t) {
							var n, r;
							null == e ? (e = {
								from: this.doc.sel.primary().head,
								to: null
							}, null == t && (t = this.options.cursorScrollMargin)) : "number" == typeof e ? e = {
								from: ge(e, 0),
								to: null
							} : null == e.from && (e = {
								from: e,
								to: null
							}), e.to || (e.to = e.from), e.margin = t || 0, null != e.from.line ? (r = e, Mr(n = this), n.curOp.scrollToPos = r) : Ar(
								this, e.from, e.to, e.margin)
						}),
						setSize: Xr(function (e, t) {
							var n = this,
								r = function (e) {
									return "number" == typeof e || /^\d+$/.test(String(e)) ? e + "px" : e
								};
							null != e && (this.display.wrapper.style.width = r(e)), null != t && (this.display.wrapper.style.height = r(t)), this.options
								.lineWrapping && zn(this);
							var i = this.display.viewFrom;
							this.doc.iter(i, this.display.viewTo, function (e) {
								if (e.widgets)
									for (var t = 0; t < e.widgets.length; t++)
										if (e.widgets[t].noHScroll) {
											Yr(n, i, "widget");
											break
										}++i
							}), this.curOp.forceUpdate = !0, it(this, "refresh", this)
						}),
						operation: function (e) {
							return Gr(this, e)
						},
						startOperation: function () {
							return _r(this)
						},
						endOperation: function () {
							return Wr(this)
						},
						refresh: Xr(function () {
							var e = this.display.cachedTextHeight;
							Zr(this), this.curOp.forceUpdate = !0, Pn(this), Tr(this, this.doc.scrollLeft, this.doc.scrollTop), li(this), (null == e ||
								.5 < Math.abs(e - er(this.display))) && or(this), it(this, "refresh", this)
						}),
						swapDoc: Xr(function (e) {
							var t = this.doc;
							return t.cm = null, Ei(this, e), Pn(this), this.display.input.reset(), Tr(this, e.scrollLeft, e.scrollTop), this.curOp.forceScroll = !
								0, sn(this, "swapDoc", this, t), t
						}),
						phrase: function (e) {
							var t = this.options.phrases;
							return t && Object.prototype.hasOwnProperty.call(t, e) ? t[e] : e
						},
						getInputField: function () {
							return this.display.input.getField()
						},
						getWrapperElement: function () {
							return this.display.wrapper
						},
						getScrollerElement: function () {
							return this.display.scroller
						},
						getGutterElement: function () {
							return this.display.gutters
						}
					}, st(_a), _a.registerHelper = function (e, t, n) {
						ja.hasOwnProperty(e) || (ja[e] = _a[e] = {
							_global: []
						}), ja[e][t] = n
					}, _a.registerGlobalHelper = function (e, t, n, r) {
						_a.registerHelper(e, t, r), ja[e]._global.push({
							pred: n,
							val: r
						})
					};
				var qa, $a = "iter insert remove copy getEditor constructor".split(" ");
				for (var Ga in Lo.prototype) Lo.prototype.hasOwnProperty(Ga) && _($a, Ga) < 0 && (ka.prototype[Ga] = function (e) {
					return function () {
						return e.apply(this.doc, arguments)
					}
				}(Lo.prototype[Ga]));
				return st(Lo), ka.inputStyles = {
						textarea: Ua,
						contenteditable: Ba
					}, ka.defineMode = function (e) {
						ka.defaults.mode || "null" == e || (ka.defaults.mode = e),
							function (e, t) {
								2 < arguments.length && (t.dependencies = Array.prototype.slice.call(arguments, 2)), Lt[e] = t
							}.apply(this, arguments)
					}, ka.defineMIME = function (e, t) {
						Tt[e] = t
					}, ka.defineMode("null", function () {
						return {
							token: function (e) {
								return e.skipToEnd()
							}
						}
					}), ka.defineMIME("text/plain", "null"), ka.defineExtension = function (e, t) {
						ka.prototype[e] = t
					}, ka.defineDocExtension = function (e, t) {
						Lo.prototype[e] = t
					}, ka.fromTextArea = function (t, e) {
						if ((e = e ? H(e) : {}).value = t.value, !e.tabindex && t.tabIndex && (e.tabindex = t.tabIndex), !e.placeholder && t.placeholder &&
							(e.placeholder = t.placeholder), null == e.autofocus) {
							var n = F();
							e.autofocus = n == t || null != t.getAttribute("autofocus") && n == document.body
						}

						function r() {
							t.value = l.getValue()
						}
						var i;
						if (t.form && (tt(t.form, "submit", r), !e.leaveSubmitMethodAlone)) {
							var o = t.form;
							i = o.submit;
							try {
								var a = o.submit = function () {
									r(), o.submit = i, o.submit(), o.submit = a
								}
							} catch (e) {}
						}
						e.finishInit = function (e) {
							e.save = r, e.getTextArea = function () {
								return t
							}, e.toTextArea = function () {
								e.toTextArea = isNaN, r(), t.parentNode.removeChild(e.getWrapperElement()), t.style.display = "", t.form && (rt(t.form,
									"submit", r), "function" == typeof t.form.submit && (t.form.submit = i))
							}
						}, t.style.display = "none";
						var l = ka(function (e) {
							return t.parentNode.insertBefore(e, t.nextSibling)
						}, e);
						return l
					}, (qa = ka).off = rt, qa.on = tt, qa.wheelEventPixels = pi, qa.Doc = Lo, qa.splitLines = wt, qa.countColumn = z, qa.findColumn =
					G, qa.isWordChar = ee, qa.Pass = j, qa.signal = it, qa.Line = Vt, qa.changeEnd = bi, qa.scrollbarModel = Hr, qa.Pos = ge, qa.cmpPos =
					ve, qa.modes = Lt, qa.mimeModes = Tt, qa.resolveMode = Mt, qa.getMode = At, qa.modeExtensions = Et, qa.extendMode = Nt, qa.copyState =
					Dt, qa.startState = Ot, qa.innerMode = Ft, qa.commands = Ko, qa.keyMap = Ho, qa.keyName = Uo, qa.isModifierKey = Wo, qa.lookupKey =
					_o, qa.normalizeKeyMap = Po, qa.StringStream = It, qa.SharedTextMarker = wo, qa.TextMarker = xo, qa.LineWidget = go, qa.e_preventDefault =
					ut, qa.e_stopPropagation = ct, qa.e_stop = ft, qa.addClass = O, qa.contains = D, qa.rmClass = T, qa.keyNames = Oo, ka.version =
					"5.44.0", ka
			}, "object" == typeof n && void 0 !== t ? t.exports = i() : r.CodeMirror = i()
		}, {}],
		12: [function (e, t, n) {
			var r;
			r = function (a) {
				"use strict";
				var l =
					/^((?:(?:aaas?|about|acap|adiumxtra|af[ps]|aim|apt|attachment|aw|beshare|bitcoin|bolo|callto|cap|chrome(?:-extension)?|cid|coap|com-eventbrite-attendee|content|crid|cvs|data|dav|dict|dlna-(?:playcontainer|playsingle)|dns|doi|dtn|dvb|ed2k|facetime|feed|file|finger|fish|ftp|geo|gg|git|gizmoproject|go|gopher|gtalk|h323|hcp|https?|iax|icap|icon|im|imap|info|ipn|ipp|irc[6s]?|iris(?:\.beep|\.lwz|\.xpc|\.xpcs)?|itms|jar|javascript|jms|keyparc|lastfm|ldaps?|magnet|mailto|maps|market|message|mid|mms|ms-help|msnim|msrps?|mtqp|mumble|mupdate|mvn|news|nfs|nih?|nntp|notes|oid|opaquelocktoken|palm|paparazzi|platform|pop|pres|proxy|psyc|query|res(?:ource)?|rmi|rsync|rtmp|rtsp|secondlife|service|session|sftp|sgn|shttp|sieve|sips?|skype|sm[bs]|snmp|soap\.beeps?|soldat|spotify|ssh|steam|svn|tag|teamspeak|tel(?:net)?|tftp|things|thismessage|tip|tn3270|tv|udp|unreal|urn|ut2004|vemmi|ventrilo|view-source|webcal|wss?|wtai|wyciwyg|xcon(?:-userid)?|xfire|xmlrpc\.beeps?|xmpp|xri|ymsgr|z39\.50[rs]?):(?:\/{1,3}|[a-z0-9%])|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}\/)(?:[^\s()<>]|\([^\s()<>]*\))+(?:\([^\s()<>]*\)|[^\s`*!()\[\]{};:'".,<>?«»“”‘’]))/i;
				a.defineMode("gfm", function (e, i) {
					var o = 0;
					var t = {
							startState: function () {
								return {
									code: !1,
									codeBlock: !1,
									ateSpace: !1
								}
							},
							copyState: function (e) {
								return {
									code: e.code,
									codeBlock: e.codeBlock,
									ateSpace: e.ateSpace
								}
							},
							token: function (e, t) {
								if (t.combineTokens = null, t.codeBlock) return e.match(/^```+/) ? t.codeBlock = !1 : e.skipToEnd(), null;
								if (e.sol() && (t.code = !1), e.sol() && e.match(/^```+/)) return e.skipToEnd(), t.codeBlock = !0, null;
								if ("`" === e.peek()) {
									e.next();
									var n = e.pos;
									e.eatWhile("`");
									var r = 1 + e.pos - n;
									return t.code ? r === o && (t.code = !1) : (o = r, t.code = !0), null
								}
								if (t.code) return e.next(), null;
								if (e.eatSpace()) return t.ateSpace = !0, null;
								if ((e.sol() || t.ateSpace) && (t.ateSpace = !1) !== i.gitHubSpice) {
									if (e.match(/^(?:[a-zA-Z0-9\-_]+\/)?(?:[a-zA-Z0-9\-_]+@)?(?=.{0,6}\d)(?:[a-f0-9]{7,40}\b)/)) return t.combineTokens = !0,
										"link";
									if (e.match(/^(?:[a-zA-Z0-9\-_]+\/)?(?:[a-zA-Z0-9\-_]+)?#[0-9]+\b/)) return t.combineTokens = !0, "link"
								}
								return e.match(l) && "](" != e.string.slice(e.start - 2, e.start) && (0 == e.start || /\W/.test(e.string.charAt(e.start -
									1))) ? (t.combineTokens = !0, "link") : (e.next(), null)
							},
							blankLine: function (e) {
								return e.code = !1, null
							}
						},
						n = {
							taskLists: !0,
							strikethrough: !0,
							emoji: !0
						};
					for (var r in i) n[r] = i[r];
					return n.name = "markdown", a.overlayMode(a.getMode(e, n), t)
				}, "markdown"), a.defineMIME("text/x-gfm", "gfm")
			}, "object" == typeof n && "object" == typeof t ? r(e("../../lib/codemirror"), e("../markdown/markdown"), e(
				"../../addon/mode/overlay")) : r(CodeMirror)
		}, {
			"../../addon/mode/overlay": 8,
			"../../lib/codemirror": 11,
			"../markdown/markdown": 13
		}],
		13: [function (e, t, n) {
			var r;
			r = function (B) {
				"use strict";
				B.defineMode("markdown", function (p, w) {
					var k = B.getMode(p, "text/html"),
						i = "null" == k.name;
					void 0 === w.highlightFormatting && (w.highlightFormatting = !1), void 0 === w.maxBlockquoteDepth && (w.maxBlockquoteDepth = 0),
						void 0 === w.taskLists && (w.taskLists = !1), void 0 === w.strikethrough && (w.strikethrough = !1), void 0 === w.emoji && (w.emoji = !
							1), void 0 === w.fencedCodeBlockHighlighting && (w.fencedCodeBlockHighlighting = !0), void 0 === w.xml && (w.xml = !0), void 0 ===
						w.tokenTypeOverrides && (w.tokenTypeOverrides = {});
					var C = {
						header: "header",
						code: "comment",
						quote: "quote",
						list1: "variable-2",
						list2: "variable-3",
						list3: "keyword",
						hr: "hr",
						image: "image",
						imageAltText: "image-alt-text",
						imageMarker: "image-marker",
						formatting: "formatting",
						linkInline: "link",
						linkEmail: "link",
						linkText: "link",
						linkHref: "string",
						em: "em",
						strong: "strong",
						strikethrough: "strikethrough",
						emoji: "builtin"
					};
					for (var e in C) C.hasOwnProperty(e) && w.tokenTypeOverrides[e] && (C[e] = w.tokenTypeOverrides[e]);
					var m = /^([*\-_])(?:\s*\1){2,}\s*$/,
						g = /^(?:[*\-+]|^[0-9]+([.)]))\s+/,
						S = /^\[(x| )\](?=\s)/i,
						v = w.allowAtxHeaderWithoutSpace ? /^(#+)/ : /^(#+)(?: |$)/,
						y = /^ *(?:\={1,}|-{1,})\s*$/,
						n = /^[^#!\[\]*_\\<>` "'(~:]+/,
						x = /^(~~~+|```+)[ \t]*([\w+#-]*)[^\n`]*$/,
						b = /^\s*\[[^\]]+?\]:.*$/,
						L =
						/[!"#$%&'()*+,\-.\/:;<=>?@\[\\\]^_`{|}~\xA1\xA7\xAB\xB6\xB7\xBB\xBF\u037E\u0387\u055A-\u055F\u0589\u058A\u05BE\u05C0\u05C3\u05C6\u05F3\u05F4\u0609\u060A\u060C\u060D\u061B\u061E\u061F\u066A-\u066D\u06D4\u0700-\u070D\u07F7-\u07F9\u0830-\u083E\u085E\u0964\u0965\u0970\u0AF0\u0DF4\u0E4F\u0E5A\u0E5B\u0F04-\u0F12\u0F14\u0F3A-\u0F3D\u0F85\u0FD0-\u0FD4\u0FD9\u0FDA\u104A-\u104F\u10FB\u1360-\u1368\u1400\u166D\u166E\u169B\u169C\u16EB-\u16ED\u1735\u1736\u17D4-\u17D6\u17D8-\u17DA\u1800-\u180A\u1944\u1945\u1A1E\u1A1F\u1AA0-\u1AA6\u1AA8-\u1AAD\u1B5A-\u1B60\u1BFC-\u1BFF\u1C3B-\u1C3F\u1C7E\u1C7F\u1CC0-\u1CC7\u1CD3\u2010-\u2027\u2030-\u2043\u2045-\u2051\u2053-\u205E\u207D\u207E\u208D\u208E\u2308-\u230B\u2329\u232A\u2768-\u2775\u27C5\u27C6\u27E6-\u27EF\u2983-\u2998\u29D8-\u29DB\u29FC\u29FD\u2CF9-\u2CFC\u2CFE\u2CFF\u2D70\u2E00-\u2E2E\u2E30-\u2E42\u3001-\u3003\u3008-\u3011\u3014-\u301F\u3030\u303D\u30A0\u30FB\uA4FE\uA4FF\uA60D-\uA60F\uA673\uA67E\uA6F2-\uA6F7\uA874-\uA877\uA8CE\uA8CF\uA8F8-\uA8FA\uA8FC\uA92E\uA92F\uA95F\uA9C1-\uA9CD\uA9DE\uA9DF\uAA5C-\uAA5F\uAADE\uAADF\uAAF0\uAAF1\uABEB\uFD3E\uFD3F\uFE10-\uFE19\uFE30-\uFE52\uFE54-\uFE61\uFE63\uFE68\uFE6A\uFE6B\uFF01-\uFF03\uFF05-\uFF0A\uFF0C-\uFF0F\uFF1A\uFF1B\uFF1F\uFF20\uFF3B-\uFF3D\uFF3F\uFF5B\uFF5D\uFF5F-\uFF65]|\uD800[\uDD00-\uDD02\uDF9F\uDFD0]|\uD801\uDD6F|\uD802[\uDC57\uDD1F\uDD3F\uDE50-\uDE58\uDE7F\uDEF0-\uDEF6\uDF39-\uDF3F\uDF99-\uDF9C]|\uD804[\uDC47-\uDC4D\uDCBB\uDCBC\uDCBE-\uDCC1\uDD40-\uDD43\uDD74\uDD75\uDDC5-\uDDC9\uDDCD\uDDDB\uDDDD-\uDDDF\uDE38-\uDE3D\uDEA9]|\uD805[\uDCC6\uDDC1-\uDDD7\uDE41-\uDE43\uDF3C-\uDF3E]|\uD809[\uDC70-\uDC74]|\uD81A[\uDE6E\uDE6F\uDEF5\uDF37-\uDF3B\uDF44]|\uD82F\uDC9F|\uD836[\uDE87-\uDE8B]/;

					function T(e, t, n) {
						return t.f = t.inline = n, n(e, t)
					}

					function M(e, t, n) {
						return t.f = t.block = n, n(e, t)
					}

					function r(e) {
						if (e.linkTitle = !1, e.linkHref = !1, e.linkText = !1, e.em = !1, e.strong = !1, e.strikethrough = !1, e.quote = 0, e.indentedCode = !
							1, e.f == A) {
							var t = i;
							if (!t) {
								var n = B.innerMode(k, e.htmlState);
								t = "xml" == n.mode.name && null === n.state.tagStart && !n.state.context && n.state.tokenize.isInText
							}
							t && (e.f = D, e.block = a, e.htmlState = null)
						}
						return e.trailingSpace = 0, e.trailingSpaceNewLine = !1, e.prevLine = e.thisLine, e.thisLine = {
							stream: null
						}, null
					}

					function a(e, t) {
						var n, r = e.column() === t.indentation,
							i = !(n = t.prevLine.stream) || !/\S/.test(n.string),
							o = t.indentedCode,
							a = t.prevLine.hr,
							l = !1 !== t.list,
							s = (t.listStack[t.listStack.length - 1] || 0) + 3;
						t.indentedCode = !1;
						var u = t.indentation;
						if (null === t.indentationDiff && (t.indentationDiff = t.indentation, l)) {
							for (t.em = !1, t.strong = !1, t.code = !1, t.strikethrough = !1, t.list = null; u < t.listStack[t.listStack.length - 1];) t
								.listStack.pop(), t.listStack.length ? t.indentation = t.listStack[t.listStack.length - 1] : t.list = !1;
							!1 !== t.list && (t.indentationDiff = u - t.listStack[t.listStack.length - 1])
						}
						var c = !(i || a || t.prevLine.header || l && o || t.prevLine.fencedCodeEnd),
							h = (!1 === t.list || a || i) && t.indentation <= s && e.match(m),
							f = null;
						if (4 <= t.indentationDiff && (o || t.prevLine.fencedCodeEnd || t.prevLine.header || i)) return e.skipToEnd(), t.indentedCode = !
							0, C.code;
						if (e.eatSpace()) return null;
						if (r && t.indentation <= s && (f = e.match(v)) && f[1].length <= 6) return t.quote = 0, t.header = f[1].length, t.thisLine.header = !
							0, w.highlightFormatting && (t.formatting = "header"), t.f = t.inline, N(t);
						if (t.indentation <= s && e.eat(">")) return t.quote = r ? 1 : t.quote + 1, w.highlightFormatting && (t.formatting = "quote"),
							e.eatSpace(), N(t);
						if (!h && !t.setext && r && t.indentation <= s && (f = e.match(g))) {
							var d = f[1] ? "ol" : "ul";
							return t.indentation = u + e.current().length, t.list = !0, t.quote = 0, t.listStack.push(t.indentation), w.taskLists && e.match(
								S, !1) && (t.taskList = !0), t.f = t.inline, w.highlightFormatting && (t.formatting = ["list", "list-" + d]), N(t)
						}
						return r && t.indentation <= s && (f = e.match(x, !0)) ? (t.quote = 0, t.fencedEndRE = new RegExp(f[1] + "+ *$"), t.localMode =
								w.fencedCodeBlockHighlighting && function (e) {
									if (B.findModeByName) {
										var t = B.findModeByName(e);
										t && (e = t.mime || t.mimes[0])
									}
									var n = B.getMode(p, e);
									return "null" == n.name ? null : n
								}(f[2]), t.localMode && (t.localState = B.startState(t.localMode)), t.f = t.block = E, w.highlightFormatting && (t.formatting =
									"code-block"), t.code = -1, N(t)) : t.setext || !(c && l || t.quote || !1 !== t.list || t.code || h || b.test(e.string)) &&
							(f = e.lookAhead(1)) && (f = f.match(y)) ? (t.setext ? (t.header = t.setext, t.setext = 0, e.skipToEnd(), w.highlightFormatting &&
									(t.formatting = "header")) : (t.header = "=" == f[0].charAt(0) ? 1 : 2, t.setext = t.header), t.thisLine.header = !0, t.f =
								t.inline, N(t)) : h ? (e.skipToEnd(), t.hr = !0, t.thisLine.hr = !0, C.hr) : "[" === e.peek() ? T(e, t, I) : T(e, t, t.inline)
					}

					function A(e, t) {
						var n = k.token(e, t.htmlState);
						if (!i) {
							var r = B.innerMode(k, t.htmlState);
							("xml" == r.mode.name && null === r.state.tagStart && !r.state.context && r.state.tokenize.isInText || t.md_inside && -1 < e
								.current().indexOf(">")) && (t.f = D, t.block = a, t.htmlState = null)
						}
						return n
					}

					function E(e, t) {
						var n, r = t.listStack[t.listStack.length - 1] || 0,
							i = t.indentation < r,
							o = r + 3;
						return t.fencedEndRE && t.indentation <= o && (i || e.match(t.fencedEndRE)) ? (w.highlightFormatting && (t.formatting =
								"code-block"), i || (n = N(t)), t.localMode = t.localState = null, t.block = a, t.f = D, t.fencedEndRE = null, t.code = 0,
							t.thisLine.fencedCodeEnd = !0, i ? M(e, t, t.block) : n) : t.localMode ? t.localMode.token(e, t.localState) : (e.skipToEnd(),
							C.code)
					}

					function N(e) {
						var t = [];
						if (e.formatting) {
							t.push(C.formatting), "string" == typeof e.formatting && (e.formatting = [e.formatting]);
							for (var n = 0; n < e.formatting.length; n++) t.push(C.formatting + "-" + e.formatting[n]), "header" === e.formatting[n] &&
								t.push(C.formatting + "-" + e.formatting[n] + "-" + e.header), "quote" === e.formatting[n] && (!w.maxBlockquoteDepth || w.maxBlockquoteDepth >=
									e.quote ? t.push(C.formatting + "-" + e.formatting[n] + "-" + e.quote) : t.push("error"))
						}
						if (e.taskOpen) return t.push("meta"), t.length ? t.join(" ") : null;
						if (e.taskClosed) return t.push("property"), t.length ? t.join(" ") : null;
						if (e.linkHref ? t.push(C.linkHref, "url") : (e.strong && t.push(C.strong), e.em && t.push(C.em), e.strikethrough && t.push(C
								.strikethrough), e.emoji && t.push(C.emoji), e.linkText && t.push(C.linkText), e.code && t.push(C.code), e.image && t.push(
								C.image), e.imageAltText && t.push(C.imageAltText, "link"), e.imageMarker && t.push(C.imageMarker)), e.header && t.push(C.header,
								C.header + "-" + e.header), e.quote && (t.push(C.quote), !w.maxBlockquoteDepth || w.maxBlockquoteDepth >= e.quote ? t.push(
								C.quote + "-" + e.quote) : t.push(C.quote + "-" + w.maxBlockquoteDepth)), !1 !== e.list) {
							var r = (e.listStack.length - 1) % 3;
							r ? 1 === r ? t.push(C.list2) : t.push(C.list3) : t.push(C.list1)
						}
						return e.trailingSpaceNewLine ? t.push("trailing-space-new-line") : e.trailingSpace && t.push("trailing-space-" + (e.trailingSpace %
							2 ? "a" : "b")), t.length ? t.join(" ") : null
					}

					function t(e, t) {
						if (e.match(n, !0)) return N(t)
					}

					function D(e, t) {
						var n = t.text(e, t);
						if (void 0 !== n) return n;
						if (t.list) return t.list = null, N(t);
						if (t.taskList) return " " === e.match(S, !0)[1] ? t.taskOpen = !0 : t.taskClosed = !0, w.highlightFormatting && (t.formatting =
							"task"), t.taskList = !1, N(t);
						if (t.taskOpen = !1, t.taskClosed = !1, t.header && e.match(/^#+$/, !0)) return w.highlightFormatting && (t.formatting =
							"header"), N(t);
						var r = e.next();
						if (t.linkTitle) {
							t.linkTitle = !1;
							var i = r;
							"(" === r && (i = ")");
							var o = "^\\s*(?:[^" + (i = (i + "").replace(/([.?*+^\[\]\\(){}|-])/g, "\\$1")) + "\\\\]+|\\\\\\\\|\\\\.)" + i;
							if (e.match(new RegExp(o), !0)) return C.linkHref
						}
						if ("`" === r) {
							var a = t.formatting;
							w.highlightFormatting && (t.formatting = "code"), e.eatWhile("`");
							var l = e.current().length;
							if (0 != t.code || t.quote && 1 != l) {
								if (l != t.code) return t.formatting = a, N(t);
								var s = N(t);
								return t.code = 0, s
							}
							return t.code = l, N(t)
						}
						if (t.code) return N(t);
						if ("\\" === r && (e.next(), w.highlightFormatting)) {
							var u = N(t),
								c = C.formatting + "-escape";
							return u ? u + " " + c : c
						}
						if ("!" === r && e.match(/\[[^\]]*\] ?(?:\(|\[)/, !1)) return t.imageMarker = !0, t.image = !0, w.highlightFormatting && (t.formatting =
							"image"), N(t);
						if ("[" === r && t.imageMarker && e.match(/[^\]]*\](\(.*?\)| ?\[.*?\])/, !1)) return t.imageMarker = !1, t.imageAltText = !0,
							w.highlightFormatting && (t.formatting = "image"), N(t);
						if ("]" === r && t.imageAltText) {
							w.highlightFormatting && (t.formatting = "image");
							var u = N(t);
							return t.imageAltText = !1, t.image = !1, t.inline = t.f = O, u
						}
						if ("[" === r && !t.image) return t.linkText && e.match(/^.*?\]/) || (t.linkText = !0, w.highlightFormatting && (t.formatting =
							"link")), N(t);
						if ("]" === r && t.linkText) {
							w.highlightFormatting && (t.formatting = "link");
							var u = N(t);
							return t.linkText = !1, t.inline = t.f = e.match(/\(.*?\)| ?\[.*?\]/, !1) ? O : D, u
						}
						if ("<" === r && e.match(/^(https?|ftps?):\/\/(?:[^\\>]|\\.)+>/, !1)) return t.f = t.inline = F, w.highlightFormatting && (t.formatting =
							"link"), (u = N(t)) ? u += " " : u = "", u + C.linkInline;
						if ("<" === r && e.match(/^[^> \\]+@(?:[^\\>]|\\.)+>/, !1)) return t.f = t.inline = F, w.highlightFormatting && (t.formatting =
							"link"), (u = N(t)) ? u += " " : u = "", u + C.linkEmail;
						if (w.xml && "<" === r && e.match(/^(!--|\?|!\[CDATA\[|[a-z][a-z0-9-]*(?:\s+[a-z_:.\-]+(?:\s*=\s*[^>]+)?)*\s*(?:>|$))/i, !1)) {
							var h = e.string.indexOf(">", e.pos);
							if (-1 != h) {
								var f = e.string.substring(e.start, h);
								/markdown\s*=\s*('|"){0,1}1('|"){0,1}/.test(f) && (t.md_inside = !0)
							}
							return e.backUp(1), t.htmlState = B.startState(k), M(e, t, A)
						}
						if (w.xml && "<" === r && e.match(/^\/\w*?>/)) return t.md_inside = !1, "tag";
						if ("*" === r || "_" === r) {
							for (var d = 1, p = 1 == e.pos ? " " : e.string.charAt(e.pos - 2); d < 3 && e.eat(r);) d++;
							var m = e.peek() || " ",
								g = !/\s/.test(m) && (!L.test(m) || /\s/.test(p) || L.test(p)),
								v = !/\s/.test(p) && (!L.test(p) || /\s/.test(m) || L.test(m)),
								y = null,
								x = null;
							if (d % 2 && (t.em || !g || "*" !== r && v && !L.test(p) ? t.em != r || !v || "*" !== r && g && !L.test(m) || (y = !1) : y = !
									0), 1 < d && (t.strong || !g || "*" !== r && v && !L.test(p) ? t.strong != r || !v || "*" !== r && g && !L.test(m) || (x = !
									1) : x = !0), null != x || null != y) {
								w.highlightFormatting && (t.formatting = null == y ? "strong" : null == x ? "em" : "strong em"), !0 === y && (t.em = r), !0 ===
									x && (t.strong = r);
								s = N(t);
								return !1 === y && (t.em = !1), !1 === x && (t.strong = !1), s
							}
						} else if (" " === r && (e.eat("*") || e.eat("_"))) {
							if (" " === e.peek()) return N(t);
							e.backUp(1)
						}
						if (w.strikethrough)
							if ("~" === r && e.eatWhile(r)) {
								if (t.strikethrough) {
									w.highlightFormatting && (t.formatting = "strikethrough");
									s = N(t);
									return t.strikethrough = !1, s
								}
								if (e.match(/^[^\s]/, !1)) return t.strikethrough = !0, w.highlightFormatting && (t.formatting = "strikethrough"), N(t)
							} else if (" " === r && e.match(/^~~/, !0)) {
							if (" " === e.peek()) return N(t);
							e.backUp(2)
						}
						if (w.emoji && ":" === r && e.match(/^(?:[a-z_\d+][a-z_\d+-]*|\-[a-z_\d+][a-z_\d+-]*):/)) {
							t.emoji = !0, w.highlightFormatting && (t.formatting = "emoji");
							var b = N(t);
							return t.emoji = !1, b
						}
						return " " === r && (e.match(/^ +$/, !1) ? t.trailingSpace++ : t.trailingSpace && (t.trailingSpaceNewLine = !0)), N(t)
					}

					function F(e, t) {
						if (">" !== e.next()) return e.match(/^[^>]+/, !0), C.linkInline;
						t.f = t.inline = D, w.highlightFormatting && (t.formatting = "link");
						var n = N(t);
						return n ? n += " " : n = "", n + C.linkInline
					}

					function O(e, t) {
						if (e.eatSpace()) return null;
						var i, n = e.next();
						return "(" === n || "[" === n ? (t.f = t.inline = (i = "(" === n ? ")" : "]", function (e, t) {
							var n = e.next();
							if (n !== i) return e.match(o[i]), t.linkHref = !0, N(t);
							t.f = t.inline = D, w.highlightFormatting && (t.formatting = "link-string");
							var r = N(t);
							return t.linkHref = !1, r
						}), w.highlightFormatting && (t.formatting = "link-string"), t.linkHref = !0, N(t)) : "error"
					}
					var o = {
						")": /^(?:[^\\\(\)]|\\.|\((?:[^\\\(\)]|\\.)*\))*?(?=\))/,
						"]": /^(?:[^\\\[\]]|\\.|\[(?:[^\\\[\]]|\\.)*\])*?(?=\])/
					};

					function I(e, t) {
						return e.match(/^([^\]\\]|\\.)*\]:/, !1) ? (t.f = l, e.next(), w.highlightFormatting && (t.formatting = "link"), t.linkText = !
							0, N(t)) : T(e, t, D)
					}

					function l(e, t) {
						if (e.match(/^\]:/, !0)) {
							t.f = t.inline = s, w.highlightFormatting && (t.formatting = "link");
							var n = N(t);
							return t.linkText = !1, n
						}
						return e.match(/^([^\]\\]|\\.)+/, !0), C.linkText
					}

					function s(e, t) {
						return e.eatSpace() ? null : (e.match(/^[^\s]+/, !0), void 0 === e.peek() ? t.linkTitle = !0 : e.match(
								/^(?:\s+(?:"(?:[^"\\]|\\\\|\\.)+"|'(?:[^'\\]|\\\\|\\.)+'|\((?:[^)\\]|\\\\|\\.)+\)))?/, !0), t.f = t.inline = D, C.linkHref +
							" url")
					}
					var u = {
						startState: function () {
							return {
								f: a,
								prevLine: {
									stream: null
								},
								thisLine: {
									stream: null
								},
								block: a,
								htmlState: null,
								indentation: 0,
								inline: D,
								text: t,
								formatting: !1,
								linkText: !1,
								linkHref: !1,
								linkTitle: !1,
								code: 0,
								em: !1,
								strong: !1,
								header: 0,
								setext: 0,
								hr: !1,
								taskList: !1,
								list: !1,
								listStack: [],
								quote: 0,
								trailingSpace: 0,
								trailingSpaceNewLine: !1,
								strikethrough: !1,
								emoji: !1,
								fencedEndRE: null
							}
						},
						copyState: function (e) {
							return {
								f: e.f,
								prevLine: e.prevLine,
								thisLine: e.thisLine,
								block: e.block,
								htmlState: e.htmlState && B.copyState(k, e.htmlState),
								indentation: e.indentation,
								localMode: e.localMode,
								localState: e.localMode ? B.copyState(e.localMode, e.localState) : null,
								inline: e.inline,
								text: e.text,
								formatting: !1,
								linkText: e.linkText,
								linkTitle: e.linkTitle,
								linkHref: e.linkHref,
								code: e.code,
								em: e.em,
								strong: e.strong,
								strikethrough: e.strikethrough,
								emoji: e.emoji,
								header: e.header,
								setext: e.setext,
								hr: e.hr,
								taskList: e.taskList,
								list: e.list,
								listStack: e.listStack.slice(0),
								quote: e.quote,
								indentedCode: e.indentedCode,
								trailingSpace: e.trailingSpace,
								trailingSpaceNewLine: e.trailingSpaceNewLine,
								md_inside: e.md_inside,
								fencedEndRE: e.fencedEndRE
							}
						},
						token: function (e, t) {
							if (t.formatting = !1, e != t.thisLine.stream) {
								if (t.header = 0, t.hr = !1, e.match(/^\s*$/, !0)) return r(t), null;
								if (t.prevLine = t.thisLine, t.thisLine = {
										stream: e
									}, t.taskList = !1, t.trailingSpace = 0, t.trailingSpaceNewLine = !1, !t.localState && (t.f = t.block, t.f != A)) {
									var n = e.match(/^\s*/, !0)[0].replace(/\t/g, "    ").length;
									if (t.indentation = n, t.indentationDiff = null, 0 < n) return null
								}
							}
							return t.f(e, t)
						},
						innerMode: function (e) {
							return e.block == A ? {
								state: e.htmlState,
								mode: k
							} : e.localState ? {
								state: e.localState,
								mode: e.localMode
							} : {
								state: e,
								mode: u
							}
						},
						indent: function (e, t, n) {
							return e.block == A && k.indent ? k.indent(e.htmlState, t, n) : e.localState && e.localMode.indent ? e.localMode.indent(e.localState,
								t, n) : B.Pass
						},
						blankLine: r,
						getType: N,
						blockCommentStart: "\x3c!--",
						blockCommentEnd: "--\x3e",
						closeBrackets: "()[]{}''\"\"``",
						fold: "markdown"
					};
					return u
				}, "xml"), B.defineMIME("text/markdown", "markdown"), B.defineMIME("text/x-markdown", "markdown")
			}, "object" == typeof n && "object" == typeof t ? r(e("../../lib/codemirror"), e("../xml/xml"), e("../meta")) : r(CodeMirror)
		}, {
			"../../lib/codemirror": 11,
			"../meta": 14,
			"../xml/xml": 15
		}],
		14: [function (e, t, n) {
			(function (o) {
				"use strict";
				o.modeInfo = [{
					name: "APL",
					mime: "text/apl",
					mode: "apl",
					ext: ["dyalog", "apl"]
				}, {
					name: "PGP",
					mimes: ["application/pgp", "application/pgp-encrypted", "application/pgp-keys", "application/pgp-signature"],
					mode: "asciiarmor",
					ext: ["asc", "pgp", "sig"]
				}, {
					name: "ASN.1",
					mime: "text/x-ttcn-asn",
					mode: "asn.1",
					ext: ["asn", "asn1"]
				}, {
					name: "Asterisk",
					mime: "text/x-asterisk",
					mode: "asterisk",
					file: /^extensions\.conf$/i
				}, {
					name: "Brainfuck",
					mime: "text/x-brainfuck",
					mode: "brainfuck",
					ext: ["b", "bf"]
				}, {
					name: "C",
					mime: "text/x-csrc",
					mode: "clike",
					ext: ["c", "h", "ino"]
				}, {
					name: "C++",
					mime: "text/x-c++src",
					mode: "clike",
					ext: ["cpp", "c++", "cc", "cxx", "hpp", "h++", "hh", "hxx"],
					alias: ["cpp"]
				}, {
					name: "Cobol",
					mime: "text/x-cobol",
					mode: "cobol",
					ext: ["cob", "cpy"]
				}, {
					name: "C#",
					mime: "text/x-csharp",
					mode: "clike",
					ext: ["cs"],
					alias: ["csharp"]
				}, {
					name: "Clojure",
					mime: "text/x-clojure",
					mode: "clojure",
					ext: ["clj", "cljc", "cljx"]
				}, {
					name: "ClojureScript",
					mime: "text/x-clojurescript",
					mode: "clojure",
					ext: ["cljs"]
				}, {
					name: "Closure Stylesheets (GSS)",
					mime: "text/x-gss",
					mode: "css",
					ext: ["gss"]
				}, {
					name: "CMake",
					mime: "text/x-cmake",
					mode: "cmake",
					ext: ["cmake", "cmake.in"],
					file: /^CMakeLists.txt$/
				}, {
					name: "CoffeeScript",
					mimes: ["application/vnd.coffeescript", "text/coffeescript", "text/x-coffeescript"],
					mode: "coffeescript",
					ext: ["coffee"],
					alias: ["coffee", "coffee-script"]
				}, {
					name: "Common Lisp",
					mime: "text/x-common-lisp",
					mode: "commonlisp",
					ext: ["cl", "lisp", "el"],
					alias: ["lisp"]
				}, {
					name: "Cypher",
					mime: "application/x-cypher-query",
					mode: "cypher",
					ext: ["cyp", "cypher"]
				}, {
					name: "Cython",
					mime: "text/x-cython",
					mode: "python",
					ext: ["pyx", "pxd", "pxi"]
				}, {
					name: "Crystal",
					mime: "text/x-crystal",
					mode: "crystal",
					ext: ["cr"]
				}, {
					name: "CSS",
					mime: "text/css",
					mode: "css",
					ext: ["css"]
				}, {
					name: "CQL",
					mime: "text/x-cassandra",
					mode: "sql",
					ext: ["cql"]
				}, {
					name: "D",
					mime: "text/x-d",
					mode: "d",
					ext: ["d"]
				}, {
					name: "Dart",
					mimes: ["application/dart", "text/x-dart"],
					mode: "dart",
					ext: ["dart"]
				}, {
					name: "diff",
					mime: "text/x-diff",
					mode: "diff",
					ext: ["diff", "patch"]
				}, {
					name: "Django",
					mime: "text/x-django",
					mode: "django"
				}, {
					name: "Dockerfile",
					mime: "text/x-dockerfile",
					mode: "dockerfile",
					file: /^Dockerfile$/
				}, {
					name: "DTD",
					mime: "application/xml-dtd",
					mode: "dtd",
					ext: ["dtd"]
				}, {
					name: "Dylan",
					mime: "text/x-dylan",
					mode: "dylan",
					ext: ["dylan", "dyl", "intr"]
				}, {
					name: "EBNF",
					mime: "text/x-ebnf",
					mode: "ebnf"
				}, {
					name: "ECL",
					mime: "text/x-ecl",
					mode: "ecl",
					ext: ["ecl"]
				}, {
					name: "edn",
					mime: "application/edn",
					mode: "clojure",
					ext: ["edn"]
				}, {
					name: "Eiffel",
					mime: "text/x-eiffel",
					mode: "eiffel",
					ext: ["e"]
				}, {
					name: "Elm",
					mime: "text/x-elm",
					mode: "elm",
					ext: ["elm"]
				}, {
					name: "Embedded Javascript",
					mime: "application/x-ejs",
					mode: "htmlembedded",
					ext: ["ejs"]
				}, {
					name: "Embedded Ruby",
					mime: "application/x-erb",
					mode: "htmlembedded",
					ext: ["erb"]
				}, {
					name: "Erlang",
					mime: "text/x-erlang",
					mode: "erlang",
					ext: ["erl"]
				}, {
					name: "Esper",
					mime: "text/x-esper",
					mode: "sql"
				}, {
					name: "Factor",
					mime: "text/x-factor",
					mode: "factor",
					ext: ["factor"]
				}, {
					name: "FCL",
					mime: "text/x-fcl",
					mode: "fcl"
				}, {
					name: "Forth",
					mime: "text/x-forth",
					mode: "forth",
					ext: ["forth", "fth", "4th"]
				}, {
					name: "Fortran",
					mime: "text/x-fortran",
					mode: "fortran",
					ext: ["f", "for", "f77", "f90", "f95"]
				}, {
					name: "F#",
					mime: "text/x-fsharp",
					mode: "mllike",
					ext: ["fs"],
					alias: ["fsharp"]
				}, {
					name: "Gas",
					mime: "text/x-gas",
					mode: "gas",
					ext: ["s"]
				}, {
					name: "Gherkin",
					mime: "text/x-feature",
					mode: "gherkin",
					ext: ["feature"]
				}, {
					name: "GitHub Flavored Markdown",
					mime: "text/x-gfm",
					mode: "gfm",
					file: /^(readme|contributing|history).md$/i
				}, {
					name: "Go",
					mime: "text/x-go",
					mode: "go",
					ext: ["go"]
				}, {
					name: "Groovy",
					mime: "text/x-groovy",
					mode: "groovy",
					ext: ["groovy", "gradle"],
					file: /^Jenkinsfile$/
				}, {
					name: "HAML",
					mime: "text/x-haml",
					mode: "haml",
					ext: ["haml"]
				}, {
					name: "Haskell",
					mime: "text/x-haskell",
					mode: "haskell",
					ext: ["hs"]
				}, {
					name: "Haskell (Literate)",
					mime: "text/x-literate-haskell",
					mode: "haskell-literate",
					ext: ["lhs"]
				}, {
					name: "Haxe",
					mime: "text/x-haxe",
					mode: "haxe",
					ext: ["hx"]
				}, {
					name: "HXML",
					mime: "text/x-hxml",
					mode: "haxe",
					ext: ["hxml"]
				}, {
					name: "ASP.NET",
					mime: "application/x-aspx",
					mode: "htmlembedded",
					ext: ["aspx"],
					alias: ["asp", "aspx"]
				}, {
					name: "HTML",
					mime: "text/html",
					mode: "htmlmixed",
					ext: ["html", "htm", "handlebars", "hbs"],
					alias: ["xhtml"]
				}, {
					name: "HTTP",
					mime: "message/http",
					mode: "http"
				}, {
					name: "IDL",
					mime: "text/x-idl",
					mode: "idl",
					ext: ["pro"]
				}, {
					name: "Pug",
					mime: "text/x-pug",
					mode: "pug",
					ext: ["jade", "pug"],
					alias: ["jade"]
				}, {
					name: "Java",
					mime: "text/x-java",
					mode: "clike",
					ext: ["java"]
				}, {
					name: "Java Server Pages",
					mime: "application/x-jsp",
					mode: "htmlembedded",
					ext: ["jsp"],
					alias: ["jsp"]
				}, {
					name: "JavaScript",
					mimes: ["text/javascript", "text/ecmascript", "application/javascript", "application/x-javascript", "application/ecmascript"],
					mode: "javascript",
					ext: ["js"],
					alias: ["ecmascript", "js", "node"]
				}, {
					name: "JSON",
					mimes: ["application/json", "application/x-json"],
					mode: "javascript",
					ext: ["json", "map"],
					alias: ["json5"]
				}, {
					name: "JSON-LD",
					mime: "application/ld+json",
					mode: "javascript",
					ext: ["jsonld"],
					alias: ["jsonld"]
				}, {
					name: "JSX",
					mime: "text/jsx",
					mode: "jsx",
					ext: ["jsx"]
				}, {
					name: "Jinja2",
					mime: "text/jinja2",
					mode: "jinja2",
					ext: ["j2", "jinja", "jinja2"]
				}, {
					name: "Julia",
					mime: "text/x-julia",
					mode: "julia",
					ext: ["jl"]
				}, {
					name: "Kotlin",
					mime: "text/x-kotlin",
					mode: "clike",
					ext: ["kt"]
				}, {
					name: "LESS",
					mime: "text/x-less",
					mode: "css",
					ext: ["less"]
				}, {
					name: "LiveScript",
					mime: "text/x-livescript",
					mode: "livescript",
					ext: ["ls"],
					alias: ["ls"]
				}, {
					name: "Lua",
					mime: "text/x-lua",
					mode: "lua",
					ext: ["lua"]
				}, {
					name: "Markdown",
					mime: "text/x-markdown",
					mode: "markdown",
					ext: ["markdown", "md", "mkd"]
				}, {
					name: "mIRC",
					mime: "text/mirc",
					mode: "mirc"
				}, {
					name: "MariaDB SQL",
					mime: "text/x-mariadb",
					mode: "sql"
				}, {
					name: "Mathematica",
					mime: "text/x-mathematica",
					mode: "mathematica",
					ext: ["m", "nb"]
				}, {
					name: "Modelica",
					mime: "text/x-modelica",
					mode: "modelica",
					ext: ["mo"]
				}, {
					name: "MUMPS",
					mime: "text/x-mumps",
					mode: "mumps",
					ext: ["mps"]
				}, {
					name: "MS SQL",
					mime: "text/x-mssql",
					mode: "sql"
				}, {
					name: "mbox",
					mime: "application/mbox",
					mode: "mbox",
					ext: ["mbox"]
				}, {
					name: "MySQL",
					mime: "text/x-mysql",
					mode: "sql"
				}, {
					name: "Nginx",
					mime: "text/x-nginx-conf",
					mode: "nginx",
					file: /nginx.*\.conf$/i
				}, {
					name: "NSIS",
					mime: "text/x-nsis",
					mode: "nsis",
					ext: ["nsh", "nsi"]
				}, {
					name: "NTriples",
					mimes: ["application/n-triples", "application/n-quads", "text/n-triples"],
					mode: "ntriples",
					ext: ["nt", "nq"]
				}, {
					name: "Objective-C",
					mime: "text/x-objectivec",
					mode: "clike",
					ext: ["m", "mm"],
					alias: ["objective-c", "objc"]
				}, {
					name: "OCaml",
					mime: "text/x-ocaml",
					mode: "mllike",
					ext: ["ml", "mli", "mll", "mly"]
				}, {
					name: "Octave",
					mime: "text/x-octave",
					mode: "octave",
					ext: ["m"]
				}, {
					name: "Oz",
					mime: "text/x-oz",
					mode: "oz",
					ext: ["oz"]
				}, {
					name: "Pascal",
					mime: "text/x-pascal",
					mode: "pascal",
					ext: ["p", "pas"]
				}, {
					name: "PEG.js",
					mime: "null",
					mode: "pegjs",
					ext: ["jsonld"]
				}, {
					name: "Perl",
					mime: "text/x-perl",
					mode: "perl",
					ext: ["pl", "pm"]
				}, {
					name: "PHP",
					mimes: ["text/x-php", "application/x-httpd-php", "application/x-httpd-php-open"],
					mode: "php",
					ext: ["php", "php3", "php4", "php5", "php7", "phtml"]
				}, {
					name: "Pig",
					mime: "text/x-pig",
					mode: "pig",
					ext: ["pig"]
				}, {
					name: "Plain Text",
					mime: "text/plain",
					mode: "null",
					ext: ["txt", "text", "conf", "def", "list", "log"]
				}, {
					name: "PLSQL",
					mime: "text/x-plsql",
					mode: "sql",
					ext: ["pls"]
				}, {
					name: "PowerShell",
					mime: "application/x-powershell",
					mode: "powershell",
					ext: ["ps1", "psd1", "psm1"]
				}, {
					name: "Properties files",
					mime: "text/x-properties",
					mode: "properties",
					ext: ["properties", "ini", "in"],
					alias: ["ini", "properties"]
				}, {
					name: "ProtoBuf",
					mime: "text/x-protobuf",
					mode: "protobuf",
					ext: ["proto"]
				}, {
					name: "Python",
					mime: "text/x-python",
					mode: "python",
					ext: ["BUILD", "bzl", "py", "pyw"],
					file: /^(BUCK|BUILD)$/
				}, {
					name: "Puppet",
					mime: "text/x-puppet",
					mode: "puppet",
					ext: ["pp"]
				}, {
					name: "Q",
					mime: "text/x-q",
					mode: "q",
					ext: ["q"]
				}, {
					name: "R",
					mime: "text/x-rsrc",
					mode: "r",
					ext: ["r", "R"],
					alias: ["rscript"]
				}, {
					name: "reStructuredText",
					mime: "text/x-rst",
					mode: "rst",
					ext: ["rst"],
					alias: ["rst"]
				}, {
					name: "RPM Changes",
					mime: "text/x-rpm-changes",
					mode: "rpm"
				}, {
					name: "RPM Spec",
					mime: "text/x-rpm-spec",
					mode: "rpm",
					ext: ["spec"]
				}, {
					name: "Ruby",
					mime: "text/x-ruby",
					mode: "ruby",
					ext: ["rb"],
					alias: ["jruby", "macruby", "rake", "rb", "rbx"]
				}, {
					name: "Rust",
					mime: "text/x-rustsrc",
					mode: "rust",
					ext: ["rs"]
				}, {
					name: "SAS",
					mime: "text/x-sas",
					mode: "sas",
					ext: ["sas"]
				}, {
					name: "Sass",
					mime: "text/x-sass",
					mode: "sass",
					ext: ["sass"]
				}, {
					name: "Scala",
					mime: "text/x-scala",
					mode: "clike",
					ext: ["scala"]
				}, {
					name: "Scheme",
					mime: "text/x-scheme",
					mode: "scheme",
					ext: ["scm", "ss"]
				}, {
					name: "SCSS",
					mime: "text/x-scss",
					mode: "css",
					ext: ["scss"]
				}, {
					name: "Shell",
					mimes: ["text/x-sh", "application/x-sh"],
					mode: "shell",
					ext: ["sh", "ksh", "bash"],
					alias: ["bash", "sh", "zsh"],
					file: /^PKGBUILD$/
				}, {
					name: "Sieve",
					mime: "application/sieve",
					mode: "sieve",
					ext: ["siv", "sieve"]
				}, {
					name: "Slim",
					mimes: ["text/x-slim", "application/x-slim"],
					mode: "slim",
					ext: ["slim"]
				}, {
					name: "Smalltalk",
					mime: "text/x-stsrc",
					mode: "smalltalk",
					ext: ["st"]
				}, {
					name: "Smarty",
					mime: "text/x-smarty",
					mode: "smarty",
					ext: ["tpl"]
				}, {
					name: "Solr",
					mime: "text/x-solr",
					mode: "solr"
				}, {
					name: "SML",
					mime: "text/x-sml",
					mode: "mllike",
					ext: ["sml", "sig", "fun", "smackspec"]
				}, {
					name: "Soy",
					mime: "text/x-soy",
					mode: "soy",
					ext: ["soy"],
					alias: ["closure template"]
				}, {
					name: "SPARQL",
					mime: "application/sparql-query",
					mode: "sparql",
					ext: ["rq", "sparql"],
					alias: ["sparul"]
				}, {
					name: "Spreadsheet",
					mime: "text/x-spreadsheet",
					mode: "spreadsheet",
					alias: ["excel", "formula"]
				}, {
					name: "SQL",
					mime: "text/x-sql",
					mode: "sql",
					ext: ["sql"]
				}, {
					name: "SQLite",
					mime: "text/x-sqlite",
					mode: "sql"
				}, {
					name: "Squirrel",
					mime: "text/x-squirrel",
					mode: "clike",
					ext: ["nut"]
				}, {
					name: "Stylus",
					mime: "text/x-styl",
					mode: "stylus",
					ext: ["styl"]
				}, {
					name: "Swift",
					mime: "text/x-swift",
					mode: "swift",
					ext: ["swift"]
				}, {
					name: "sTeX",
					mime: "text/x-stex",
					mode: "stex"
				}, {
					name: "LaTeX",
					mime: "text/x-latex",
					mode: "stex",
					ext: ["text", "ltx", "tex"],
					alias: ["tex"]
				}, {
					name: "SystemVerilog",
					mime: "text/x-systemverilog",
					mode: "verilog",
					ext: ["v", "sv", "svh"]
				}, {
					name: "Tcl",
					mime: "text/x-tcl",
					mode: "tcl",
					ext: ["tcl"]
				}, {
					name: "Textile",
					mime: "text/x-textile",
					mode: "textile",
					ext: ["textile"]
				}, {
					name: "TiddlyWiki ",
					mime: "text/x-tiddlywiki",
					mode: "tiddlywiki"
				}, {
					name: "Tiki wiki",
					mime: "text/tiki",
					mode: "tiki"
				}, {
					name: "TOML",
					mime: "text/x-toml",
					mode: "toml",
					ext: ["toml"]
				}, {
					name: "Tornado",
					mime: "text/x-tornado",
					mode: "tornado"
				}, {
					name: "troff",
					mime: "text/troff",
					mode: "troff",
					ext: ["1", "2", "3", "4", "5", "6", "7", "8", "9"]
				}, {
					name: "TTCN",
					mime: "text/x-ttcn",
					mode: "ttcn",
					ext: ["ttcn", "ttcn3", "ttcnpp"]
				}, {
					name: "TTCN_CFG",
					mime: "text/x-ttcn-cfg",
					mode: "ttcn-cfg",
					ext: ["cfg"]
				}, {
					name: "Turtle",
					mime: "text/turtle",
					mode: "turtle",
					ext: ["ttl"]
				}, {
					name: "TypeScript",
					mime: "application/typescript",
					mode: "javascript",
					ext: ["ts"],
					alias: ["ts"]
				}, {
					name: "TypeScript-JSX",
					mime: "text/typescript-jsx",
					mode: "jsx",
					ext: ["tsx"],
					alias: ["tsx"]
				}, {
					name: "Twig",
					mime: "text/x-twig",
					mode: "twig"
				}, {
					name: "Web IDL",
					mime: "text/x-webidl",
					mode: "webidl",
					ext: ["webidl"]
				}, {
					name: "VB.NET",
					mime: "text/x-vb",
					mode: "vb",
					ext: ["vb"]
				}, {
					name: "VBScript",
					mime: "text/vbscript",
					mode: "vbscript",
					ext: ["vbs"]
				}, {
					name: "Velocity",
					mime: "text/velocity",
					mode: "velocity",
					ext: ["vtl"]
				}, {
					name: "Verilog",
					mime: "text/x-verilog",
					mode: "verilog",
					ext: ["v"]
				}, {
					name: "VHDL",
					mime: "text/x-vhdl",
					mode: "vhdl",
					ext: ["vhd", "vhdl"]
				}, {
					name: "Vue.js Component",
					mimes: ["script/x-vue", "text/x-vue"],
					mode: "vue",
					ext: ["vue"]
				}, {
					name: "XML",
					mimes: ["application/xml", "text/xml"],
					mode: "xml",
					ext: ["xml", "xsl", "xsd", "svg"],
					alias: ["rss", "wsdl", "xsd"]
				}, {
					name: "XQuery",
					mime: "application/xquery",
					mode: "xquery",
					ext: ["xy", "xquery"]
				}, {
					name: "Yacas",
					mime: "text/x-yacas",
					mode: "yacas",
					ext: ["ys"]
				}, {
					name: "YAML",
					mimes: ["text/x-yaml", "text/yaml"],
					mode: "yaml",
					ext: ["yaml", "yml"],
					alias: ["yml"]
				}, {
					name: "Z80",
					mime: "text/x-z80",
					mode: "z80",
					ext: ["z80"]
				}, {
					name: "mscgen",
					mime: "text/x-mscgen",
					mode: "mscgen",
					ext: ["mscgen", "mscin", "msc"]
				}, {
					name: "xu",
					mime: "text/x-xu",
					mode: "mscgen",
					ext: ["xu"]
				}, {
					name: "msgenny",
					mime: "text/x-msgenny",
					mode: "mscgen",
					ext: ["msgenny"]
				}];
				for (var e = 0; e < o.modeInfo.length; e++) {
					var t = o.modeInfo[e];
					t.mimes && (t.mime = t.mimes[0])
				}
				o.findModeByMIME = function (e) {
					e = e.toLowerCase();
					for (var t = 0; t < o.modeInfo.length; t++) {
						var n = o.modeInfo[t];
						if (n.mime == e) return n;
						if (n.mimes)
							for (var r = 0; r < n.mimes.length; r++)
								if (n.mimes[r] == e) return n
					}
					return /\+xml$/.test(e) ? o.findModeByMIME("application/xml") : /\+json$/.test(e) ? o.findModeByMIME("application/json") : void 0
				}, o.findModeByExtension = function (e) {
					for (var t = 0; t < o.modeInfo.length; t++) {
						var n = o.modeInfo[t];
						if (n.ext)
							for (var r = 0; r < n.ext.length; r++)
								if (n.ext[r] == e) return n
					}
				}, o.findModeByFileName = function (e) {
					for (var t = 0; t < o.modeInfo.length; t++) {
						var n = o.modeInfo[t];
						if (n.file && n.file.test(e)) return n
					}
					var r = e.lastIndexOf("."),
						i = -1 < r && e.substring(r + 1, e.length);
					if (i) return o.findModeByExtension(i)
				}, o.findModeByName = function (e) {
					e = e.toLowerCase();
					for (var t = 0; t < o.modeInfo.length; t++) {
						var n = o.modeInfo[t];
						if (n.name.toLowerCase() == e) return n;
						if (n.alias)
							for (var r = 0; r < n.alias.length; r++)
								if (n.alias[r].toLowerCase() == e) return n
					}
				}
			})("object" == typeof n && "object" == typeof t ? e("../lib/codemirror") : CodeMirror)
		}, {
			"../lib/codemirror": 11
		}],
		15: [function (e, t, n) {
			(function (C) {
				"use strict";
				var S = {
						autoSelfClosers: {
							area: !0,
							base: !0,
							br: !0,
							col: !0,
							command: !0,
							embed: !0,
							frame: !0,
							hr: !0,
							img: !0,
							input: !0,
							keygen: !0,
							link: !0,
							meta: !0,
							param: !0,
							source: !0,
							track: !0,
							wbr: !0,
							menuitem: !0
						},
						implicitlyClosed: {
							dd: !0,
							li: !0,
							optgroup: !0,
							option: !0,
							p: !0,
							rp: !0,
							rt: !0,
							tbody: !0,
							td: !0,
							tfoot: !0,
							th: !0,
							tr: !0
						},
						contextGrabbers: {
							dd: {
								dd: !0,
								dt: !0
							},
							dt: {
								dd: !0,
								dt: !0
							},
							li: {
								li: !0
							},
							option: {
								option: !0,
								optgroup: !0
							},
							optgroup: {
								optgroup: !0
							},
							p: {
								address: !0,
								article: !0,
								aside: !0,
								blockquote: !0,
								dir: !0,
								div: !0,
								dl: !0,
								fieldset: !0,
								footer: !0,
								form: !0,
								h1: !0,
								h2: !0,
								h3: !0,
								h4: !0,
								h5: !0,
								h6: !0,
								header: !0,
								hgroup: !0,
								hr: !0,
								menu: !0,
								nav: !0,
								ol: !0,
								p: !0,
								pre: !0,
								section: !0,
								table: !0,
								ul: !0
							},
							rp: {
								rp: !0,
								rt: !0
							},
							rt: {
								rp: !0,
								rt: !0
							},
							tbody: {
								tbody: !0,
								tfoot: !0
							},
							td: {
								td: !0,
								th: !0
							},
							tfoot: {
								tbody: !0
							},
							th: {
								td: !0,
								th: !0
							},
							thead: {
								tbody: !0,
								tfoot: !0
							},
							tr: {
								tr: !0
							}
						},
						doNotIndent: {
							pre: !0
						},
						allowUnquoted: !0,
						allowMissing: !0,
						caseFold: !0
					},
					L = {
						autoSelfClosers: {},
						implicitlyClosed: {},
						contextGrabbers: {},
						doNotIndent: {},
						allowUnquoted: !1,
						allowMissing: !1,
						allowMissingTagName: !1,
						caseFold: !1
					};
				C.defineMode("xml", function (e, t) {
					var a, o, l = e.indentUnit,
						s = {},
						n = t.htmlMode ? S : L;
					for (var r in n) s[r] = n[r];
					for (var r in t) s[r] = t[r];

					function u(t, n) {
						function e(e) {
							return (n.tokenize = e)(t, n)
						}
						var r = t.next();
						return "<" == r ? t.eat("!") ? t.eat("[") ? t.match("CDATA[") ? e(i("atom", "]]>")) : null : t.match("--") ? e(i("comment",
							"--\x3e")) : t.match("DOCTYPE", !0, !0) ? (t.eatWhile(/[\w\._\-]/), e(function r(i) {
							return function (e, t) {
								for (var n; null != (n = e.next());) {
									if ("<" == n) return t.tokenize = r(i + 1), t.tokenize(e, t);
									if (">" == n) {
										if (1 != i) return t.tokenize = r(i - 1), t.tokenize(e, t);
										t.tokenize = u;
										break
									}
								}
								return "meta"
							}
						}(1))) : null : t.eat("?") ? (t.eatWhile(/[\w\._\-]/), n.tokenize = i("meta", "?>"), "meta") : (a = t.eat("/") ? "closeTag" :
							"openTag", n.tokenize = c, "tag bracket") : "&" != r ? (t.eatWhile(/[^&<]/), null) : (t.eat("#") ? t.eat("x") ? t.eatWhile(
							/[a-fA-F\d]/) && t.eat(";") : t.eatWhile(/[\d]/) && t.eat(";") : t.eatWhile(/[\w\.\-:]/) && t.eat(";")) ? "atom" : "error"
					}

					function c(e, t) {
						var n = e.next();
						if (">" == n || "/" == n && e.eat(">")) return t.tokenize = u, a = ">" == n ? "endTag" : "selfcloseTag", "tag bracket";
						if ("=" == n) return a = "equals", null;
						if ("<" != n) return /[\'\"]/.test(n) ? (t.tokenize = (r = n, (i = function (e, t) {
							for (; !e.eol();)
								if (e.next() == r) {
									t.tokenize = c;
									break
								}
							return "string"
						}).isInAttribute = !0, i), t.stringStartCol = e.column(), t.tokenize(e, t)) : (e.match(
							/^[^\s\u00a0=<>\"\']*[^\s\u00a0=<>\"\'\/]/), "word");
						t.tokenize = u, t.state = p, t.tagName = t.tagStart = null;
						var r, i, o = t.tokenize(e, t);
						return o ? o + " tag error" : "tag error"
					}

					function i(n, r) {
						return function (e, t) {
							for (; !e.eol();) {
								if (e.match(r)) {
									t.tokenize = u;
									break
								}
								e.next()
							}
							return n
						}
					}

					function h(e, t, n) {
						this.prev = e.context, this.tagName = t, this.indent = e.indented, this.startOfLine = n, (s.doNotIndent.hasOwnProperty(t) ||
							e.context && e.context.noIndent) && (this.noIndent = !0)
					}

					function f(e) {
						e.context && (e.context = e.context.prev)
					}

					function d(e, t) {
						for (var n;;) {
							if (!e.context) return;
							if (n = e.context.tagName, !s.contextGrabbers.hasOwnProperty(n) || !s.contextGrabbers[n].hasOwnProperty(t)) return;
							f(e)
						}
					}

					function p(e, t, n) {
						return "openTag" == e ? (n.tagStart = t.column(), m) : "closeTag" == e ? g : p
					}

					function m(e, t, n) {
						return "word" == e ? (n.tagName = t.current(), o = "tag", x) : s.allowMissingTagName && "endTag" == e ? (o = "tag bracket", x(
							e, t, n)) : (o = "error", m)
					}

					function g(e, t, n) {
						if ("word" != e) return s.allowMissingTagName && "endTag" == e ? (o = "tag bracket", v(e, t, n)) : (o = "error", y);
						var r = t.current();
						return n.context && n.context.tagName != r && s.implicitlyClosed.hasOwnProperty(n.context.tagName) && f(n), n.context && n.context
							.tagName == r || !1 === s.matchClosing ? (o = "tag", v) : (o = "tag error", y)
					}

					function v(e, t, n) {
						return "endTag" != e ? (o = "error", v) : (f(n), p)
					}

					function y(e, t, n) {
						return o = "error", v(e, 0, n)
					}

					function x(e, t, n) {
						if ("word" == e) return o = "attribute", b;
						if ("endTag" != e && "selfcloseTag" != e) return o = "error", x;
						var r = n.tagName,
							i = n.tagStart;
						return n.tagName = n.tagStart = null, "selfcloseTag" == e || s.autoSelfClosers.hasOwnProperty(r) ? d(n, r) : (d(n, r), n.context =
							new h(n, r, i == n.indented)), p
					}

					function b(e, t, n) {
						return "equals" == e ? w : (s.allowMissing || (o = "error"), x(e, 0, n))
					}

					function w(e, t, n) {
						return "string" == e ? k : "word" == e && s.allowUnquoted ? (o = "string", x) : (o = "error", x(e, 0, n))
					}

					function k(e, t, n) {
						return "string" == e ? k : x(e, 0, n)
					}
					return u.isInText = !0, {
						startState: function (e) {
							var t = {
								tokenize: u,
								state: p,
								indented: e || 0,
								tagName: null,
								tagStart: null,
								context: null
							};
							return null != e && (t.baseIndent = e), t
						},
						token: function (e, t) {
							if (!t.tagName && e.sol() && (t.indented = e.indentation()), e.eatSpace()) return null;
							a = null;
							var n = t.tokenize(e, t);
							return (n || a) && "comment" != n && (o = null, t.state = t.state(a || n, e, t), o && (n = "error" == o ? n + " error" : o)),
								n
						},
						indent: function (e, t, n) {
							var r = e.context;
							if (e.tokenize.isInAttribute) return e.tagStart == e.indented ? e.stringStartCol + 1 : e.indented + l;
							if (r && r.noIndent) return C.Pass;
							if (e.tokenize != c && e.tokenize != u) return n ? n.match(/^(\s*)/)[0].length : 0;
							if (e.tagName) return !1 !== s.multilineTagIndentPastTag ? e.tagStart + e.tagName.length + 2 : e.tagStart + l * (s.multilineTagIndentFactor ||
								1);
							if (s.alignCDATA && /<!\[CDATA\[/.test(t)) return 0;
							var i = t && /^<(\/)?([\w_:\.-]*)/.exec(t);
							if (i && i[1])
								for (; r;) {
									if (r.tagName == i[2]) {
										r = r.prev;
										break
									}
									if (!s.implicitlyClosed.hasOwnProperty(r.tagName)) break;
									r = r.prev
								} else if (i)
									for (; r;) {
										var o = s.contextGrabbers[r.tagName];
										if (!o || !o.hasOwnProperty(i[2])) break;
										r = r.prev
									}
							for (; r && r.prev && !r.startOfLine;) r = r.prev;
							return r ? r.indent + l : e.baseIndent || 0
						},
						electricInput: /<\/[\s\w:]+>$/,
						blockCommentStart: "\x3c!--",
						blockCommentEnd: "--\x3e",
						configuration: s.htmlMode ? "html" : "xml",
						helperType: s.htmlMode ? "html" : "xml",
						skipAttribute: function (e) {
							e.state == w && (e.state = x)
						}
					}
				}), C.defineMIME("text/xml", "xml"), C.defineMIME("application/xml", "xml"), C.mimeModes.hasOwnProperty("text/html") || C.defineMIME(
					"text/html", {
						name: "xml",
						htmlMode: !0
					})
			})("object" == typeof n && "object" == typeof t ? e("../../lib/codemirror") : CodeMirror)
		}, {
			"../../lib/codemirror": 11
		}],
		16: [function (e, t, n) {
			n.read = function (e, t, n, r, i) {
				var o, a, l = 8 * i - r - 1,
					s = (1 << l) - 1,
					u = s >> 1,
					c = -7,
					h = n ? i - 1 : 0,
					f = n ? -1 : 1,
					d = e[t + h];
				for (h += f, o = d & (1 << -c) - 1, d >>= -c, c += l; 0 < c; o = 256 * o + e[t + h], h += f, c -= 8);
				for (a = o & (1 << -c) - 1, o >>= -c, c += r; 0 < c; a = 256 * a + e[t + h], h += f, c -= 8);
				if (0 === o) o = 1 - u;
				else {
					if (o === s) return a ? NaN : 1 / 0 * (d ? -1 : 1);
					a += Math.pow(2, r), o -= u
				}
				return (d ? -1 : 1) * a * Math.pow(2, o - r)
			}, n.write = function (e, t, n, r, i, o) {
				var a, l, s, u = 8 * o - i - 1,
					c = (1 << u) - 1,
					h = c >> 1,
					f = 23 === i ? Math.pow(2, -24) - Math.pow(2, -77) : 0,
					d = r ? 0 : o - 1,
					p = r ? 1 : -1,
					m = t < 0 || 0 === t && 1 / t < 0 ? 1 : 0;
				for (t = Math.abs(t), isNaN(t) || t === 1 / 0 ? (l = isNaN(t) ? 1 : 0, a = c) : (a = Math.floor(Math.log(t) / Math.LN2), t * (s =
							Math.pow(2, -a)) < 1 && (a--, s *= 2), 2 <= (t += 1 <= a + h ? f / s : f * Math.pow(2, 1 - h)) * s && (a++, s /= 2), c <= a +
						h ? (l = 0, a = c) : 1 <= a + h ? (l = (t * s - 1) * Math.pow(2, i), a += h) : (l = t * Math.pow(2, h - 1) * Math.pow(2, i), a =
							0)); 8 <= i; e[n + d] = 255 & l, d += p, l /= 256, i -= 8);
				for (a = a << i | l, u += i; 0 < u; e[n + d] = 255 & a, d += p, a /= 256, u -= 8);
				e[n + d - p] |= 128 * m
			}
		}, {}],
		17: [function (e, w, k) {
			(function (e) {
				! function (e) {
					"use strict";
					var y = {
						newline: /^\n+/,
						code: /^( {4}[^\n]+\n*)+/,
						fences: p,
						hr: /^ {0,3}((?:- *){3,}|(?:_ *){3,}|(?:\* *){3,})(?:\n+|$)/,
						heading: /^ *(#{1,6}) *([^\n]+?) *(?:#+ *)?(?:\n+|$)/,
						nptable: p,
						blockquote: /^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/,
						list: /^( {0,3})(bull) [\s\S]+?(?:hr|def|\n{2,}(?! )(?!\1bull )\n*|\s*$)/,
						html: "^ {0,3}(?:<(script|pre|style)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?\\?>\\n*|<![A-Z][\\s\\S]*?>\\n*|<!\\[CDATA\\[[\\s\\S]*?\\]\\]>\\n*|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:\\n{2,}|$)|<(?!script|pre|style)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:\\n{2,}|$)|</(?!script|pre|style)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:\\n{2,}|$))",
						def: /^ {0,3}\[(label)\]: *\n? *<?([^\s>]+)>?(?:(?: +\n? *| *\n *)(title))? *(?:\n+|$)/,
						table: p,
						lheading: /^([^\n]+)\n *(=|-){2,} *(?:\n+|$)/,
						paragraph: /^([^\n]+(?:\n(?!hr|heading|lheading| {0,3}>|<\/?(?:tag)(?: +|\n|\/?>)|<(?:script|pre|style|!--))[^\n]+)*)/,
						text: /^[^\n]+/
					};

					function s(e) {
						this.tokens = [], this.tokens.links = Object.create(null), this.options = e || v.defaults, this.rules = y.normal, this.options.pedantic ?
							this.rules = y.pedantic : this.options.gfm && (this.options.tables ? this.rules = y.tables : this.rules = y.gfm)
					}
					y._label = /(?!\s*\])(?:\\[\[\]]|[^\[\]])+/, y._title = /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/, y.def =
						o(y.def).replace("label", y._label).replace("title", y._title).getRegex(), y.bullet = /(?:[*+-]|\d{1,9}\.)/, y.item =
						/^( *)(bull) ?[^\n]*(?:\n(?!\1bull ?)[^\n]*)*/, y.item = o(y.item, "gm").replace(/bull/g, y.bullet).getRegex(), y.list = o(y.list)
						.replace(/bull/g, y.bullet).replace("hr", "\\n+(?=\\1?(?:(?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$))").replace("def",
							"\\n+(?=" + y.def.source + ")").getRegex(), y._tag =
						"address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|section|source|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul",
						y._comment = /<!--(?!-?>)[\s\S]*?-->/, y.html = o(y.html, "i").replace("comment", y._comment).replace("tag", y._tag).replace(
							"attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), y.paragraph = o(y.paragraph)
						.replace("hr", y.hr).replace("heading", y.heading).replace("lheading", y.lheading).replace("tag", y._tag).getRegex(), y.blockquote =
						o(y.blockquote).replace("paragraph", y.paragraph).getRegex(), y.normal = m({}, y), y.gfm = m({}, y.normal, {
							fences: /^ {0,3}(`{3,}|~{3,})([^`\n]*)\n(?:|([\s\S]*?)\n)(?: {0,3}\1[~`]* *(?:\n+|$)|$)/,
							paragraph: /^/,
							heading: /^ *(#{1,6}) +([^\n]+?) *#* *(?:\n+|$)/
						}), y.gfm.paragraph = o(y.paragraph).replace("(?!", "(?!" + y.gfm.fences.source.replace("\\1", "\\2") + "|" + y.list.source.replace(
							"\\1", "\\3") + "|").getRegex(), y.tables = m({}, y.gfm, {
							nptable: /^ *([^|\n ].*\|.*)\n *([-:]+ *\|[-| :]*)(?:\n((?:.*[^>\n ].*(?:\n|$))*)\n*|$)/,
							table: /^ *\|(.+)\n *\|?( *[-:]+[-| :]*)(?:\n((?: *[^>\n ].*(?:\n|$))*)\n*|$)/
						}), y.pedantic = m({}, y.normal, {
							html: o(
								"^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:\"[^\"]*\"|'[^']*'|\\s[^'\"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))"
							).replace("comment", y._comment).replace(/tag/g,
								"(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b"
							).getRegex(),
							def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/
						}), s.rules = y, s.lex = function (e, t) {
							return new s(t).lex(e)
						}, s.prototype.lex = function (e) {
							return e = e.replace(/\r\n|\r/g, "\n").replace(/\t/g, "    ").replace(/\u00a0/g, " ").replace(/\u2424/g, "\n"), this.token(e, !
								0)
						}, s.prototype.token = function (e, t) {
							var n, r, i, o, a, l, s, u, c, h, f, d, p, m, g, v;
							for (e = e.replace(/^ +$/gm, ""); e;)
								if ((i = this.rules.newline.exec(e)) && (e = e.substring(i[0].length), 1 < i[0].length && this.tokens.push({
										type: "space"
									})), i = this.rules.code.exec(e)) e = e.substring(i[0].length), i = i[0].replace(/^ {4}/gm, ""), this.tokens.push({
									type: "code",
									text: this.options.pedantic ? i : b(i, "\n")
								});
								else if (i = this.rules.fences.exec(e)) e = e.substring(i[0].length), this.tokens.push({
								type: "code",
								lang: i[2] ? i[2].trim() : i[2],
								text: i[3] || ""
							});
							else if (i = this.rules.heading.exec(e)) e = e.substring(i[0].length), this.tokens.push({
								type: "heading",
								depth: i[1].length,
								text: i[2]
							});
							else if ((i = this.rules.nptable.exec(e)) && (l = {
									type: "table",
									header: x(i[1].replace(/^ *| *\| *$/g, "")),
									align: i[2].replace(/^ *|\| *$/g, "").split(/ *\| */),
									cells: i[3] ? i[3].replace(/\n$/, "").split("\n") : []
								}).header.length === l.align.length) {
								for (e = e.substring(i[0].length), f = 0; f < l.align.length; f++) /^ *-+: *$/.test(l.align[f]) ? l.align[f] = "right" :
									/^ *:-+: *$/.test(l.align[f]) ? l.align[f] = "center" : /^ *:-+ *$/.test(l.align[f]) ? l.align[f] = "left" : l.align[f] =
									null;
								for (f = 0; f < l.cells.length; f++) l.cells[f] = x(l.cells[f], l.header.length);
								this.tokens.push(l)
							} else if (i = this.rules.hr.exec(e)) e = e.substring(i[0].length), this.tokens.push({
								type: "hr"
							});
							else if (i = this.rules.blockquote.exec(e)) e = e.substring(i[0].length), this.tokens.push({
								type: "blockquote_start"
							}), i = i[0].replace(/^ *> ?/gm, ""), this.token(i, t), this.tokens.push({
								type: "blockquote_end"
							});
							else if (i = this.rules.list.exec(e)) {
								for (e = e.substring(i[0].length), s = {
										type: "list_start",
										ordered: m = 1 < (o = i[2]).length,
										start: m ? +o : "",
										loose: !1
									}, this.tokens.push(s), n = !(u = []), p = (i = i[0].match(this.rules.item)).length, f = 0; f < p; f++) h = (l = i[f]).length, ~
									(l = l.replace(/^ *([*+-]|\d+\.) */, "")).indexOf("\n ") && (h -= l.length, l = this.options.pedantic ? l.replace(
										/^ {1,4}/gm, "") : l.replace(new RegExp("^ {1," + h + "}", "gm"), "")), f !== p - 1 && (a = y.bullet.exec(i[f + 1])[0], (1 <
										o.length ? 1 === a.length : 1 < a.length || this.options.smartLists && a !== o) && (e = i.slice(f + 1).join("\n") + e, f =
										p - 1)), r = n || /\n\n(?!\s*$)/.test(l), f !== p - 1 && (n = "\n" === l.charAt(l.length - 1), r || (r = n)), r && (s.loose = !
										0), v = void 0, (g = /^\[[ xX]\] /.test(l)) && (v = " " !== l[1], l = l.replace(/^\[[ xX]\] +/, "")), c = {
										type: "list_item_start",
										task: g,
										checked: v,
										loose: r
									}, u.push(c), this.tokens.push(c), this.token(l, !1), this.tokens.push({
										type: "list_item_end"
									});
								if (s.loose)
									for (p = u.length, f = 0; f < p; f++) u[f].loose = !0;
								this.tokens.push({
									type: "list_end"
								})
							} else if (i = this.rules.html.exec(e)) e = e.substring(i[0].length), this.tokens.push({
								type: this.options.sanitize ? "paragraph" : "html",
								pre: !this.options.sanitizer && ("pre" === i[1] || "script" === i[1] || "style" === i[1]),
								text: i[0]
							});
							else if (t && (i = this.rules.def.exec(e))) e = e.substring(i[0].length), i[3] && (i[3] = i[3].substring(1, i[3].length - 1)),
								d = i[1].toLowerCase().replace(/\s+/g, " "), this.tokens.links[d] || (this.tokens.links[d] = {
									href: i[2],
									title: i[3]
								});
							else if ((i = this.rules.table.exec(e)) && (l = {
									type: "table",
									header: x(i[1].replace(/^ *| *\| *$/g, "")),
									align: i[2].replace(/^ *|\| *$/g, "").split(/ *\| */),
									cells: i[3] ? i[3].replace(/\n$/, "").split("\n") : []
								}).header.length === l.align.length) {
								for (e = e.substring(i[0].length), f = 0; f < l.align.length; f++) /^ *-+: *$/.test(l.align[f]) ? l.align[f] = "right" :
									/^ *:-+: *$/.test(l.align[f]) ? l.align[f] = "center" : /^ *:-+ *$/.test(l.align[f]) ? l.align[f] = "left" : l.align[f] =
									null;
								for (f = 0; f < l.cells.length; f++) l.cells[f] = x(l.cells[f].replace(/^ *\| *| *\| *$/g, ""), l.header.length);
								this.tokens.push(l)
							} else if (i = this.rules.lheading.exec(e)) e = e.substring(i[0].length), this.tokens.push({
								type: "heading",
								depth: "=" === i[2] ? 1 : 2,
								text: i[1]
							});
							else if (t && (i = this.rules.paragraph.exec(e))) e = e.substring(i[0].length), this.tokens.push({
								type: "paragraph",
								text: "\n" === i[1].charAt(i[1].length - 1) ? i[1].slice(0, -1) : i[1]
							});
							else if (i = this.rules.text.exec(e)) e = e.substring(i[0].length), this.tokens.push({
								type: "text",
								text: i[0]
							});
							else if (e) throw new Error("Infinite loop on byte: " + e.charCodeAt(0));
							return this.tokens
						};
					var n = {
						escape: /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/,
						autolink: /^<(scheme:[^\s\x00-\x1f<>]*|email)>/,
						url: p,
						tag: "^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>",
						link: /^!?\[(label)\]\(href(?:\s+(title))?\s*\)/,
						reflink: /^!?\[(label)\]\[(?!\s*\])((?:\\[\[\]]?|[^\[\]\\])+)\]/,
						nolink: /^!?\[(?!\s*\])((?:\[[^\[\]]*\]|\\[\[\]]|[^\[\]])*)\](?:\[\])?/,
						strong: /^__([^\s_])__(?!_)|^\*\*([^\s*])\*\*(?!\*)|^__([^\s][\s\S]*?[^\s])__(?!_)|^\*\*([^\s][\s\S]*?[^\s])\*\*(?!\*)/,
						em: /^_([^\s_])_(?!_)|^\*([^\s*"<\[])\*(?!\*)|^_([^\s][\s\S]*?[^\s_])_(?!_|[^\spunctuation])|^_([^\s_][\s\S]*?[^\s])_(?!_|[^\spunctuation])|^\*([^\s"<\[][\s\S]*?[^\s*])\*(?!\*)|^\*([^\s*"<\[][\s\S]*?[^\s])\*(?!\*)/,
						code: /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/,
						br: /^( {2,}|\\)\n(?!\s*$)/,
						del: p,
						text: /^(`+|[^`])(?:[\s\S]*?(?:(?=[\\<!\[`*]|\b_|$)|[^ ](?= {2,}\n))|(?= {2,}\n))/
					};

					function c(e, t) {
						if (this.options = t || v.defaults, this.links = e, this.rules = n.normal, this.renderer = this.options.renderer || new r, this
							.renderer.options = this.options, !this.links) throw new Error("Tokens array requires a `links` property.");
						this.options.pedantic ? this.rules = n.pedantic : this.options.gfm && (this.options.breaks ? this.rules = n.breaks : this.rules =
							n.gfm)
					}

					function r(e) {
						this.options = e || v.defaults
					}

					function i() {}

					function u(e) {
						this.tokens = [], this.token = null, this.options = e || v.defaults, this.options.renderer = this.options.renderer || new r,
							this.renderer = this.options.renderer, this.renderer.options = this.options, this.slugger = new t
					}

					function t() {
						this.seen = {}
					}

					function h(e, t) {
						if (t) {
							if (h.escapeTest.test(e)) return e.replace(h.escapeReplace, function (e) {
								return h.replacements[e]
							})
						} else if (h.escapeTestNoEncode.test(e)) return e.replace(h.escapeReplaceNoEncode, function (e) {
							return h.replacements[e]
						});
						return e
					}

					function f(e) {
						return e.replace(/&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/gi, function (e, t) {
							return "colon" === (t = t.toLowerCase()) ? ":" : "#" === t.charAt(0) ? "x" === t.charAt(1) ? String.fromCharCode(parseInt(t.substring(
								2), 16)) : String.fromCharCode(+t.substring(1)) : ""
						})
					}

					function o(n, e) {
						return n = n.source || n, e = e || "", {
							replace: function (e, t) {
								return t = (t = t.source || t).replace(/(^|[^\[])\^/g, "$1"), n = n.replace(e, t), this
							},
							getRegex: function () {
								return new RegExp(n, e)
							}
						}
					}

					function a(e, t, n) {
						if (e) {
							try {
								var r = decodeURIComponent(f(n)).replace(/[^\w:]/g, "").toLowerCase()
							} catch (e) {
								return null
							}
							if (0 === r.indexOf("javascript:") || 0 === r.indexOf("vbscript:") || 0 === r.indexOf("data:")) return null
						}
						t && !d.test(n) && (n = function (e, t) {
							l[" " + e] || (/^[^:]+:\/*[^/]*$/.test(e) ? l[" " + e] = e + "/" : l[" " + e] = b(e, "/", !0));
							return e = l[" " + e], "//" === t.slice(0, 2) ? e.replace(/:[\s\S]*/, ":") + t : "/" === t.charAt(0) ? e.replace(
								/(:\/*[^/]*)[\s\S]*/, "$1") + t : e + t
						}(t, n));
						try {
							n = encodeURI(n).replace(/%25/g, "%")
						} catch (e) {
							return null
						}
						return n
					}
					n._punctuation = "!\"#$%&'()*+,\\-./:;<=>?@\\[^_{|}~", n.em = o(n.em).replace(/punctuation/g, n._punctuation).getRegex(), n._escapes =
						/\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/g, n._scheme = /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/, n._email =
						/[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/,
						n.autolink = o(n.autolink).replace("scheme", n._scheme).replace("email", n._email).getRegex(), n._attribute =
						/\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/, n.tag = o(n.tag).replace("comment", y._comment).replace(
							"attribute", n._attribute).getRegex(), n._label = /(?:\[[^\[\]]*\]|\\[\[\]]?|`[^`]*`|`(?!`)|[^\[\]\\`])*?/, n._href =
						/\s*(<(?:\\[<>]?|[^\s<>\\])*>|[^\s\x00-\x1f]*)/, n._title = /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/, n.link =
						o(n.link).replace("label", n._label).replace("href", n._href).replace("title", n._title).getRegex(), n.reflink = o(n.reflink).replace(
							"label", n._label).getRegex(), n.normal = m({}, n), n.pedantic = m({}, n.normal, {
							strong: /^__(?=\S)([\s\S]*?\S)__(?!_)|^\*\*(?=\S)([\s\S]*?\S)\*\*(?!\*)/,
							em: /^_(?=\S)([\s\S]*?\S)_(?!_)|^\*(?=\S)([\s\S]*?\S)\*(?!\*)/,
							link: o(/^!?\[(label)\]\((.*?)\)/).replace("label", n._label).getRegex(),
							reflink: o(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", n._label).getRegex()
						}), n.gfm = m({}, n.normal, {
							escape: o(n.escape).replace("])", "~|])").getRegex(),
							_extended_email: /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/,
							url: /^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/,
							_backpedal: /(?:[^?!.,:;*_~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_~)]+(?!$))+/,
							del: /^~+(?=\S)([\s\S]*?\S)~+/,
							text: /^(`+|[^`])(?:[\s\S]*?(?:(?=[\\<!\[`*~]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@))|(?= {2,}\n|[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@))/
						}), n.gfm.url = o(n.gfm.url, "i").replace("email", n.gfm._extended_email).getRegex(), n.breaks = m({}, n.gfm, {
							br: o(n.br).replace("{2,}", "*").getRegex(),
							text: o(n.gfm.text).replace(/\{2,\}/g, "*").getRegex()
						}), c.rules = n, c.output = function (e, t, n) {
							return new c(t, n).output(e)
						}, c.prototype.output = function (e) {
							for (var t, n, r, i, o, a, l = ""; e;)
								if (o = this.rules.escape.exec(e)) e = e.substring(o[0].length), l += h(o[1]);
								else if (o = this.rules.tag.exec(e)) !this.inLink && /^<a /i.test(o[0]) ? this.inLink = !0 : this.inLink && /^<\/a>/i.test(o[
									0]) && (this.inLink = !1), !this.inRawBlock && /^<(pre|code|kbd|script)(\s|>)/i.test(o[0]) ? this.inRawBlock = !0 : this.inRawBlock &&
								/^<\/(pre|code|kbd|script)(\s|>)/i.test(o[0]) && (this.inRawBlock = !1), e = e.substring(o[0].length), l += this.options.sanitize ?
								this.options.sanitizer ? this.options.sanitizer(o[0]) : h(o[0]) : o[0];
							else if (o = this.rules.link.exec(e)) {
								var s = g(o[2], "()");
								if (-1 < s) {
									var u = o[0].length - (o[2].length - s) - (o[3] || "").length;
									o[2] = o[2].substring(0, s), o[0] = o[0].substring(0, u).trim(), o[3] = ""
								}
								e = e.substring(o[0].length), this.inLink = !0, r = o[2], i = this.options.pedantic ? (t = /^([^'"]*[^\s])\s+(['"])(.*)\2/.exec(
									r)) ? (r = t[1], t[3]) : "" : o[3] ? o[3].slice(1, -1) : "", r = r.trim().replace(/^<([\s\S]*)>$/, "$1"), l += this.outputLink(
									o, {
										href: c.escapes(r),
										title: c.escapes(i)
									}), this.inLink = !1
							} else if ((o = this.rules.reflink.exec(e)) || (o = this.rules.nolink.exec(e))) {
								if (e = e.substring(o[0].length), t = (o[2] || o[1]).replace(/\s+/g, " "), !(t = this.links[t.toLowerCase()]) || !t.href) {
									l += o[0].charAt(0), e = o[0].substring(1) + e;
									continue
								}
								this.inLink = !0, l += this.outputLink(o, t), this.inLink = !1
							} else if (o = this.rules.strong.exec(e)) e = e.substring(o[0].length), l += this.renderer.strong(this.output(o[4] || o[3] ||
								o[2] || o[1]));
							else if (o = this.rules.em.exec(e)) e = e.substring(o[0].length), l += this.renderer.em(this.output(o[6] || o[5] || o[4] || o[
								3] || o[2] || o[1]));
							else if (o = this.rules.code.exec(e)) e = e.substring(o[0].length), l += this.renderer.codespan(h(o[2].trim(), !0));
							else if (o = this.rules.br.exec(e)) e = e.substring(o[0].length), l += this.renderer.br();
							else if (o = this.rules.del.exec(e)) e = e.substring(o[0].length), l += this.renderer.del(this.output(o[1]));
							else if (o = this.rules.autolink.exec(e)) e = e.substring(o[0].length), r = "@" === o[2] ? "mailto:" + (n = h(this.mangle(o[1]))) :
								n = h(o[1]), l += this.renderer.link(r, null, n);
							else if (this.inLink || !(o = this.rules.url.exec(e))) {
								if (o = this.rules.text.exec(e)) e = e.substring(o[0].length), this.inRawBlock ? l += this.renderer.text(o[0]) : l += this.renderer
									.text(h(this.smartypants(o[0])));
								else if (e) throw new Error("Infinite loop on byte: " + e.charCodeAt(0))
							} else {
								if ("@" === o[2]) r = "mailto:" + (n = h(o[0]));
								else {
									for (; a = o[0], o[0] = this.rules._backpedal.exec(o[0])[0], a !== o[0];);
									n = h(o[0]), r = "www." === o[1] ? "http://" + n : n
								}
								e = e.substring(o[0].length), l += this.renderer.link(r, null, n)
							}
							return l
						}, c.escapes = function (e) {
							return e ? e.replace(c.rules._escapes, "$1") : e
						}, c.prototype.outputLink = function (e, t) {
							var n = t.href,
								r = t.title ? h(t.title) : null;
							return "!" !== e[0].charAt(0) ? this.renderer.link(n, r, this.output(e[1])) : this.renderer.image(n, r, h(e[1]))
						}, c.prototype.smartypants = function (e) {
							return this.options.smartypants ? e.replace(/---/g, "—").replace(/--/g, "–").replace(/(^|[-\u2014/(\[{"\s])'/g, "$1‘").replace(
								/'/g, "’").replace(/(^|[-\u2014/(\[{\u2018\s])"/g, "$1“").replace(/"/g, "”").replace(/\.{3}/g, "…") : e
						}, c.prototype.mangle = function (e) {
							if (!this.options.mangle) return e;
							for (var t, n = "", r = e.length, i = 0; i < r; i++) t = e.charCodeAt(i), .5 < Math.random() && (t = "x" + t.toString(16)), n +=
								"&#" + t + ";";
							return n
						}, r.prototype.code = function (e, t, n) {
							var r = (t || "").match(/\S*/)[0];
							if (this.options.highlight) {
								var i = this.options.highlight(e, r);
								null != i && i !== e && (n = !0, e = i)
							}
							return r ? '<pre><code class="' + this.options.langPrefix + h(r, !0) + '">' + (n ? e : h(e, !0)) + "</code></pre>\n" :
								"<pre><code>" + (n ? e : h(e, !0)) + "</code></pre>"
						}, r.prototype.blockquote = function (e) {
							return "<blockquote>\n" + e + "</blockquote>\n"
						}, r.prototype.html = function (e) {
							return e
						}, r.prototype.heading = function (e, t, n, r) {
							return this.options.headerIds ? "<h" + t + ' id="' + this.options.headerPrefix + r.slug(n) + '">' + e + "</h" + t + ">\n" :
								"<h" + t + ">" + e + "</h" + t + ">\n"
						}, r.prototype.hr = function () {
							return this.options.xhtml ? "<hr/>\n" : "<hr>\n"
						}, r.prototype.list = function (e, t, n) {
							var r = t ? "ol" : "ul";
							return "<" + r + (t && 1 !== n ? ' start="' + n + '"' : "") + ">\n" + e + "</" + r + ">\n"
						}, r.prototype.listitem = function (e) {
							return "<li>" + e + "</li>\n"
						}, r.prototype.checkbox = function (e) {
							return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox"' + (this.options.xhtml ? " /" : "") + "> "
						}, r.prototype.paragraph = function (e) {
							return "<p>" + e + "</p>\n"
						}, r.prototype.table = function (e, t) {
							return t && (t = "<tbody>" + t + "</tbody>"), "<table>\n<thead>\n" + e + "</thead>\n" + t + "</table>\n"
						}, r.prototype.tablerow = function (e) {
							return "<tr>\n" + e + "</tr>\n"
						}, r.prototype.tablecell = function (e, t) {
							var n = t.header ? "th" : "td";
							return (t.align ? "<" + n + ' align="' + t.align + '">' : "<" + n + ">") + e + "</" + n + ">\n"
						}, r.prototype.strong = function (e) {
							return "<strong>" + e + "</strong>"
						}, r.prototype.em = function (e) {
							return "<em>" + e + "</em>"
						}, r.prototype.codespan = function (e) {
							return "<code>" + e + "</code>"
						}, r.prototype.br = function () {
							return this.options.xhtml ? "<br/>" : "<br>"
						}, r.prototype.del = function (e) {
							return "<del>" + e + "</del>"
						}, r.prototype.link = function (e, t, n) {
							if (null === (e = a(this.options.sanitize, this.options.baseUrl, e))) return n;
							var r = '<a href="' + h(e) + '"';
							return t && (r += ' title="' + t + '"'), r += ">" + n + "</a>"
						}, r.prototype.image = function (e, t, n) {
							if (null === (e = a(this.options.sanitize, this.options.baseUrl, e))) return n;
							var r = '<img src="' + e + '" alt="' + n + '"';
							return t && (r += ' title="' + t + '"'), r += this.options.xhtml ? "/>" : ">"
						}, r.prototype.text = function (e) {
							return e
						}, i.prototype.strong = i.prototype.em = i.prototype.codespan = i.prototype.del = i.prototype.text = function (e) {
							return e
						}, i.prototype.link = i.prototype.image = function (e, t, n) {
							return "" + n
						}, i.prototype.br = function () {
							return ""
						}, u.parse = function (e, t) {
							return new u(t).parse(e)
						}, u.prototype.parse = function (e) {
							this.inline = new c(e.links, this.options), this.inlineText = new c(e.links, m({}, this.options, {
								renderer: new i
							})), this.tokens = e.reverse();
							for (var t = ""; this.next();) t += this.tok();
							return t
						}, u.prototype.next = function () {
							return this.token = this.tokens.pop()
						}, u.prototype.peek = function () {
							return this.tokens[this.tokens.length - 1] || 0
						}, u.prototype.parseText = function () {
							for (var e = this.token.text;
								"text" === this.peek().type;) e += "\n" + this.next().text;
							return this.inline.output(e)
						}, u.prototype.tok = function () {
							switch (this.token.type) {
							case "space":
								return "";
							case "hr":
								return this.renderer.hr();
							case "heading":
								return this.renderer.heading(this.inline.output(this.token.text), this.token.depth, f(this.inlineText.output(this.token.text)),
									this.slugger);
							case "code":
								return this.renderer.code(this.token.text, this.token.lang, this.token.escaped);
							case "table":
								var e, t, n, r, i = "",
									o = "";
								for (n = "", e = 0; e < this.token.header.length; e++) n += this.renderer.tablecell(this.inline.output(this.token.header[e]), {
									header: !0,
									align: this.token.align[e]
								});
								for (i += this.renderer.tablerow(n), e = 0; e < this.token.cells.length; e++) {
									for (t = this.token.cells[e], n = "", r = 0; r < t.length; r++) n += this.renderer.tablecell(this.inline.output(t[r]), {
										header: !1,
										align: this.token.align[r]
									});
									o += this.renderer.tablerow(n)
								}
								return this.renderer.table(i, o);
							case "blockquote_start":
								for (o = "";
									"blockquote_end" !== this.next().type;) o += this.tok();
								return this.renderer.blockquote(o);
							case "list_start":
								o = "";
								for (var a = this.token.ordered, l = this.token.start;
									"list_end" !== this.next().type;) o += this.tok();
								return this.renderer.list(o, a, l);
							case "list_item_start":
								o = "";
								var s = this.token.loose,
									u = this.token.checked,
									c = this.token.task;
								for (this.token.task && (o += this.renderer.checkbox(u));
									"list_item_end" !== this.next().type;) o += s || "text" !== this.token.type ? this.tok() : this.parseText();
								return this.renderer.listitem(o, c, u);
							case "html":
								return this.renderer.html(this.token.text);
							case "paragraph":
								return this.renderer.paragraph(this.inline.output(this.token.text));
							case "text":
								return this.renderer.paragraph(this.parseText());
							default:
								var h = 'Token with "' + this.token.type + '" type was not found.';
								if (!this.options.silent) throw new Error(h);
								console.log(h)
							}
						}, t.prototype.slug = function (e) {
							var t = e.toLowerCase().trim().replace(/[\u2000-\u206F\u2E00-\u2E7F\\'!"#$%&()*+,./:;<=>?@[\]^`{|}~]/g, "").replace(/\s/g, "-");
							if (this.seen.hasOwnProperty(t))
								for (var n = t; this.seen[n]++, t = n + "-" + this.seen[n], this.seen.hasOwnProperty(t););
							return this.seen[t] = 0, t
						}, h.escapeTest = /[&<>"']/, h.escapeReplace = /[&<>"']/g, h.replacements = {
							"&": "&amp;",
							"<": "&lt;",
							">": "&gt;",
							'"': "&quot;",
							"'": "&#39;"
						}, h.escapeTestNoEncode = /[<>"']|&(?!#?\w+;)/, h.escapeReplaceNoEncode = /[<>"']|&(?!#?\w+;)/g;
					var l = {},
						d = /^$|^[a-z][a-z0-9+.-]*:|^[?#]/i;

					function p() {}

					function m(e) {
						for (var t, n, r = 1; r < arguments.length; r++)
							for (n in t = arguments[r]) Object.prototype.hasOwnProperty.call(t, n) && (e[n] = t[n]);
						return e
					}

					function x(e, t) {
						var n = e.replace(/\|/g, function (e, t, n) {
								for (var r = !1, i = t; 0 <= --i && "\\" === n[i];) r = !r;
								return r ? "|" : " |"
							}).split(/ \|/),
							r = 0;
						if (n.length > t) n.splice(t);
						else
							for (; n.length < t;) n.push("");
						for (; r < n.length; r++) n[r] = n[r].trim().replace(/\\\|/g, "|");
						return n
					}

					function b(e, t, n) {
						if (0 === e.length) return "";
						for (var r = 0; r < e.length;) {
							var i = e.charAt(e.length - r - 1);
							if (i !== t || n) {
								if (i === t || !n) break;
								r++
							} else r++
						}
						return e.substr(0, e.length - r)
					}

					function g(e, t) {
						if (-1 === e.indexOf(t[1])) return -1;
						for (var n = 0, r = 0; r < e.length; r++)
							if ("\\" === e[r]) r++;
							else if (e[r] === t[0]) n++;
						else if (e[r] === t[1] && --n < 0) return r;
						return -1
					}

					function v(e, n, r) {
						if (null == e) throw new Error("marked(): input parameter is undefined or null");
						if ("string" != typeof e) throw new Error("marked(): input parameter is of type " + Object.prototype.toString.call(e) +
							", string expected");
						if (r || "function" == typeof n) {
							r || (r = n, n = null);
							var i, o, a = (n = m({}, v.defaults, n || {})).highlight,
								t = 0;
							try {
								i = s.lex(e, n)
							} catch (e) {
								return r(e)
							}
							o = i.length;
							var l = function (t) {
								if (t) return n.highlight = a, r(t);
								var e;
								try {
									e = u.parse(i, n)
								} catch (e) {
									t = e
								}
								return n.highlight = a, t ? r(t) : r(null, e)
							};
							if (!a || a.length < 3) return l();
							if (delete n.highlight, !o) return l();
							for (; t < i.length; t++) ! function (n) {
								"code" !== n.type ? --o || l() : a(n.text, n.lang, function (e, t) {
									return e ? l(e) : null == t || t === n.text ? --o || l() : (n.text = t, n.escaped = !0, void(--o || l()))
								})
							}(i[t])
						} else try {
							return n && (n = m({}, v.defaults, n)), u.parse(s.lex(e, n), n)
						} catch (e) {
							if (e.message += "\nPlease report this to https://github.com/markedjs/marked.", (n || v.defaults).silent) return "<p>An error occurred:</p><pre>" +
								h(e.message + "", !0) + "</pre>";
							throw e
						}
					}
					p.exec = p, v.options = v.setOptions = function (e) {
							return m(v.defaults, e), v
						}, v.getDefaults = function () {
							return {
								baseUrl: null,
								breaks: !1,
								gfm: !0,
								headerIds: !0,
								headerPrefix: "",
								highlight: null,
								langPrefix: "language-",
								mangle: !0,
								pedantic: !1,
								renderer: new r,
								sanitize: !1,
								sanitizer: null,
								silent: !1,
								smartLists: !1,
								smartypants: !1,
								tables: !0,
								xhtml: !1
							}
						}, v.defaults = v.getDefaults(), v.Parser = u, v.parser = u.parse, v.Renderer = r, v.TextRenderer = i, v.Lexer = s, v.lexer = s
						.lex, v.InlineLexer = c, v.inlineLexer = c.output, v.Slugger = t, v.parse = v, void 0 !== w && "object" == typeof k ? w.exports =
						v : e.marked = v
				}(this || ("undefined" != typeof window ? window : e))
			}).call(this, "undefined" != typeof global ? global : "undefined" != typeof self ? self : "undefined" != typeof window ? window : {})
		}, {}],
		18: [function (c, t, e) {
			(function (u, p) {
				var e;
				! function () {
					"use strict";
					(e = function (e, i, o, a) {
						a = a || {}, this.dictionary = null, this.rules = {}, this.dictionaryTable = {}, this.compoundRules = [], this.compoundRuleCodes = {},
							this.replacementTable = [], this.flags = a.flags || {}, this.memoized = {}, this.loaded = !1;
						var t, l, s, u, c, h = this;

						function n(e, t) {
							var n = h._readFile(e, null, a.asyncLoad);
							a.asyncLoad ? n.then(function (e) {
								t(e)
							}) : t(n)
						}

						function r(e) {
							i = e, o && d()
						}

						function f(e) {
							o = e, i && d()
						}

						function d() {
							for (h.rules = h._parseAFF(i), h.compoundRuleCodes = {}, l = 0, u = h.compoundRules.length; l < u; l++) {
								var e = h.compoundRules[l];
								for (s = 0, c = e.length; s < c; s++) h.compoundRuleCodes[e[s]] = []
							}
							for (l in "ONLYINCOMPOUND" in h.flags && (h.compoundRuleCodes[h.flags.ONLYINCOMPOUND] = []), h.dictionaryTable = h._parseDIC(
									o), h.compoundRuleCodes) 0 === h.compoundRuleCodes[l].length && delete h.compoundRuleCodes[l];
							for (l = 0, u = h.compoundRules.length; l < u; l++) {
								var t = h.compoundRules[l],
									n = "";
								for (s = 0, c = t.length; s < c; s++) {
									var r = t[s];
									r in h.compoundRuleCodes ? n += "(" + h.compoundRuleCodes[r].join("|") + ")" : n += r
								}
								h.compoundRules[l] = new RegExp(n, "i")
							}
							h.loaded = !0, a.asyncLoad && a.loadedCallback && a.loadedCallback(h)
						}
						return e && (h.dictionary = e, i && o ? d() : "undefined" != typeof window && "chrome" in window && "extension" in window.chrome &&
							"getURL" in window.chrome.extension ? (t = a.dictionaryPath ? a.dictionaryPath : "typo/dictionaries", i || n(chrome.extension
								.getURL(t + "/" + e + "/" + e + ".aff"), r), o || n(chrome.extension.getURL(t + "/" + e + "/" + e + ".dic"), f)) : (t = a.dictionaryPath ?
								a.dictionaryPath : void 0 !== p ? p + "/dictionaries" : "./dictionaries", i || n(t + "/" + e + "/" + e + ".aff", r), o || n(
									t + "/" + e + "/" + e + ".dic", f))), this
					}).prototype = {
						load: function (e) {
							for (var t in e) e.hasOwnProperty(t) && (this[t] = e[t]);
							return this
						},
						_readFile: function (e, t, n) {
							if (t = t || "utf8", "undefined" != typeof XMLHttpRequest) {
								var r, i = new XMLHttpRequest;
								return i.open("GET", e, n), n && (r = new Promise(function (e, t) {
									i.onload = function () {
										200 === i.status ? e(i.responseText) : t(i.statusText)
									}, i.onerror = function () {
										t(i.statusText)
									}
								})), i.overrideMimeType && i.overrideMimeType("text/plain; charset=" + t), i.send(null), n ? r : i.responseText
							}
							if (void 0 !== c) {
								var o = c("fs");
								try {
									if (o.existsSync(e)) {
										var a = o.statSync(e),
											l = o.openSync(e, "r"),
											s = new u(a.size);
										return o.readSync(l, s, 0, s.length, null), s.toString(t, 0, s.length)
									}
									console.log("Path " + e + " does not exist.")
								} catch (e) {
									return console.log(e), ""
								}
							}
						},
						_parseAFF: function (e) {
							var t, n, r, i, o, a, l, s = {},
								u = (e = this._removeAffixComments(e)).split("\n");
							for (i = 0, a = u.length; i < a; i++) {
								var c = (t = u[i]).split(/\s+/),
									h = c[0];
								if ("PFX" == h || "SFX" == h) {
									var f = c[1],
										d = c[2],
										p = [];
									for (l = (o = i + 1) + (n = parseInt(c[3], 10)); o < l; o++) {
										var m = (r = u[o].split(/\s+/))[2],
											g = r[3].split("/"),
											v = g[0];
										"0" === v && (v = "");
										var y = this.parseRuleCodes(g[1]),
											x = r[4],
											b = {};
										b.add = v, 0 < y.length && (b.continuationClasses = y), "." !== x && (b.match = "SFX" === h ? new RegExp(x + "$") : new RegExp(
											"^" + x)), "0" != m && (b.remove = "SFX" === h ? new RegExp(m + "$") : m), p.push(b)
									}
									s[f] = {
										type: h,
										combineable: "Y" == d,
										entries: p
									}, i += n
								} else if ("COMPOUNDRULE" === h) {
									for (l = (o = i + 1) + (n = parseInt(c[1], 10)); o < l; o++) r = (t = u[o]).split(/\s+/), this.compoundRules.push(r[1]);
									i += n
								} else "REP" === h ? 3 === (r = t.split(/\s+/)).length && this.replacementTable.push([r[1], r[2]]) : this.flags[h] = c[1]
							}
							return s
						},
						_removeAffixComments: function (e) {
							return e = (e = (e = (e = e.replace(/^\s*#.*$/gm, "")).replace(/^\s\s*/m, "").replace(/\s\s*$/m, "")).replace(/\n{2,}/g,
								"\n")).replace(/^\s\s*/, "").replace(/\s\s*$/, "")
						},
						_parseDIC: function (e) {
							var t = (e = this._removeDicComments(e)).split("\n"),
								n = {};

							function r(e, t) {
								n.hasOwnProperty(e) || (n[e] = null), 0 < t.length && (null === n[e] && (n[e] = []), n[e].push(t))
							}
							for (var i = 1, o = t.length; i < o; i++) {
								var a = t[i].split("/", 2),
									l = a[0];
								if (1 < a.length) {
									var s = this.parseRuleCodes(a[1]);
									"NEEDAFFIX" in this.flags && -1 != s.indexOf(this.flags.NEEDAFFIX) || r(l, s);
									for (var u = 0, c = s.length; u < c; u++) {
										var h = s[u],
											f = this.rules[h];
										if (f)
											for (var d = this._applyRule(l, f), p = 0, m = d.length; p < m; p++) {
												var g = d[p];
												if (r(g, []), f.combineable)
													for (var v = u + 1; v < c; v++) {
														var y = s[v],
															x = this.rules[y];
														if (x && x.combineable && f.type != x.type)
															for (var b = this._applyRule(g, x), w = 0, k = b.length; w < k; w++) {
																r(b[w], [])
															}
													}
											}
										h in this.compoundRuleCodes && this.compoundRuleCodes[h].push(l)
									}
								} else r(l.trim(), [])
							}
							return n
						},
						_removeDicComments: function (e) {
							return e = e.replace(/^\t.*$/gm, "")
						},
						parseRuleCodes: function (e) {
							if (!e) return [];
							if (!("FLAG" in this.flags)) return e.split("");
							if ("long" !== this.flags.FLAG) return "num" === this.flags.FLAG ? e.split(",") : void 0;
							for (var t = [], n = 0, r = e.length; n < r; n += 2) t.push(e.substr(n, 2));
							return t
						},
						_applyRule: function (e, t) {
							for (var n = t.entries, r = [], i = 0, o = n.length; i < o; i++) {
								var a = n[i];
								if (!a.match || e.match(a.match)) {
									var l = e;
									if (a.remove && (l = l.replace(a.remove, "")), "SFX" === t.type ? l += a.add : l = a.add + l, r.push(l),
										"continuationClasses" in a)
										for (var s = 0, u = a.continuationClasses.length; s < u; s++) {
											var c = this.rules[a.continuationClasses[s]];
											c && (r = r.concat(this._applyRule(l, c)))
										}
								}
							}
							return r
						},
						check: function (e) {
							if (!this.loaded) throw "Dictionary not loaded.";
							var t = e.replace(/^\s\s*/, "").replace(/\s\s*$/, "");
							if (this.checkExact(t)) return !0;
							if (t.toUpperCase() === t) {
								var n = t[0] + t.substring(1).toLowerCase();
								if (this.hasFlag(n, "KEEPCASE")) return !1;
								if (this.checkExact(n)) return !0
							}
							var r = t.toLowerCase();
							if (r !== t) {
								if (this.hasFlag(r, "KEEPCASE")) return !1;
								if (this.checkExact(r)) return !0
							}
							return !1
						},
						checkExact: function (e) {
							if (!this.loaded) throw "Dictionary not loaded.";
							var t, n, r = this.dictionaryTable[e];
							if (void 0 === r) {
								if ("COMPOUNDMIN" in this.flags && e.length >= this.flags.COMPOUNDMIN)
									for (t = 0, n = this.compoundRules.length; t < n; t++)
										if (e.match(this.compoundRules[t])) return !0
							} else {
								if (null === r) return !0;
								if ("object" == typeof r)
									for (t = 0, n = r.length; t < n; t++)
										if (!this.hasFlag(e, "ONLYINCOMPOUND", r[t])) return !0
							}
							return !1
						},
						hasFlag: function (e, t, n) {
							if (!this.loaded) throw "Dictionary not loaded.";
							return !!(t in this.flags && (void 0 === n && (n = Array.prototype.concat.apply([], this.dictionaryTable[e])), n && -1 !== n
								.indexOf(this.flags[t])))
						},
						alphabet: "",
						suggest: function (e, c) {
							if (!this.loaded) throw "Dictionary not loaded.";
							if (c = c || 5, this.memoized.hasOwnProperty(e)) {
								var t = this.memoized[e].limit;
								if (c <= t || this.memoized[e].suggestions.length < t) return this.memoized[e].suggestions.slice(0, c)
							}
							if (this.check(e)) return [];
							for (var n = 0, r = this.replacementTable.length; n < r; n++) {
								var i = this.replacementTable[n];
								if (-1 !== e.indexOf(i[0])) {
									var o = e.replace(i[0], i[1]);
									if (this.check(o)) return [o]
								}
							}
							var h = this;

							function f(e) {
								var t, n, r, i, o, a, l = [];
								for (t = 0, i = e.length; t < i; t++) {
									var s = e[t];
									for (n = 0, o = s.length + 1; n < o; n++) {
										var u = [s.substring(0, n), s.substring(n)];
										if (u[1] && l.push(u[0] + u[1].substring(1)), 1 < u[1].length && u[1][1] !== u[1][0] && l.push(u[0] + u[1][1] + u[1][0] +
												u[1].substring(2)), u[1])
											for (r = 0, a = h.alphabet.length; r < a; r++) h.alphabet[r] != u[1].substring(0, 1) && l.push(u[0] + h.alphabet[r] + u[
												1].substring(1));
										if (u[1])
											for (r = 0, a = h.alphabet.length; r < a; r++) l.push(u[0] + h.alphabet[r] + u[1])
									}
								}
								return l
							}
							return h.alphabet = "abcdefghijklmnopqrstuvwxyz", this.memoized[e] = {
								suggestions: function (e) {
									var t, n, r = f([e]),
										i = f(r),
										o = function (e) {
											for (var t = [], n = 0, r = e.length; n < r; n++) h.check(e[n]) && t.push(e[n]);
											return t
										}(r.concat(i)),
										a = {};
									for (t = 0, n = o.length; t < n; t++) o[t] in a ? a[o[t]] += 1 : a[o[t]] = 1;
									var l = [];
									for (t in a) a.hasOwnProperty(t) && l.push([t, a[t]]);
									l.sort(function (e, t) {
										return e[1] < t[1] ? -1 : 1
									}).reverse();
									var s = [],
										u = "lowercase";
									for (e.toUpperCase() === e ? u = "uppercase" : e.substr(0, 1).toUpperCase() + e.substr(1).toLowerCase() === e && (u =
											"capitalized"), t = 0, n = Math.min(c, l.length); t < n; t++) "uppercase" === u ? l[t][0] = l[t][0].toUpperCase() :
										"capitalized" === u && (l[t][0] = l[t][0].substr(0, 1).toUpperCase() + l[t][0].substr(1)), h.hasFlag(l[t][0],
											"NOSUGGEST") || s.push(l[t][0]);
									return s
								}(e),
								limit: c
							}, this.memoized[e].suggestions
						}
					}
				}(), void 0 !== t && (t.exports = e)
			}).call(this, c("buffer").Buffer, "/node_modules/typo-js")
		}, {
			buffer: 3,
			fs: 2
		}],
		19: [function (e, t, n) {
			var r = e("codemirror");
			r.commands.tabAndIndentMarkdownList = function (e) {
				var t = e.listSelections()[0].head;
				if (!1 !== e.getStateAfter(t.line).list) e.execCommand("indentMore");
				else if (e.options.indentWithTabs) e.execCommand("insertTab");
				else {
					var n = Array(e.options.tabSize + 1).join(" ");
					e.replaceSelection(n)
				}
			}, r.commands.shiftTabAndUnindentMarkdownList = function (e) {
				var t = e.listSelections()[0].head;
				if (!1 !== e.getStateAfter(t.line).list) e.execCommand("indentLess");
				else if (e.options.indentWithTabs) e.execCommand("insertTab");
				else {
					var n = Array(e.options.tabSize + 1).join(" ");
					e.replaceSelection(n)
				}
			}
		}, {
			codemirror: 11
		}],
		20: [function (e, t, n) {
			"use strict";
			var u = e("codemirror");
			e("codemirror/addon/edit/continuelist.js"), e("./codemirror/tablist"), e("codemirror/addon/display/fullscreen.js"), e(
				"codemirror/mode/markdown/markdown.js"), e("codemirror/addon/mode/overlay.js"), e("codemirror/addon/display/placeholder.js"), e(
				"codemirror/addon/selection/mark-selection.js"), e("codemirror/addon/search/searchcursor.js"), e("codemirror/mode/gfm/gfm.js"), e(
				"codemirror/mode/xml/xml.js");
			var c = e("codemirror-spell-checker"),
				i = e("marked"),
				h = /Mac/.test(navigator.platform),
				o = new RegExp(/(<a.*?https?:\/\/.*?[^a]>)+?/g),
				f = {
					toggleBold: r,
					toggleItalic: s,
					drawLink: N,
					toggleHeadingSmaller: k,
					toggleHeadingBigger: C,
					drawImage: D,
					toggleBlockquote: w,
					toggleOrderedList: A,
					toggleUnorderedList: M,
					toggleCodeBlock: b,
					togglePreview: H,
					toggleStrikethrough: x,
					toggleHeading1: S,
					toggleHeading2: L,
					toggleHeading3: T,
					cleanBlock: E,
					drawTable: F,
					drawHorizontalRule: O,
					undo: I,
					redo: B,
					toggleSideBySide: R,
					toggleFullScreen: y
				},
				a = {
					toggleBold: "Cmd-B",
					toggleItalic: "Cmd-I",
					drawLink: "Cmd-K",
					toggleHeadingSmaller: "Cmd-H",
					toggleHeadingBigger: "Shift-Cmd-H",
					cleanBlock: "Cmd-E",
					drawImage: "Cmd-Alt-I",
					toggleBlockquote: "Cmd-'",
					toggleOrderedList: "Cmd-Alt-L",
					toggleUnorderedList: "Cmd-L",
					toggleCodeBlock: "Cmd-Alt-C",
					togglePreview: "Cmd-P",
					toggleSideBySide: "F9",
					toggleFullScreen: "F11"
				},
				d = function (e) {
					for (var t in f)
						if (f[t] === e) return t;
					return null
				},
				p = function () {
					var e, t = !1;
					return e = navigator.userAgent || navigator.vendor || window.opera, (
						/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i
						.test(e) ||
						/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw-(n|u)|c55\/|capi|ccwa|cdm-|cell|chtm|cldc|cmd-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc-s|devi|dica|dmob|do(c|p)o|ds(12|-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(-|_)|g1 u|g560|gene|gf-5|g-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd-(m|p|t)|hei-|hi(pt|ta)|hp( i|ip)|hs-c|ht(c(-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i-(20|go|ma)|i230|iac( |-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|-[a-w])|libw|lynx|m1-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|-([1-8]|c))|phil|pire|pl(ay|uc)|pn-2|po(ck|rt|se)|prox|psio|pt-g|qa-a|qc(07|12|21|32|60|-[2-7]|i-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h-|oo|p-)|sdk\/|se(c(-|0|1)|47|mc|nd|ri)|sgh-|shar|sie(-|m)|sk-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h-|v-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl-|tdg-|tel(i|m)|tim-|t-mo|to(pl|sh)|ts(70|m-|m3|m5)|tx-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas-|your|zeto|zte-/i
						.test(e.substr(0, 4))) && (t = !0), t
				};

			function m(e) {
				return e = h ? e.replace("Ctrl", "Cmd") : e.replace("Cmd", "Ctrl")
			}

			function g(e, t, n) {
				e = e || {};
				var r = document.createElement("button");
				r.className = e.name, r.setAttribute("type", "button"), t = null == t || t, e.name && e.name in n && (f[e.name] = e.action), e.title &&
					t && (r.title = function (e, t, n) {
						var r, i = e;
						t && (r = d(t), n[r] && (i += " (" + m(n[r]) + ")"));
						return i
					}(e.title, e.action, n), h && (r.title = r.title.replace("Ctrl", "⌘"), r.title = r.title.replace("Alt", "⌥"))), e.noDisable && r.classList
					.add("no-disable"), e.noMobile && r.classList.add("no-mobile");
				for (var i = e.className.split(" "), o = [], a = 0; a < i.length; a++) {
					var l = i[a];
					l.match(/^fa([srlb]|(-[\w-]*)|$)/) ? o.push(l) : r.classList.add(l)
				}
				r.tabIndex = -1;
				for (var s = document.createElement("i"), u = 0; u < o.length; u++) {
					var c = o[u];
					s.classList.add(c)
				}
				return r.appendChild(s), r
			}

			function v(e, t) {
				t = t || e.getCursor("start");
				var n = e.getTokenAt(t);
				if (!n.type) return {};
				for (var r, i, o = n.type.split(" "), a = {}, l = 0; l < o.length; l++) "strong" === (r = o[l]) ? a.bold = !0 : "variable-2" === r ?
					(i = e.getLine(t.line), /^\s*\d+\.\s/.test(i) ? a["ordered-list"] = !0 : a["unordered-list"] = !0) : "atom" === r ? a.quote = !0 :
					"em" === r ? a.italic = !0 : "quote" === r ? a.quote = !0 : "strikethrough" === r ? a.strikethrough = !0 : "comment" === r ? a.code = !
					0 : "link" === r ? a.link = !0 : "tag" === r ? a.image = !0 : r.match(/^header(-[1-6])?$/) && (a[r.replace("header", "heading")] = !
						0);
				return a
			}
			var l = "";

			function y(e) {
				var t = e.codemirror;
				t.setOption("fullScreen", !t.getOption("fullScreen")), t.getOption("fullScreen") ? (l = document.body.style.overflow, document.body
					.style.overflow = "hidden") : document.body.style.overflow = l;
				var n = t.getWrapperElement();
				if (/fullscreen/.test(n.previousSibling.className) ? n.previousSibling.className = n.previousSibling.className.replace(
						/\s*fullscreen\b/, "") : n.previousSibling.className += " fullscreen", e.toolbarElements && e.toolbarElements.fullscreen) {
					var r = e.toolbarElements.fullscreen;
					/active/.test(r.className) ? r.className = r.className.replace(/\s*active\s*/g, "") : r.className += " active"
				}
				var i = t.getWrapperElement().nextSibling;
				/editor-preview-active-side/.test(i.className) && R(e), e.options.onToggleFullScreen && e.options.onToggleFullScreen(t.getOption(
					"fullScreen") || !1)
			}

			function r(e) {
				W(e, "bold", e.options.blockStyles.bold)
			}

			function s(e) {
				W(e, "italic", e.options.blockStyles.italic)
			}

			function x(e) {
				W(e, "strikethrough", "~~")
			}

			function b(e) {
				var t = e.options.blockStyles.code;

				function a(e) {
					if ("object" != typeof e) throw "fencing_line() takes a 'line' object (not a line number, or line text).  Got: " + typeof e +
						": " + e;
					return e.styles && e.styles[2] && -1 !== e.styles[2].indexOf("formatting-code-block")
				}

				function l(e) {
					return e.state.base.base || e.state.base
				}

				function n(e, t, n, r, i) {
					n = n || e.getLineHandle(t), r = r || e.getTokenAt({
						line: t,
						ch: 1
					}), i = i || !!n.text && e.getTokenAt({
						line: t,
						ch: n.text.length - 1
					});
					var o = r.type ? r.type.split(" ") : [];
					return i && l(i).indentedCode ? "indented" : -1 !== o.indexOf("comment") && (l(r).fencedChars || l(i).fencedChars || a(n) ?
						"fenced" : "single")
				}
				var r, i, o, s, u, c, h, f, d, p, m, g, v = e.codemirror,
					y = v.getCursor("start"),
					x = v.getCursor("end"),
					b = v.getTokenAt({
						line: y.line,
						ch: y.ch || 1
					}),
					w = v.getLineHandle(y.line),
					k = n(v, y.line, w, b);
				if ("single" === k) {
					var C = w.text.slice(0, y.ch).replace("`", ""),
						S = w.text.slice(y.ch).replace("`", "");
					v.replaceRange(C + S, {
						line: y.line,
						ch: 0
					}, {
						line: y.line,
						ch: 99999999999999
					}), y.ch--, y !== x && x.ch--, v.setSelection(y, x), v.focus()
				} else if ("fenced" === k)
					if (y.line !== x.line || y.ch !== x.ch) {
						for (r = y.line; 0 <= r && !a(w = v.getLineHandle(r)); r--);
						var L, T, M, A, E = l(v.getTokenAt({
							line: r,
							ch: 1
						})).fencedChars;
						T = a(v.getLineHandle(y.line)) ? (L = "", y.line) : a(v.getLineHandle(y.line - 1)) ? (L = "", y.line - 1) : (L = E + "\n", y.line),
							a(v.getLineHandle(x.line)) ? (M = "", A = x.line, 0 === x.ch && (A += 1)) : A = (M = 0 !== x.ch && a(v.getLineHandle(x.line + 1)) ?
								"" : E + "\n", x.line + 1), 0 === x.ch && (A -= 1), v.operation(function () {
								v.replaceRange(M, {
									line: A,
									ch: 0
								}, {
									line: A + (M ? 0 : 1),
									ch: 0
								}), v.replaceRange(L, {
									line: T,
									ch: 0
								}, {
									line: T + (L ? 0 : 1),
									ch: 0
								})
							}), v.setSelection({
								line: T + (L ? 1 : 0),
								ch: 0
							}, {
								line: A + (L ? 1 : -1),
								ch: 0
							}), v.focus()
					} else {
						var N = y.line;
						if (a(v.getLineHandle(y.line)) && (N = "fenced" === n(v, y.line + 1) ? (r = y.line, y.line + 1) : (i = y.line, y.line - 1)),
							void 0 === r)
							for (r = N; 0 <= r && !a(w = v.getLineHandle(r)); r--);
						if (void 0 === i)
							for (o = v.lineCount(), i = N; i < o && !a(w = v.getLineHandle(i)); i++);
						v.operation(function () {
							v.replaceRange("", {
								line: r,
								ch: 0
							}, {
								line: r + 1,
								ch: 0
							}), v.replaceRange("", {
								line: i - 1,
								ch: 0
							}, {
								line: i,
								ch: 0
							})
						}), v.focus()
					}
				else if ("indented" === k) {
					if (y.line !== x.line || y.ch !== x.ch) r = y.line, i = x.line, 0 === x.ch && i--;
					else {
						for (r = y.line; 0 <= r; r--)
							if (!(w = v.getLineHandle(r)).text.match(/^\s*$/) && "indented" !== n(v, r, w)) {
								r += 1;
								break
							}
						for (o = v.lineCount(), i = y.line; i < o; i++)
							if (!(w = v.getLineHandle(i)).text.match(/^\s*$/) && "indented" !== n(v, i, w)) {
								i -= 1;
								break
							}
					}
					var D = v.getLineHandle(i + 1),
						F = D && v.getTokenAt({
							line: i + 1,
							ch: D.text.length - 1
						});
					F && l(F).indentedCode && v.replaceRange("\n", {
						line: i + 1,
						ch: 0
					});
					for (var O = r; O <= i; O++) v.indentLine(O, "subtract");
					v.focus()
				} else {
					var I = y.line === x.line && y.ch === x.ch && 0 === y.ch,
						B = y.line !== x.line;
					I || B ? (s = v, c = x, h = t, f = (u = y).line + 1, d = c.line + 1, p = u.line !== c.line, m = h + "\n", g = "\n" + h, p && d++,
						p && 0 === c.ch && (g = h + "\n", d--), z(s, !1, [m, g]), s.setSelection({
							line: f,
							ch: 0
						}, {
							line: d,
							ch: 0
						})) : z(v, !1, ["`", "`"])
				}
			}

			function w(e) {
				_(e.codemirror, "quote")
			}

			function k(e) {
				P(e.codemirror, "smaller")
			}

			function C(e) {
				P(e.codemirror, "bigger")
			}

			function S(e) {
				P(e.codemirror, void 0, 1)
			}

			function L(e) {
				P(e.codemirror, void 0, 2)
			}

			function T(e) {
				P(e.codemirror, void 0, 3)
			}

			function M(e) {
				_(e.codemirror, "unordered-list")
			}

			function A(e) {
				_(e.codemirror, "ordered-list")
			}

			function E(e) {
				! function (e) {
					if (/editor-preview-active/.test(e.getWrapperElement().lastChild.className)) return;
					for (var t, n = e.getCursor("start"), r = e.getCursor("end"), i = n.line; i <= r.line; i++) t = (t = e.getLine(i)).replace(
						/^[ ]*([# ]+|\*|-|[> ]+|[0-9]+(.|\)))[ ]*/, ""), e.replaceRange(t, {
						line: i,
						ch: 0
					}, {
						line: i,
						ch: 99999999999999
					})
				}(e.codemirror)
			}

			function N(e) {
				var t = e.codemirror,
					n = v(t),
					r = e.options,
					i = "https://";
				if (r.promptURLs && !(i = prompt(r.promptTexts.link, "https://"))) return !1;
				z(t, n.link, r.insertTexts.link, i)
			}

			function D(e) {
				var t = e.codemirror,
					n = v(t),
					r = e.options,
					i = "https://";
				if (r.promptURLs && !(i = prompt(r.promptTexts.image, "https://"))) return !1;
				z(t, n.image, r.insertTexts.image, i)
			}

			function F(e) {
				var t = e.codemirror,
					n = v(t),
					r = e.options;
				z(t, n.table, r.insertTexts.table)
			}

			function O(e) {
				var t = e.codemirror,
					n = v(t),
					r = e.options;
				z(t, n.image, r.insertTexts.horizontalRule)
			}

			function I(e) {
				var t = e.codemirror;
				t.undo(), t.focus()
			}

			function B(e) {
				var t = e.codemirror;
				t.redo(), t.focus()
			}

			function R(e) {
				var t = e.codemirror,
					n = t.getWrapperElement(),
					r = n.nextSibling,
					i = e.toolbarElements && e.toolbarElements["side-by-side"],
					o = !1;
				/editor-preview-active-side/.test(r.className) ? (r.className = r.className.replace(/\s*editor-preview-active-side\s*/g, ""), i &&
					(i.className = i.className.replace(/\s*active\s*/g, "")), n.className = n.className.replace(/\s*CodeMirror-sided\s*/g, " ")) : (
					setTimeout(function () {
						t.getOption("fullScreen") || y(e), r.className += " editor-preview-active-side"
					}, 1), i && (i.className += " active"), n.className += " CodeMirror-sided", o = !0);
				var a = n.lastChild;
				if (/editor-preview-active/.test(a.className)) {
					a.className = a.className.replace(/\s*editor-preview-active\s*/g, "");
					var l = e.toolbarElements.preview,
						s = n.previousSibling;
					l.className = l.className.replace(/\s*active\s*/g, ""), s.className = s.className.replace(/\s*disabled-for-preview*/g, "")
				}
				t.sideBySideRenderingFunction || (t.sideBySideRenderingFunction = function () {
						r.innerHTML = e.options.previewRender(e.value(), r)
					}), o ? (r.innerHTML = e.options.previewRender(e.value(), r), t.on("update", t.sideBySideRenderingFunction)) : t.off("update", t.sideBySideRenderingFunction),
					t.refresh()
			}

			function H(e) {
				var t = e.codemirror,
					n = t.getWrapperElement(),
					r = n.previousSibling,
					i = !!e.options.toolbar && e.toolbarElements.preview,
					o = n.lastChild;
				o && /editor-preview/.test(o.className) || ((o = document.createElement("div")).className = "editor-preview", n.appendChild(o)),
					/editor-preview-active/.test(o.className) ? (o.className = o.className.replace(/\s*editor-preview-active\s*/g, ""), i && (i.className =
						i.className.replace(/\s*active\s*/g, ""), r.className = r.className.replace(/\s*disabled-for-preview*/g, ""))) : (setTimeout(
						function () {
							o.className += " editor-preview-active"
						}, 1), i && (i.className += " active", r.className += " disabled-for-preview")), o.innerHTML = e.options.previewRender(e.value(),
						o);
				var a = t.getWrapperElement().nextSibling;
				/editor-preview-active-side/.test(a.className) && R(e)
			}

			function z(e, t, n, r) {
				if (!/editor-preview-active/.test(e.getWrapperElement().lastChild.className)) {
					var i, o = n[0],
						a = n[1],
						l = {},
						s = {};
					Object.assign(l, e.getCursor("start")), Object.assign(s, e.getCursor("end")), r && (a = a.replace("#url#", r)), t ? (o = (i = e.getLine(
						l.line)).slice(0, l.ch), a = i.slice(l.ch), e.replaceRange(o + a, {
						line: l.line,
						ch: 0
					})) : (i = e.getSelection(), e.replaceSelection(o + i + a), l.ch += o.length, l !== s && (s.ch += o.length)), e.setSelection(l,
						s), e.focus()
				}
			}

			function P(e, t, n) {
				if (!/editor-preview-active/.test(e.getWrapperElement().lastChild.className)) {
					for (var r, i, o, a = e.getCursor("start"), l = e.getCursor("end"), s = a.line; s <= l.line; s++) r = s, i = void 0, i = e.getLine(
							r), o = i.search(/[^#]/), i = void 0 !== t ? o <= 0 ? "bigger" == t ? "###### " + i : "# " + i : 6 == o && "smaller" == t ? i.substr(
							7) : 1 == o && "bigger" == t ? i.substr(2) : "bigger" == t ? i.substr(1) : "#" + i : 1 == n ? o <= 0 ? "# " + i : o == n ? i.substr(
							o + 1) : "# " + i.substr(o + 1) : 2 == n ? o <= 0 ? "## " + i : o == n ? i.substr(o + 1) : "## " + i.substr(o + 1) : o <= 0 ?
						"### " + i : o == n ? i.substr(o + 1) : "### " + i.substr(o + 1), e.replaceRange(i, {
							line: r,
							ch: 0
						}, {
							line: r,
							ch: 99999999999999
						});
					e.focus()
				}
			}

			function _(s, u) {
				if (!/editor-preview-active/.test(s.getWrapperElement().lastChild.className)) {
					for (var c = /^(\s*)(\*|-|\+|\d*\.)(\s+)/, h = /^\s*/, f = v(s), e = s.getCursor("start"), t = s.getCursor("end"), d = {
							quote: /^(\s*)>\s+/,
							"unordered-list": c,
							"ordered-list": c
						}, p = 1, n = e.line; n <= t.line; n++) ! function (e) {
						var t, n, r, i, o = s.getLine(e);
						if (f[u]) o = o.replace(d[u], "$1");
						else {
							var a = c.exec(o),
								l = (i = p, {
									quote: ">",
									"unordered-list": "*",
									"ordered-list": "%%i."
								}[u].replace("%%i", i));
							o = null !== a ? (t = u, n = a[2], r = new RegExp({
								quote: ">",
								"unordered-list": "*",
								"ordered-list": "d+."
							}[t]), n && r.test(n) && (l = ""), a[1] + l + a[3] + o.replace(h, "").replace(d[u], "$1")) : l + " " + o, p += 1
						}
						s.replaceRange(o, {
							line: e,
							ch: 0
						}, {
							line: e,
							ch: 99999999999999
						})
					}(n);
					s.focus()
				}
			}

			function W(e, t, n, r) {
				if (!/editor-preview-active/.test(e.codemirror.getWrapperElement().lastChild.className)) {
					r = void 0 === r ? n : r;
					var i, o = e.codemirror,
						a = v(o),
						l = n,
						s = r,
						u = o.getCursor("start"),
						c = o.getCursor("end");
					a[t] ? (l = (i = o.getLine(u.line)).slice(0, u.ch), s = i.slice(u.ch), "bold" == t ? (l = l.replace(
						/(\*\*|__)(?![\s\S]*(\*\*|__))/, ""), s = s.replace(/(\*\*|__)/, "")) : "italic" == t ? (l = l.replace(
						/(\*|_)(?![\s\S]*(\*|_))/, ""), s = s.replace(/(\*|_)/, "")) : "strikethrough" == t && (l = l.replace(
						/(\*\*|~~)(?![\s\S]*(\*\*|~~))/, ""), s = s.replace(/(\*\*|~~)/, "")), o.replaceRange(l + s, {
						line: u.line,
						ch: 0
					}, {
						line: u.line,
						ch: 99999999999999
					}), "bold" == t || "strikethrough" == t ? (u.ch -= 2, u !== c && (c.ch -= 2)) : "italic" == t && (u.ch -= 1, u !== c && (c.ch -=
						1))) : (i = o.getSelection(), "bold" == t ? i = (i = i.split("**").join("")).split("__").join("") : "italic" == t ? i = (i = i.split(
							"*").join("")).split("_").join("") : "strikethrough" == t && (i = i.split("~~").join("")), o.replaceSelection(l + i + s), u.ch +=
						n.length, c.ch = u.ch + i.length), o.setSelection(u, c), o.focus()
				}
			}

			function j(e, t) {
				for (var n in t) t.hasOwnProperty(n) && (t[n] instanceof Array ? e[n] = t[n].concat(e[n] instanceof Array ? e[n] : []) : null !==
					t[n] && "object" == typeof t[n] && t[n].constructor === Object ? e[n] = j(e[n] || {}, t[n]) : e[n] = t[n]);
				return e
			}

			function U(e) {
				for (var t = 1; t < arguments.length; t++) e = j(e, arguments[t]);
				return e
			}

			function q(e) {
				var t = e.match(
						/[a-zA-Z0-9_\u00A0-\u02AF\u0392-\u03c9\u0410-\u04F9]+|[\u4E00-\u9FFF\u3400-\u4dbf\uf900-\ufaff\u3040-\u309f\uac00-\ud7af]+/g),
					n = 0;
				if (null === t) return n;
				for (var r = 0; r < t.length; r++) 19968 <= t[r].charCodeAt(0) ? n += t[r].length : n += 1;
				return n
			}
			var $ = {
					bold: {
						name: "bold",
						action: r,
						className: "fa fa-bold",
						title: "Bold",
						default: !0
					},
					italic: {
						name: "italic",
						action: s,
						className: "fa fa-italic",
						title: "Italic",
						default: !0
					},
					strikethrough: {
						name: "strikethrough",
						action: x,
						className: "fa fa-strikethrough",
						title: "Strikethrough"
					},
					heading: {
						name: "heading",
						action: k,
						className: "fa fa-header fa-heading",
						title: "Heading",
						default: !0
					},
					"heading-smaller": {
						name: "heading-smaller",
						action: k,
						className: "fa fa-header fa-heading header-smaller",
						title: "Smaller Heading"
					},
					"heading-bigger": {
						name: "heading-bigger",
						action: C,
						className: "fa fa-header fa-heading header-bigger",
						title: "Bigger Heading"
					},
					"heading-1": {
						name: "heading-1",
						action: S,
						className: "fa fa-header fa-heading header-1",
						title: "Big Heading"
					},
					"heading-2": {
						name: "heading-2",
						action: L,
						className: "fa fa-header fa-heading header-2",
						title: "Medium Heading"
					},
					"heading-3": {
						name: "heading-3",
						action: T,
						className: "fa fa-header fa-heading header-3",
						title: "Small Heading"
					},
					"separator-1": {
						name: "separator-1"
					},
					code: {
						name: "code",
						action: b,
						className: "fa fa-code",
						title: "Code"
					},
					quote: {
						name: "quote",
						action: w,
						className: "fa fa-quote-left",
						title: "Quote",
						default: !0
					},
					"unordered-list": {
						name: "unordered-list",
						action: M,
						className: "fa fa-list-ul",
						title: "Generic List",
						default: !0
					},
					"ordered-list": {
						name: "ordered-list",
						action: A,
						className: "fa fa-list-ol",
						title: "Numbered List",
						default: !0
					},
					"clean-block": {
						name: "clean-block",
						action: E,
						className: "fa fa-eraser",
						title: "Clean block"
					},
					"separator-2": {
						name: "separator-2"
					},
					link: {
						name: "link",
						action: N,
						className: "fa fa-link",
						title: "Create Link",
						default: !0
					},
					image: {
						name: "image",
						action: D,
						className: "fa fa-image",
						title: "Insert Image",
						default: !0
					},
					table: {
						name: "table",
						action: F,
						className: "fa fa-table",
						title: "Insert Table"
					},
					"horizontal-rule": {
						name: "horizontal-rule",
						action: O,
						className: "fa fa-minus",
						title: "Insert Horizontal Line"
					},
					"separator-3": {
						name: "separator-3"
					},
					preview: {
						name: "preview",
						action: H,
						className: "fa fa-eye",
						noDisable: !0,
						title: "Toggle Preview",
						default: !0
					},
					"side-by-side": {
						name: "side-by-side",
						action: R,
						className: "fa fa-columns",
						noDisable: !0,
						noMobile: !0,
						title: "Toggle Side by Side",
						default: !0
					},
					fullscreen: {
						name: "fullscreen",
						action: y,
						className: "fa fa-arrows-alt",
						noDisable: !0,
						noMobile: !0,
						title: "Toggle Fullscreen",
						default: !0
					},
					"separator-4": {
						name: "separator-4"
					},
					guide: {
						name: "guide",
						action: "https://www.markdownguide.org/basic-syntax/",
						className: "fa fa-question-circle",
						noDisable: !0,
						title: "Markdown Guide",
						default: !0
					},
					"separator-5": {
						name: "separator-5"
					},
					undo: {
						name: "undo",
						action: I,
						className: "fa fa-undo",
						noDisable: !0,
						title: "Undo"
					},
					redo: {
						name: "redo",
						action: B,
						className: "fa fa-repeat fa-redo",
						noDisable: !0,
						title: "Redo"
					}
				},
				G = {
					link: ["[", "](#url#)"],
					image: ["![](", "#url#)"],
					table: ["", "\n\n| Column 1 | Column 2 | Column 3 |\n| -------- | -------- | -------- |\n| Text     | Text     | Text     |\n\n"],
					horizontalRule: ["", "\n\n-----\n\n"]
				},
				V = {
					link: "URL for the link:",
					image: "URL of the image:"
				},
				X = {
					bold: "**",
					code: "```",
					italic: "*"
				};

			function K(e) {
				(e = e || {}).parent = this;
				var t = !0;
				if (!1 === e.autoDownloadFontAwesome && (t = !1), !0 !== e.autoDownloadFontAwesome)
					for (var n = document.styleSheets, r = 0; r < n.length; r++) n[r].href && -1 < n[r].href.indexOf(
						"//maxcdn.bootstrapcdn.com/font-awesome/") && (t = !1);
				if (t) {
					var i = document.createElement("link");
					i.rel = "stylesheet", i.href = "https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css", document.getElementsByTagName(
						"head")[0].appendChild(i)
				}
				if (e.element) this.element = e.element;
				else if (null === e.element) return void console.log("EasyMDE: Error. No element was found.");
				if (void 0 === e.toolbar)
					for (var o in e.toolbar = [], $) $.hasOwnProperty(o) && (-1 != o.indexOf("separator-") && e.toolbar.push("|"), (!0 === $[o].default ||
						e.showIcons && e.showIcons.constructor === Array && -1 != e.showIcons.indexOf(o)) && e.toolbar.push(o));
				e.hasOwnProperty("status") || (e.status = ["autosave", "lines", "words", "cursor"]), e.previewRender || (e.previewRender =
						function (e) {
							return this.parent.markdown(e)
						}), e.parsingConfig = U({
						highlightFormatting: !0
					}, e.parsingConfig || {}), e.insertTexts = U({}, G, e.insertTexts || {}), e.promptTexts = U({}, V, e.promptTexts || {}), e.blockStyles =
					U({}, X, e.blockStyles || {}), e.shortcuts = U({}, a, e.shortcuts || {}), e.minHeight = e.minHeight || "300px", null != e.autosave &&
					null != e.autosave.unique_id && "" != e.autosave.unique_id && (e.autosave.uniqueId = e.autosave.unique_id), this.options = e,
					this.render(), !e.initialValue || this.options.autosave && !0 === this.options.autosave.foundSavedValue || this.value(e.initialValue)
			}

			function Z() {
				if ("object" != typeof localStorage) return !1;
				try {
					localStorage.setItem("smde_localStorage", 1), localStorage.removeItem("smde_localStorage")
				} catch (e) {
					return !1
				}
				return !0
			}
			K.prototype.markdown = function (e) {
					if (i) {
						var t;
						if (t = this.options && this.options.renderingConfig && this.options.renderingConfig.markedOptions ? this.options.renderingConfig
							.markedOptions : {}, this.options && this.options.renderingConfig && !1 === this.options.renderingConfig.singleLineBreaks ? t.breaks = !
							1 : t.breaks = !0, this.options && this.options.renderingConfig && !0 === this.options.renderingConfig.codeSyntaxHighlighting) {
							var n = this.options.renderingConfig.hljs || window.hljs;
							n && (t.highlight = function (e) {
								return n.highlightAuto(e).value
							})
						}
						i.setOptions(t);
						var r = i(e);
						return r = function (e) {
							for (var t; null !== (t = o.exec(e));) {
								var n = t[0];
								if (-1 === n.indexOf("target=")) {
									var r = n.replace(/>$/, ' target="_blank">');
									e = e.replace(n, r)
								}
							}
							return e
						}(r)
					}
				}, K.prototype.render = function (e) {
					if (e || (e = this.element || document.getElementsByTagName("textarea")[0]), !this._rendered || this._rendered !== e) {
						this.element = e;
						var t, n, r = this.options,
							i = this,
							o = {};
						for (var a in r.shortcuts) null !== r.shortcuts[a] && null !== f[a] && function (t) {
							o[m(r.shortcuts[t])] = function () {
								var e = f[t];
								"function" == typeof e ? e(i) : "string" == typeof e && window.open(e, "_blank")
							}
						}(a);
						if (o.Enter = "newlineAndIndentContinueMarkdownList", o.Tab = "tabAndIndentMarkdownList", o["Shift-Tab"] =
							"shiftTabAndUnindentMarkdownList", o.Esc = function (e) {
								e.getOption("fullScreen") && y(i)
							}, document.addEventListener("keydown", function (e) {
								27 == (e = e || window.event).keyCode && i.codemirror.getOption("fullScreen") && y(i)
							}, !1), !1 !== r.spellChecker ? (t = "spell-checker", (n = r.parsingConfig).name = "gfm", n.gitHubSpice = !1, c({
								codeMirrorInstance: u
							})) : ((t = r.parsingConfig).name = "gfm", t.gitHubSpice = !1), this.codemirror = u.fromTextArea(e, {
								mode: t,
								backdrop: n,
								theme: null != r.theme ? r.theme : "easymde",
								tabSize: null != r.tabSize ? r.tabSize : 2,
								indentUnit: null != r.tabSize ? r.tabSize : 2,
								indentWithTabs: !1 !== r.indentWithTabs,
								lineNumbers: !1,
								autofocus: !0 === r.autofocus,
								extraKeys: o,
								lineWrapping: !1 !== r.lineWrapping,
								allowDropFileTypes: ["text/plain"],
								placeholder: r.placeholder || e.getAttribute("placeholder") || "",
								styleSelectedText: null != r.styleSelectedText ? r.styleSelectedText : !p(),
								configureMouse: function (e, t, n) {
									return {
										addNew: !1
									}
								}
							}), this.codemirror.getScrollerElement().style.minHeight = r.minHeight, !0 === r.forceSync) {
							var l = this.codemirror;
							l.on("change", function () {
								l.save()
							})
						}!(this.gui = {}) !== r.toolbar && (this.gui.toolbar = this.createToolbar()), !1 !== r.status && (this.gui.statusbar = this.createStatusbar()),
							null != r.autosave && !0 === r.autosave.enabled && this.autosave(), this.gui.sideBySide = this.createSideBySide(), this._rendered =
							this.element;
						var s = this.codemirror;
						setTimeout(function () {
							s.refresh()
						}.bind(s), 0)
					}
				}, K.prototype.autosave = function () {
					if (Z()) {
						var e = this;
						if (null == this.options.autosave.uniqueId || "" == this.options.autosave.uniqueId) return void console.log(
							"EasyMDE: You must set a uniqueId to use the autosave feature");
						!0 !== this.options.autosave.binded && (null != e.element.form && null != e.element.form && e.element.form.addEventListener(
							"submit",
							function () {
								clearTimeout(e.autosaveTimeoutId), e.autosaveTimeoutId = void 0, localStorage.removeItem("smde_" + e.options.autosave.uniqueId),
									setTimeout(function () {
										e.autosave()
									}, e.options.autosave.delay || 1e4)
							}), this.options.autosave.binded = !0), !0 !== this.options.autosave.loaded && ("string" == typeof localStorage.getItem(
								"smde_" + this.options.autosave.uniqueId) && "" != localStorage.getItem("smde_" + this.options.autosave.uniqueId) && (this.codemirror
								.setValue(localStorage.getItem("smde_" + this.options.autosave.uniqueId)), this.options.autosave.foundSavedValue = !0), this.options
							.autosave.loaded = !0), localStorage.setItem("smde_" + this.options.autosave.uniqueId, e.value());
						var t = document.getElementById("autosaved");
						if (null != t && null != t && "" != t) {
							var n = new Date,
								r = n.getHours(),
								i = n.getMinutes(),
								o = "am",
								a = r;
							12 <= a && (a = r - 12, o = "pm"), 0 == a && (a = 12), i = i < 10 ? "0" + i : i, t.innerHTML = "Autosaved: " + a + ":" + i +
								" " + o
						}
						this.autosaveTimeoutId = setTimeout(function () {
							e.autosave()
						}, this.options.autosave.delay || 1e4)
					} else console.log("EasyMDE: localStorage not available, cannot autosave")
				}, K.prototype.clearAutosavedValue = function () {
					if (Z()) {
						if (null == this.options.autosave || null == this.options.autosave.uniqueId || "" == this.options.autosave.uniqueId) return void console
							.log("EasyMDE: You must set a uniqueId to clear the autosave value");
						localStorage.removeItem("smde_" + this.options.autosave.uniqueId)
					} else console.log("EasyMDE: localStorage not available, cannot autosave")
				}, K.prototype.createSideBySide = function () {
					var r = this.codemirror,
						e = r.getWrapperElement(),
						i = e.nextSibling;
					if (i && /editor-preview-side/.test(i.className) || ((i = document.createElement("div")).className = "editor-preview-side", e.parentNode
							.insertBefore(i, e.nextSibling)), !1 === this.options.syncSideBySidePreviewScroll) return i;
					var o = !1,
						a = !1;
					return r.on("scroll", function (e) {
						if (o) o = !1;
						else {
							a = !0;
							var t = e.getScrollInfo().height - e.getScrollInfo().clientHeight,
								n = parseFloat(e.getScrollInfo().top) / t,
								r = (i.scrollHeight - i.clientHeight) * n;
							i.scrollTop = r
						}
					}), i.onscroll = function () {
						if (a) a = !1;
						else {
							o = !0;
							var e = i.scrollHeight - i.clientHeight,
								t = parseFloat(i.scrollTop) / e,
								n = (r.getScrollInfo().height - r.getScrollInfo().clientHeight) * t;
							r.scrollTo(0, n)
						}
					}, i
				}, K.prototype.createToolbar = function (e) {
					if ((e = e || this.options.toolbar) && 0 !== e.length) {
						var t;
						for (t = 0; t < e.length; t++) null != $[e[t]] && (e[t] = $[e[t]]);
						var r = document.createElement("div");
						r.className = "editor-toolbar";
						var i = this,
							o = {};
						for (i.toolbar = e, t = 0; t < e.length; t++)
							if (("guide" != e[t].name || !1 !== i.options.toolbarGuideIcon) && !(i.options.hideIcons && -1 != i.options.hideIcons.indexOf(e[
									t].name) || ("fullscreen" == e[t].name || "side-by-side" == e[t].name) && p())) {
								if ("|" === e[t]) {
									for (var n = !1, a = t + 1; a < e.length; a++) "|" === e[a] || i.options.hideIcons && -1 != i.options.hideIcons.indexOf(e[a].name) ||
										(n = !0);
									if (!n) continue
								}! function (t) {
									var e, n;
									e = "|" === t ? ((n = document.createElement("i")).className = "separator", n.innerHTML = "|", n) : g(t, i.options.toolbarTips,
										i.options.shortcuts), t.action && ("function" == typeof t.action ? e.onclick = function (e) {
										e.preventDefault(), t.action(i)
									} : "string" == typeof t.action && (e.onclick = function (e) {
										e.preventDefault(), window.open(t.action, "_blank")
									})), o[t.name || t] = e, r.appendChild(e)
								}(e[t])
							}
						i.toolbarElements = o;
						var l = this.codemirror;
						l.on("cursorActivity", function () {
							var e, t, n = v(l);
							for (var r in o) t = void 0, t = o[e = r], n[e] ? t.className += " active" : "fullscreen" != e && "side-by-side" != e && (t.className =
								t.className.replace(/\s*active\s*/g, ""))
						});
						var s = l.getWrapperElement();
						return s.parentNode.insertBefore(r, s), r
					}
				}, K.prototype.createStatusbar = function (e) {
					e = e || this.options.status;
					var t = this.options,
						n = this.codemirror;
					if (e && 0 !== e.length) {
						var r, i, o, a = [];
						for (r = 0; r < e.length; r++)
							if (o = i = void 0, "object" == typeof e[r]) a.push({
								className: e[r].className,
								defaultValue: e[r].defaultValue,
								onUpdate: e[r].onUpdate
							});
							else {
								var l = e[r];
								"words" === l ? (o = function (e) {
									e.innerHTML = q(n.getValue())
								}, i = function (e) {
									e.innerHTML = q(n.getValue())
								}) : "lines" === l ? (o = function (e) {
									e.innerHTML = n.lineCount()
								}, i = function (e) {
									e.innerHTML = n.lineCount()
								}) : "cursor" === l ? (o = function (e) {
									e.innerHTML = "0:0"
								}, i = function (e) {
									var t = n.getCursor();
									e.innerHTML = t.line + ":" + t.ch
								}) : "autosave" === l && (o = function (e) {
									null != t.autosave && !0 === t.autosave.enabled && e.setAttribute("id", "autosaved")
								}), a.push({
									className: l,
									defaultValue: o,
									onUpdate: i
								})
							}
						var s = document.createElement("div");
						for (s.className = "editor-statusbar", r = 0; r < a.length; r++) {
							var u = a[r],
								c = document.createElement("span");
							c.className = u.className, "function" == typeof u.defaultValue && u.defaultValue(c), "function" == typeof u.onUpdate && this.codemirror
								.on("update", function (e, t) {
									return function () {
										t.onUpdate(e)
									}
								}(c, u)), s.appendChild(c)
						}
						var h = this.codemirror.getWrapperElement();
						return h.parentNode.insertBefore(s, h.nextSibling), s
					}
				}, K.prototype.value = function (e) {
					var t = this.codemirror;
					if (void 0 === e) return t.getValue();
					if (t.getDoc().setValue(e), this.isPreviewActive()) {
						var n = t.getWrapperElement().lastChild;
						n.innerHTML = this.options.previewRender(e, n)
					}
					return this
				}, K.toggleBold = r, K.toggleItalic = s, K.toggleStrikethrough = x, K.toggleBlockquote = w, K.toggleHeadingSmaller = k, K.toggleHeadingBigger =
				C, K.toggleHeading1 = S, K.toggleHeading2 = L, K.toggleHeading3 = T, K.toggleCodeBlock = b, K.toggleUnorderedList = M, K.toggleOrderedList =
				A, K.cleanBlock = E, K.drawLink = N, K.drawImage = D, K.drawTable = F, K.drawHorizontalRule = O, K.undo = I, K.redo = B, K.togglePreview =
				H, K.toggleSideBySide = R, K.toggleFullScreen = y, K.prototype.toggleBold = function () {
					r(this)
				}, K.prototype.toggleItalic = function () {
					s(this)
				}, K.prototype.toggleStrikethrough = function () {
					x(this)
				}, K.prototype.toggleBlockquote = function () {
					w(this)
				}, K.prototype.toggleHeadingSmaller = function () {
					k(this)
				}, K.prototype.toggleHeadingBigger = function () {
					C(this)
				}, K.prototype.toggleHeading1 = function () {
					S(this)
				}, K.prototype.toggleHeading2 = function () {
					L(this)
				}, K.prototype.toggleHeading3 = function () {
					T(this)
				}, K.prototype.toggleCodeBlock = function () {
					b(this)
				}, K.prototype.toggleUnorderedList = function () {
					M(this)
				}, K.prototype.toggleOrderedList = function () {
					A(this)
				}, K.prototype.cleanBlock = function () {
					E(this)
				}, K.prototype.drawLink = function () {
					N(this)
				}, K.prototype.drawImage = function () {
					D(this)
				}, K.prototype.drawTable = function () {
					F(this)
				}, K.prototype.drawHorizontalRule = function () {
					O(this)
				}, K.prototype.undo = function () {
					I(this)
				}, K.prototype.redo = function () {
					B(this)
				}, K.prototype.togglePreview = function () {
					H(this)
				}, K.prototype.toggleSideBySide = function () {
					R(this)
				}, K.prototype.toggleFullScreen = function () {
					y(this)
				}, K.prototype.isPreviewActive = function () {
					var e = this.codemirror.getWrapperElement().lastChild;
					return /editor-preview-active/.test(e.className)
				}, K.prototype.isSideBySideActive = function () {
					var e = this.codemirror.getWrapperElement().nextSibling;
					return /editor-preview-active-side/.test(e.className)
				}, K.prototype.isFullscreenActive = function () {
					return this.codemirror.getOption("fullScreen")
				}, K.prototype.getState = function () {
					return v(this.codemirror)
				}, K.prototype.toTextArea = function () {
					var e = this.codemirror,
						t = e.getWrapperElement();
					t.parentNode && (this.gui.toolbar && t.parentNode.removeChild(this.gui.toolbar), this.gui.statusbar && t.parentNode.removeChild(
							this.gui.statusbar), this.gui.sideBySide && t.parentNode.removeChild(this.gui.sideBySide)), e.toTextArea(), this.autosaveTimeoutId &&
						(clearTimeout(this.autosaveTimeoutId), this.autosaveTimeoutId = void 0, this.clearAutosavedValue())
				}, t.exports = K
		}, {
			"./codemirror/tablist": 19,
			codemirror: 11,
			"codemirror-spell-checker": 4,
			"codemirror/addon/display/fullscreen.js": 5,
			"codemirror/addon/display/placeholder.js": 6,
			"codemirror/addon/edit/continuelist.js": 7,
			"codemirror/addon/mode/overlay.js": 8,
			"codemirror/addon/search/searchcursor.js": 9,
			"codemirror/addon/selection/mark-selection.js": 10,
			"codemirror/mode/gfm/gfm.js": 12,
			"codemirror/mode/markdown/markdown.js": 13,
			"codemirror/mode/xml/xml.js": 15,
			marked: 17
		}]
	}, {}, [20])(20)
});